<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class TeacherCourseSeeder extends Seeder
{
    public function run(): void
    {
        // ============================================================
        // BAGIAN A: CREATE TEACHER USERS & PROFILES
        // ============================================================

        // Teacher 1 - Web Development
        $teacher1 = DB::table('users')->insertGetId([
            'name'              => 'Pak Ahmad Fauzi, S.Kom., M.Kom',
            'email'             => 'ahmad.fauzi@kompaskarir.com',
            'password'          => Hash::make('password'),
            'role'              => 'teacher',
            'email_verified_at' => now(),
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        DB::table('teacher_profiles')->insert([
            'user_id'          => $teacher1,
            'specialization'   => 'Web Development (PHP, Laravel, JavaScript)',
            'bio'              => 'Senior Full-Stack Developer dengan pengalaman 12+ tahun di industri teknologi. Telah membangun lebih dari 50 aplikasi web untuk klien nasional dan internasional. Aktif sebagai mentor di komunitas developer Indonesia.',
            'qualification'    => 'S2 Ilmu Komputer - Institut Teknologi Bandung',
            'institution_name' => 'Universitas Teknologi Indonesia',
            'experience_years' => 12,
            'expertise_areas'  => json_encode(['PHP', 'Laravel', 'JavaScript', 'React.js', 'Vue.js', 'Node.js', 'Docker', 'AWS']),
            'linkedin_url'     => 'https://linkedin.com/in/ahmad-fauzi-dev',
            'is_verified'      => true,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);

        // Teacher 2 - Data Science & Analytics
        $teacher2 = DB::table('users')->insertGetId([
            'name'              => 'Dr. Siti Nurhaliza, M.Sc',
            'email'             => 'siti.nurhaliza@kompaskarir.com',
            'password'          => Hash::make('password'),
            'role'              => 'teacher',
            'email_verified_at' => now(),
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        DB::table('teacher_profiles')->insert([
            'user_id'          => $teacher2,
            'specialization'   => 'Data Science & Analytics',
            'bio'              => 'Data Scientist dengan gelar PhD dari Universitas Indonesia. Berpengalaman di bidang machine learning, analisis data, dan AI. Telah mempublikasikan 15+ paper internasional dan menjadi konsultan data untuk beberapa perusahaan Fortune 500.',
            'qualification'    => 'S3 Ilmu Komputer (Data Science) - Universitas Indonesia',
            'institution_name' => 'Institut Teknologi Bandung',
            'experience_years' => 10,
            'expertise_areas'  => json_encode(['Python', 'Machine Learning', 'TensorFlow', 'SQL', 'Tableau', 'Statistika', 'Deep Learning']),
            'linkedin_url'     => 'https://linkedin.com/in/siti-nurhaliza-ds',
            'is_verified'      => true,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);

        // Teacher 3 - UI/UX Design & Mobile
        $teacher3 = DB::table('users')->insertGetId([
            'name'              => 'Rizky Pratama, S.Ds., M.Ds',
            'email'             => 'rizky.pratama@kompaskarir.com',
            'password'          => Hash::make('password'),
            'role'              => 'teacher',
            'email_verified_at' => now(),
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        DB::table('teacher_profiles')->insert([
            'user_id'          => $teacher3,
            'specialization'   => 'UI/UX Design & Mobile Development',
            'bio'              => 'Lead UI/UX Designer di startup unicorn Indonesia. Berpengalaman merancang produk digital untuk jutaan pengguna. Juga aktif sebagai Flutter developer dengan 20+ aplikasi di Play Store.',
            'qualification'    => 'S2 Desain Interaktif - Universitas Multimedia Nusantara',
            'institution_name' => 'Universitas Multimedia Nusantara',
            'experience_years' => 8,
            'expertise_areas'  => json_encode(['Figma', 'UI/UX Design', 'Flutter', 'Dart', 'React Native', 'Prototyping', 'User Research']),
            'linkedin_url'     => 'https://linkedin.com/in/rizky-pratama-design',
            'is_verified'      => true,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);

        // Education 1 - Bootcamp Nusantara
        $education1 = DB::table('users')->insertGetId([
            'name'              => 'Bootcamp Nusantara',
            'email'             => 'info@bootcamp-nusantara.id',
            'password'          => Hash::make('password'),
            'role'              => 'education',
            'email_verified_at' => now(),
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        // ============================================================
        // BAGIAN B: TEACHER & EDUCATION COURSES
        // ============================================================

        // --- Course 1A: Laravel Web Development untuk Pemula ---
        $laravelCompId = DB::table('competencies')->where('name', 'Laravel')->value('id');
        $phpCompId = DB::table('competencies')->where('name', 'PHP')->value('id');
        $htmlCompId = DB::table('competencies')->where('name', 'HTML & CSS')->value('id');
        $jsCompId = DB::table('competencies')->where('name', 'JavaScript')->value('id');
        $reactCompId = DB::table('competencies')->where('name', 'React.js')->value('id');
        $pythonCompId = DB::table('competencies')->where('name', 'Python')->value('id');
        $sqlCompId = DB::table('competencies')->where('name', 'SQL')->value('id');
        $mlCompId = DB::table('competencies')->where('name', 'Machine Learning')->value('id');
        $figmaCompId = DB::table('competencies')->where('name', 'Figma')->value('id');
        $flutterCompId = DB::table('competencies')->where('name', 'Flutter')->value('id');
        $dockerCompId = DB::table('competencies')->where('name', 'Docker')->value('id');
        $commCompId = DB::table('competencies')->where('name', 'Komunikasi')->value('id');

        // ===== TEACHER 1 COURSES =====

        $course1A = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher1,
            'competency_id'  => $laravelCompId,
            'title'          => 'Laravel Web Development untuk Pemula',
            'description'    => 'Kursus komprehensif membangun aplikasi web modern menggunakan Laravel 11. Dari instalasi hingga deployment, pelajari routing, controller, Eloquent ORM, Blade templating, authentication, REST API, dan best practices lainnya. Cocok untuk pemula yang ingin menjadi web developer profesional.',
            'objectives'     => "1. Mampu menginstal dan mengkonfigurasi Laravel\n2. Memahami routing, controller, dan view dalam arsitektur MVC\n3. Menguasai Eloquent ORM untuk manipulasi database\n4. Mampu membuat sistem autentikasi dan otorisasi\n5. Dapat membangun REST API yang terdokumentasi\n6. Mampu deploy aplikasi ke server production",
            'category'       => 'technical',
            'level'          => 'beginner',
            'duration_hours' => 40,
            'status'         => 'published',
            'price'          => 0,
            'is_free'        => true,
            'tags'           => json_encode(['Laravel', 'PHP', 'Web Development', 'Backend', 'MVC']),
            'max_students'   => 30,
            'rating'         => 4.8,
            'total_enrolled' => 45,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        $course1B = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher1,
            'competency_id'  => $reactCompId,
            'title'          => 'Membangun Aplikasi SPA dengan React & Laravel API',
            'description'    => 'Kursus advanced untuk membangun Single Page Application (SPA) menggunakan React.js di frontend dan Laravel sebagai REST API backend. Pelajari state management dengan Redux, authentication dengan Sanctum, real-time features dengan Laravel Echo, dan deployment full-stack.',
            'objectives'     => "1. Mampu membuat REST API di Laravel dengan Laravel Sanctum\n2. Mengelola state aplikasi React menggunakan Redux Toolkit\n3. Mengimplementasikan authentication flow lengkap (login, register, logout)\n4. Membuat fitur real-time dengan Laravel Echo & Pusher\n5. Melakukan testing pada frontend dan backend\n6. Deploy full-stack app ke production",
            'category'       => 'technical',
            'level'          => 'intermediate',
            'duration_hours' => 55,
            'status'         => 'published',
            'price'          => 250000,
            'is_free'        => false,
            'tags'           => json_encode(['React.js', 'Laravel', 'SPA', 'REST API', 'Redux', 'Full-Stack']),
            'max_students'   => 25,
            'rating'         => 4.7,
            'total_enrolled' => 32,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        // ===== TEACHER 2 COURSES =====

        $course2A = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher2,
            'competency_id'  => $pythonCompId,
            'title'          => 'Analisis Data dengan Python & Pandas untuk Pemula',
            'description'    => 'Kursus praktis belajar analisis data menggunakan Python dan library Pandas. Dari membaca dataset hingga membuat visualisasi yang insightful. Gunakan Jupyter Notebook sebagai environment utama dan latihan dengan dataset real-world dari berbagai industri.',
            'objectives'     => "1. Mampu mengoperasikan Python dan Jupyter Notebook\n2. Menguasai Pandas untuk membaca, membersihkan, dan mentransformasi data\n3. Membuat visualisasi data menggunakan Matplotlib dan Seaborn\n4. Memahami statistik dasar untuk analisis data\n5. Mampu melakukan exploratory data analysis (EDA)\n6. Menyelesaikan studi kasus analisis data bisnis",
            'category'       => 'technical',
            'level'          => 'beginner',
            'duration_hours' => 35,
            'status'         => 'published',
            'price'          => 0,
            'is_free'        => true,
            'tags'           => json_encode(['Python', 'Pandas', 'Data Analysis', 'Jupyter', 'Matplotlib']),
            'max_students'   => 40,
            'rating'         => 4.9,
            'total_enrolled' => 58,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        $course2B = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher2,
            'competency_id'  => $sqlCompId,
            'title'          => 'SQL untuk Data Analyst: Dari Dasar hingga Advanced',
            'description'    => 'Kuasai SQL dari nol hingga level advanced untuk kebutuhan analisis data. Pelajari SELECT, JOIN, subqueries, window functions, CTEs, stored procedures, dan query optimization. Semua materi menggunakan dataset bisnis nyata.',
            'objectives'     => "1. Mampu menulis query SQL dasar hingga kompleks\n2. Memahami berbagai jenis JOIN dan penggunaannya\n3. Menguasai window functions dan CTEs\n4. Mampu membuat stored procedures dan triggers\n5. Mengoptimasi query untuk dataset besar\n6. Menganalisis data bisnis menggunakan SQL",
            'category'       => 'technical',
            'level'          => 'intermediate',
            'duration_hours' => 30,
            'status'         => 'published',
            'price'          => 175000,
            'is_free'        => false,
            'tags'           => json_encode(['SQL', 'Database', 'Data Analyst', 'MySQL', 'PostgreSQL']),
            'max_students'   => 35,
            'rating'         => 4.6,
            'total_enrolled' => 41,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        // ===== TEACHER 3 COURSES =====

        $course3A = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher3,
            'competency_id'  => $figmaCompId,
            'title'          => 'Desain UI/UX dengan Figma: Panduan Lengkap',
            'description'    => 'Kursus lengkap desain UI/UX menggunakan Figma. Dari design thinking, user research, wireframing, hingga high-fidelity prototype. Bangun portfolio profesional dengan 3 project nyata yang siap ditunjukkan ke perusahaan.',
            'objectives'     => "1. Memahami prinsip design thinking dan user-centered design\n2. Mampu melakukan user research dan usability testing\n3. Menguasai Figma untuk wireframing dan prototyping\n4. Membuat design system yang konsisten\n5. Membangun high-fidelity prototype dengan interaksi\n6. Membuat portfolio desain UI/UX profesional",
            'category'       => 'technical',
            'level'          => 'beginner',
            'duration_hours' => 45,
            'status'         => 'published',
            'price'          => 0,
            'is_free'        => true,
            'tags'           => json_encode(['Figma', 'UI/UX', 'Design Thinking', 'Prototyping', 'User Research']),
            'max_students'   => 35,
            'rating'         => 4.8,
            'total_enrolled' => 52,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        $course3B = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $teacher3,
            'competency_id'  => $flutterCompId,
            'title'          => 'Flutter untuk Pemula: Bangun Aplikasi Mobile Cross-Platform',
            'description'    => 'Belajar Flutter dari nol hingga mampu membangun aplikasi mobile untuk Android dan iOS. Pelajari Dart, widget system, state management dengan Provider, integrasi REST API, local storage, dan deployment ke Play Store & App Store.',
            'objectives'     => "1. Menguasai bahasa Dart dan Flutter framework\n2. Mampu membangun UI responsif dengan widget system\n3. Mengelola state aplikasi menggunakan Provider/Riverpod\n4. Mengintegrasikan REST API ke aplikasi Flutter\n5. Mengimplementasi local storage dan push notification\n6. Deploy aplikasi ke Play Store dan App Store",
            'category'       => 'technical',
            'level'          => 'beginner',
            'duration_hours' => 50,
            'status'         => 'published',
            'price'          => 199000,
            'is_free'        => false,
            'tags'           => json_encode(['Flutter', 'Dart', 'Mobile Development', 'Cross-Platform', 'Android', 'iOS']),
            'max_students'   => 30,
            'rating'         => 4.7,
            'total_enrolled' => 38,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        // ===== EDUCATION 1 COURSES =====

        $course4A = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $education1,
            'competency_id'  => $htmlCompId,
            'title'          => 'Fullstack Web Development Bootcamp',
            'description'    => 'Bootcamp intensif selama 80 jam untuk menjadi fullstack web developer. Kurikulum dirancang bersama industri, mencakup frontend (HTML, CSS, JavaScript, React), backend (Node.js/PHP, Express/Laravel), database (MySQL, MongoDB), dan deployment. Termasuk project akhir dan career coaching.',
            'objectives'     => "1. Menguasai HTML, CSS, dan JavaScript ES6+\n2. Mampu membangun frontend dengan React.js\n3. Membuat RESTful API dengan Node.js atau PHP/Laravel\n4. Mengelola database SQL dan NoSQL\n5. Deploy aplikasi ke cloud (Vercel, Railway, AWS)\n6. Membuat portfolio profesional dan CV developer",
            'category'       => 'technical',
            'level'          => 'intermediate',
            'duration_hours' => 80,
            'status'         => 'published',
            'price'          => 450000,
            'is_free'        => false,
            'tags'           => json_encode(['Fullstack', 'Bootcamp', 'React', 'Node.js', 'Laravel', 'Career']),
            'max_students'   => 25,
            'rating'         => 4.9,
            'total_enrolled' => 67,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        $course4B = DB::table('teacher_courses')->insertGetId([
            'teacher_id'     => $education1,
            'competency_id'  => $commCompId,
            'title'          => 'Career Preparation & Soft Skills untuk Fresh Graduate',
            'description'    => 'Kursus persiapan karir untuk fresh graduate dan job seeker. Pelajari cara membuat CV yang ATS-friendly, teknik interview STAR, negosiasi gaji, personal branding di LinkedIn, dan soft skills yang dibutuhkan di dunia kerja modern.',
            'objectives'     => "1. Membuat CV dan surat lamaran yang lolos ATS\n2. Menguasai teknik interview STAR (Situation, Task, Action, Result)\n3. Membangun personal branding yang kuat di LinkedIn\n4. Memahami etika dan komunikasi profesional\n5. Mampu bernegosiasi gaji dan benefit\n6. Mempersiapkan portofolio dan dokumen pendukung karir",
            'category'       => 'soft_skill',
            'level'          => 'beginner',
            'duration_hours' => 20,
            'status'         => 'published',
            'price'          => 0,
            'is_free'        => true,
            'tags'           => json_encode(['Career', 'Soft Skills', 'CV', 'Interview', 'LinkedIn', 'Fresh Graduate']),
            'max_students'   => 50,
            'rating'         => 4.8,
            'total_enrolled' => 89,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        // ============================================================
        // BAGIAN C: COURSE MODULES
        // ============================================================

        // --- Course 1A: Laravel Web Development ---
        $modules1A = [];
        $module1A_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'Pengenalan Laravel & Setup Environment',
            'description' => 'Instalasi Laravel, pengenalan arsitektur MVC, struktur folder, dan konfigurasi dasar.',
            'order_number' => 1, 'duration_minutes' => 180,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_1;

        $module1A_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'Routing, Controller & View',
            'description' => 'Mempelajari cara mengatur routing, membuat controller, dan menampilkan view dengan Blade templating engine.',
            'order_number' => 2, 'duration_minutes' => 240,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_2;

        $module1A_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'Database & Eloquent ORM',
            'description' => 'Migration, seeder, Eloquent relationships (hasOne, hasMany, belongsTo, belongsToMany), dan query builder.',
            'order_number' => 3, 'duration_minutes' => 300,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_3;

        $module1A_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'Authentication & Authorization',
            'description' => 'Implementasi login, register, middleware, role-based access control dengan Laravel Breeze.',
            'order_number' => 4, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_4;

        $module1A_5 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'REST API Development',
            'description' => 'Membangun RESTful API dengan Laravel, API resources, authentication dengan Sanctum, dan dokumentasi dengan Swagger.',
            'order_number' => 5, 'duration_minutes' => 280,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_5;

        $module1A_6 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1A, 'title' => 'Deployment & Best Practices',
            'description' => 'Deploy ke VPS, konfigurasi Nginx, environment variables, queue, caching, dan security best practices.',
            'order_number' => 6, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1A[] = $module1A_6;

        // --- Course 1B: React & Laravel SPA ---
        $modules1B = [];
        $module1B_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1B, 'title' => 'Arsitektur SPA & Project Setup',
            'description' => 'Pengenalan SPA vs MPA, setup Laravel API + React project, CORS, dan environment configuration.',
            'order_number' => 1, 'duration_minutes' => 150,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1B[] = $module1B_1;

        $module1B_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1B, 'title' => 'REST API dengan Laravel Sanctum',
            'description' => 'Membangun API endpoints, token-based authentication, middleware, dan error handling.',
            'order_number' => 2, 'duration_minutes' => 300,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1B[] = $module1B_2;

        $module1B_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1B, 'title' => 'React State Management dengan Redux',
            'description' => 'Redux Toolkit, slices, thunks, RTK Query untuk data fetching, dan state normalization.',
            'order_number' => 3, 'duration_minutes' => 350,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1B[] = $module1B_3;

        $module1B_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course1B, 'title' => 'Real-time Features dengan Laravel Echo',
            'description' => 'WebSocket, Laravel Broadcasting, Pusher, real-time notifications dan chat system.',
            'order_number' => 4, 'duration_minutes' => 250,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules1B[] = $module1B_4;

        // --- Course 2A: Python Data Analysis ---
        $modules2A = [];
        $module2A_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2A, 'title' => 'Setup Python & Jupyter Notebook',
            'description' => 'Instalasi Python, pip, virtual environment, Jupyter Notebook, dan pengenalan syntax dasar Python.',
            'order_number' => 1, 'duration_minutes' => 120,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2A[] = $module2A_1;

        $module2A_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2A, 'title' => 'Pandas: Membaca dan Membersihkan Data',
            'description' => 'DataFrame, Series, read_csv, data cleaning, handling missing values, data type conversion.',
            'order_number' => 2, 'duration_minutes' => 240,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2A[] = $module2A_2;

        $module2A_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2A, 'title' => 'Visualisasi Data dengan Matplotlib & Seaborn',
            'description' => 'Membuat chart, plot, dan grafik yang informative untuk presentasi data.',
            'order_number' => 3, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2A[] = $module2A_3;

        $module2A_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2A, 'title' => 'Analisis Statistik Dasar',
            'description' => 'Mean, median, modus, standar deviasi, korelasi, dan distribusi data.',
            'order_number' => 4, 'duration_minutes' => 180,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2A[] = $module2A_4;

        $module2A_5 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2A, 'title' => 'Studi Kasus: Analisis Data Penjualan',
            'description' => 'Project akhir: analisis dataset penjualan e-commerce dari cleaning hingga insight.',
            'order_number' => 5, 'duration_minutes' => 300,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2A[] = $module2A_5;

        // --- Course 2B: SQL untuk Data Analyst ---
        $modules2B = [];
        $module2B_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2B, 'title' => 'SQL Fundamentals',
            'description' => 'SELECT, WHERE, ORDER BY, GROUP BY, HAVING, dan aggregate functions.',
            'order_number' => 1, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2B[] = $module2B_1;

        $module2B_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2B, 'title' => 'JOINs & Subqueries',
            'description' => 'INNER, LEFT, RIGHT, FULL JOIN, subqueries, dan correlated subqueries.',
            'order_number' => 2, 'duration_minutes' => 250,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2B[] = $module2B_2;

        $module2B_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course2B, 'title' => 'Window Functions & CTEs',
            'description' => 'ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD, WITH clause, dan recursive CTEs.',
            'order_number' => 3, 'duration_minutes' => 300,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules2B[] = $module2B_3;

        // --- Course 3A: UI/UX Figma ---
        $modules3A = [];
        $module3A_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'Pengenalan UI/UX & Design Thinking',
            'description' => 'Prinsip desain, design thinking process, empati pengguna, dan problem framing.',
            'order_number' => 1, 'duration_minutes' => 180,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_1;

        $module3A_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'Mengenal Figma: Tools & Interface',
            'description' => 'Navigasi Figma, frame, shape, text, auto layout, components, dan design tokens.',
            'order_number' => 2, 'duration_minutes' => 240,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_2;

        $module3A_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'Wireframing & Low-fidelity Prototype',
            'description' => 'Teknik wireframing, user flow, information architecture, dan low-fi prototype.',
            'order_number' => 3, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_3;

        $module3A_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'Visual Design: Warna, Tipografi & Ikon',
            'description' => 'Color theory, typography hierarchy, iconography, dan visual consistency.',
            'order_number' => 4, 'duration_minutes' => 180,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_4;

        $module3A_5 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'High-fidelity Prototype & Interaksi',
            'description' => 'Membuat hi-fi prototype dengan micro-interactions, transitions, dan component variants.',
            'order_number' => 5, 'duration_minutes' => 250,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_5;

        $module3A_6 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3A, 'title' => 'User Testing & Iterasi',
            'description' => 'Usability testing, heuristic evaluation, A/B testing, dan iterasi desain berdasarkan feedback.',
            'order_number' => 6, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3A[] = $module3A_6;

        // --- Course 3B: Flutter Mobile ---
        $modules3B = [];
        $module3B_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3B, 'title' => 'Dart Programming Fundamentals',
            'description' => 'Sintaks Dart, OOP, async/await, null safety, dan collection types.',
            'order_number' => 1, 'duration_minutes' => 200,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3B[] = $module3B_1;

        $module3B_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3B, 'title' => 'Flutter Widget System',
            'description' => 'StatelessWidget, StatefulWidget, layout widgets, ListView, GridView, dan custom widgets.',
            'order_number' => 2, 'duration_minutes' => 280,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3B[] = $module3B_2;

        $module3B_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3B, 'title' => 'State Management dengan Provider',
            'description' => 'Provider, ChangeNotifier, Consumer, MultiProvider, dan state management patterns.',
            'order_number' => 3, 'duration_minutes' => 250,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3B[] = $module3B_3;

        $module3B_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course3B, 'title' => 'REST API & Firebase Integration',
            'description' => 'HTTP client, JSON serialization, Firebase Auth, Firestore, dan push notifications.',
            'order_number' => 4, 'duration_minutes' => 300,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules3B[] = $module3B_4;

        // --- Course 4A: Fullstack Bootcamp ---
        $modules4A = [];
        $module4A_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4A, 'title' => 'Frontend Basic: HTML, CSS & JavaScript',
            'description' => 'HTML semantic, CSS Flexbox & Grid, JavaScript ES6+, DOM manipulation.',
            'order_number' => 1, 'duration_minutes' => 480,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4A[] = $module4A_1;

        $module4A_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4A, 'title' => 'Frontend Advanced: React.js',
            'description' => 'Components, hooks, state management, routing, dan API integration dengan React.',
            'order_number' => 2, 'duration_minutes' => 400,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4A[] = $module4A_2;

        $module4A_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4A, 'title' => 'Backend: Node.js & Express',
            'description' => 'RESTful API, middleware, authentication JWT, error handling, dan testing.',
            'order_number' => 3, 'duration_minutes' => 400,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4A[] = $module4A_3;

        $module4A_4 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4A, 'title' => 'Database & Deployment',
            'description' => 'MySQL, MongoDB, ORM (Prisma/Sequelize), Docker basics, deploy ke Railway/Vercel.',
            'order_number' => 4, 'duration_minutes' => 350,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4A[] = $module4A_4;

        // --- Course 4B: Career Preparation ---
        $modules4B = [];
        $module4B_1 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4B, 'title' => 'Membuat CV & Surat Lamaran',
            'description' => 'Format CV ATS-friendly, struktur surat lamaran, dan tips menulis deskripsi pengalaman.',
            'order_number' => 1, 'duration_minutes' => 120,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4B[] = $module4B_1;

        $module4B_2 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4B, 'title' => 'Teknik Interview & Negosiasi',
            'description' => 'Metode STAR, behavioral questions, technical interview, dan negosiasi gaji.',
            'order_number' => 2, 'duration_minutes' => 150,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4B[] = $module4B_2;

        $module4B_3 = DB::table('course_modules')->insertGetId([
            'course_id' => $course4B, 'title' => 'Personal Branding & LinkedIn',
            'description' => 'Optimasi LinkedIn, networking strategy, personal branding, dan building professional presence.',
            'order_number' => 3, 'duration_minutes' => 120,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $modules4B[] = $module4B_3;

        // ============================================================
        // BAGIAN D: COURSE MATERIALS
        // ============================================================

        // Helper: Insert materials for a module
        $allModuleIds = array_merge($modules1A, $modules1B, $modules2A, $modules2B, $modules3A, $modules3B, $modules4A, $modules4B);

        foreach ($allModuleIds as $moduleId) {
            $module = DB::table('course_modules')->where('id', $moduleId)->first();
            $moduleTitle = $module->title;

            DB::table('course_materials')->insert([
                [
                    'module_id'       => $moduleId,
                    'title'           => "Handout: {$moduleTitle}",
                    'type'            => 'document',
                    'file_path'       => "materials/documents/" . str_replace([' ', ':', '/'], '-', strtolower($moduleTitle)) . ".pdf",
                    'file_name'       => str_replace([' ', ':', '/'], '-', strtolower($moduleTitle)) . ".pdf",
                    'file_size'       => rand(300000, 800000),
                    'mime_type'       => 'application/pdf',
                    'content'         => "Handout materi pembelajaran untuk modul: {$moduleTitle}. File ini berisi penjelasan lengkap, contoh kode, dan diagram yang mendukung pembelajaran.",
                    'external_url'    => null,
                    'order_number'    => 1,
                    'is_downloadable' => true,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
                [
                    'module_id'       => $moduleId,
                    'title'           => "Video Tutorial: {$moduleTitle}",
                    'type'            => 'video',
                    'file_path'       => null,
                    'file_name'       => null,
                    'file_size'       => null,
                    'mime_type'       => null,
                    'content'         => "Video tutorial pembelajaran untuk modul: {$moduleTitle}. Durasi video sekitar " . rand(15, 45) . " menit dengan penjelasan step-by-step.",
                    'external_url'    => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                    'order_number'    => 2,
                    'is_downloadable' => false,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
                [
                    'module_id'       => $moduleId,
                    'title'           => "Referensi Eksternal: {$moduleTitle}",
                    'type'            => 'link',
                    'file_path'       => null,
                    'file_name'       => null,
                    'file_size'       => null,
                    'mime_type'       => null,
                    'content'         => "Kumpulan referensi dan bacaan tambahan untuk memperdalam pemahaman modul: {$moduleTitle}.",
                    'external_url'    => 'https://laravel.com/docs',
                    'order_number'    => 3,
                    'is_downloadable' => false,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
                [
                    'module_id'       => $moduleId,
                    'title'           => "Tugas Praktik: {$moduleTitle}",
                    'type'            => 'assignment',
                    'file_path'       => null,
                    'file_name'       => null,
                    'file_size'       => null,
                    'mime_type'       => null,
                    'content'         => "Kerjakan tugas praktik berikut untuk memperdalam pemahaman materi '{$moduleTitle}':\n\n1. Buatlah implementasi sederhana dari konsep yang dipelajari\n2. Dokumentasikan kode dengan komentar yang jelas\n3. Screenshot hasil kerja dan lampirkan sebagai file submission\n4. Tulis refleksi pembelajaran (minimal 200 kata)",
                    'external_url'    => null,
                    'order_number'    => 4,
                    'is_downloadable' => false,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
            ]);
        }

        // ============================================================
        // BAGIAN E: TEACHER CLASSES
        // ============================================================

        $class1A = DB::table('teacher_classes')->insertGetId([
            'teacher_id' => $teacher1, 'course_id' => $course1A,
            'name' => 'Kelas Pagi Laravel Batch 2026-A', 'code' => 'LV-2026-A1',
            'description' => 'Kelas intensif Laravel untuk pemula. Jadwal pagi hari, cocok untuk fresh graduate dan career switcher.',
            'start_date' => '2026-07-07', 'end_date' => '2026-10-07',
            'max_students' => 30, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/abc-defg-hij',
            'schedule_info' => 'Setiap Senin & Rabu, 09.00–11.00 WIB',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $class1B = DB::table('teacher_classes')->insertGetId([
            'teacher_id' => $teacher1, 'course_id' => $course1B,
            'name' => 'React + Laravel SPA Batch 2026-A', 'code' => 'RL-2026-A1',
            'description' => 'Kelas malam untuk developer yang ingin upgrade skill ke SPA.',
            'start_date' => '2026-07-14', 'end_date' => '2026-10-14',
            'max_students' => 25, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/klm-nopq-rst',
            'schedule_info' => 'Setiap Selasa & Kamis, 19.00–21.30 WIB',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $class2A = DB::table('teacher_classes')->insertGetId([
            'teacher_id' => $teacher2, 'course_id' => $course2A,
            'name' => 'Python Data Analysis Batch 2026-A', 'code' => 'PY-2026-A1',
            'description' => 'Kelas Python untuk analisis data. Menggunakan dataset real-world.',
            'start_date' => '2026-07-10', 'end_date' => '2026-10-10',
            'max_students' => 40, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/uvw-xyz-a1b',
            'schedule_info' => 'Setiap Rabu & Jumat, 19.00–21.00 WIB',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $class3A = DB::table('teacher_classes')->insertGetId([
            'teacher_id' => $teacher3, 'course_id' => $course3A,
            'name' => 'UI/UX Figma Batch 2026-A', 'code' => 'UX-2026-A1',
            'description' => 'Kelas desain UI/UX dengan Figma. Portfolio-based learning.',
            'start_date' => '2026-07-21', 'end_date' => '2026-10-21',
            'max_students' => 35, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/cde-fgh-ijk',
            'schedule_info' => 'Setiap Senin & Kamis, 16.00–18.00 WIB',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $class4A = DB::table('teacher_classes')->insertGetId([
            'teacher_id' => $education1, 'course_id' => $course4A,
            'name' => 'Fullstack Bootcamp Batch 2026-A', 'code' => 'FS-2026-A1',
            'description' => 'Bootcamp intensif fullstack web development. Career coaching included.',
            'start_date' => '2026-07-01', 'end_date' => '2026-10-30',
            'max_students' => 25, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/lmn-opq-rst',
            'schedule_info' => 'Senin–Jumat, 09.00–12.00 WIB (intensif)',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        // ============================================================
        // BAGIAN F: JOB SEEKER ENROLLMENTS
        // ============================================================

        $seekerIds = DB::table('users')->where('role', 'job_seeker')->pluck('id')->toArray();
        $seekerSlice1 = array_slice($seekerIds, 0, 5);
        $seekerSlice2 = array_slice($seekerIds, 5, 5);

        // Enrollments for Class 1A (Laravel)
        $enrollments1A = [];
        foreach ($seekerSlice1 as $i => $seekerId) {
            $progress = [75, 60, 45, 90, 30][$i];
            $status = $progress >= 90 ? 'active' : 'active';
            $eid = DB::table('class_enrollments')->insertGetId([
                'class_id' => $class1A, 'user_id' => $seekerId,
                'status' => $status, 'progress_percentage' => $progress,
                'completed_modules' => intval($progress / 20),
                'enrolled_at' => Carbon::now()->subDays(30 - $i * 3),
                'completed_at' => null, 'final_score' => null,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            $enrollments1A[] = ['id' => $eid, 'user_id' => $seekerId, 'progress' => $progress];
        }

        // Enrollments for Class 2A (Python)
        $enrollments2A = [];
        foreach ($seekerSlice2 as $i => $seekerId) {
            $progress = [80, 55, 100, 40, 65][$i];
            $status = $progress >= 100 ? 'completed' : 'active';
            $eid = DB::table('class_enrollments')->insertGetId([
                'class_id' => $class2A, 'user_id' => $seekerId,
                'status' => $status, 'progress_percentage' => min($progress, 100),
                'completed_modules' => intval(min($progress, 100) / 20),
                'enrolled_at' => Carbon::now()->subDays(35 - $i * 4),
                'completed_at' => $progress >= 100 ? Carbon::now()->subDays(2) : null,
                'final_score' => $progress >= 100 ? 87.5 : null,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            $enrollments2A[] = ['id' => $eid, 'user_id' => $seekerId, 'progress' => $progress];
        }

        // ============================================================
        // BAGIAN G: SUBMISSIONS
        // ============================================================

        // Get assignment material IDs for course 1A
        $assignmentMaterials1A = DB::table('course_materials')
            ->whereIn('module_id', $modules1A)
            ->where('type', 'assignment')
            ->pluck('id', 'module_id')
            ->toArray();

        // Submissions for enrollments in class 1A
        foreach ($enrollments1A as $enrollment) {
            $materialIds = array_values($assignmentMaterials1A);
            $matIndex = min(count($materialIds) - 1, intval($enrollment['progress'] / 25));

            if ($matIndex >= 0 && isset($materialIds[$matIndex])) {
                $isGraded = $enrollment['progress'] >= 50;
                DB::table('submissions')->insert([
                    'enrollment_id' => $enrollment['id'],
                    'material_id'   => $materialIds[$matIndex],
                    'content'       => "Berikut adalah hasil tugas praktik yang telah saya kerjakan. Saya telah mengimplementasikan konsep yang dipelajari dalam modul ini dengan membuat aplikasi CRUD sederhana menggunakan Laravel.",
                    'file_path'     => "submissions/user-{$enrollment['user_id']}/tugas-modul-" . ($matIndex + 1) . ".pdf",
                    'file_name'     => "tugas-modul-" . ($matIndex + 1) . ".pdf",
                    'file_size'     => rand(100000, 500000),
                    'status'        => $isGraded ? 'graded' : 'submitted',
                    'score'         => $isGraded ? rand(70, 95) : null,
                    'feedback'      => $isGraded ? "Kerja bagus! Kode sudah rapi dan terstruktur. Perhatikan penggunaan naming convention yang lebih konsisten. Pertahankan!" : null,
                    'submitted_at'  => Carbon::now()->subDays(rand(3, 15)),
                    'graded_at'     => $isGraded ? Carbon::now()->subDays(rand(1, 5)) : null,
                    'created_at'    => now(), 'updated_at' => now(),
                ]);
            }
        }

        // Get assignment material IDs for course 2A
        $assignmentMaterials2A = DB::table('course_materials')
            ->whereIn('module_id', $modules2A)
            ->where('type', 'assignment')
            ->pluck('id', 'module_id')
            ->toArray();

        // Submissions for enrollments in class 2A
        foreach ($enrollments2A as $enrollment) {
            if ($enrollment['progress'] < 30) continue;

            $materialIds = array_values($assignmentMaterials2A);
            $matIndex = min(count($materialIds) - 1, intval($enrollment['progress'] / 25));

            if ($matIndex >= 0 && isset($materialIds[$matIndex])) {
                $isGraded = $enrollment['progress'] >= 60;
                DB::table('submissions')->insert([
                    'enrollment_id' => $enrollment['id'],
                    'material_id'   => $materialIds[$matIndex],
                    'content'       => "Analisis data penjualan telah selesai. Berikut adalah hasil cleaning data, visualisasi, dan insight yang ditemukan. Total revenue Q1 2026 naik 23% dibanding Q1 2025.",
                    'file_path'     => "submissions/user-{$enrollment['user_id']}/analisis-data.pdf",
                    'file_name'     => "analisis-data-penjualan.pdf",
                    'file_size'     => rand(200000, 600000),
                    'status'        => $isGraded ? 'graded' : 'submitted',
                    'score'         => $isGraded ? rand(75, 98) : null,
                    'feedback'      => $isGraded ? "Analisis sangat baik! Visualisasi data sudah jelas dan insight yang ditemukan relevan. Saran: tambahkan confidence interval pada analisis statistik." : null,
                    'submitted_at'  => Carbon::now()->subDays(rand(3, 12)),
                    'graded_at'     => $isGraded ? Carbon::now()->subDays(rand(1, 4)) : null,
                    'created_at'    => now(), 'updated_at' => now(),
                ]);
            }
        }

        // Clean up temporary script
        @unlink(__DIR__ . '/../check_competencies.php');
        @unlink(__DIR__ . '/../check_state.php');
    }
}
