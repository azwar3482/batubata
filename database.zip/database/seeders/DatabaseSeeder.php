<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            CategorySeeder::class,
            CompetencySeeder::class,
            CourseSeeder::class,
            TeacherCourseSeeder::class,
            EducationCourseSeeder::class,
            EducationStudentSeeder::class,
            IndustryCompetencySeeder::class,
            DataRelationshipSeeder::class,
            ProgramSeeder::class,
            RecruitmentTeamSeeder::class,
        ]);
    }
}
