<?php

namespace Database\Seeders;

use App\Models\Competency;
use App\Models\Position;
use Illuminate\Database\Seeder;

class CompetencySeeder extends Seeder
{
    public function run(): void
    {
        // ============================================================
        // MAPPING POSISI
        // Ambil position_id berdasarkan nama posisi yang sudah ada
        // ============================================================
        $getPositionId = function (string $name): ?int {
            $position = Position::where('name', $name)->first();
            return $position?->id;
        };

        $posIds = [
            1  => $getPositionId('Digital Marketing Specialist'),
            2  => $getPositionId('Data Analyst'),
            3  => $getPositionId('Frontend Developer'),
            4  => $getPositionId('Backend Developer'),
            5  => $getPositionId('UI/UX Designer'),
            6  => $getPositionId('Project Manager'),
            7  => $getPositionId('HR Specialist'),
            8  => $getPositionId('Product Manager'),
            9  => $getPositionId('Web Developer'),
            10 => $getPositionId('Mobile Developer'),
            11 => $getPositionId('DevOps Engineer'),
            12 => $getPositionId('Digital Marketing'),
        ];

        $competencies = [

            // ============================================================
            // 1. DIGITAL MARKETING SPECIALIST (position_id: 1)
            // Code prefix: DMS
            // ============================================================

            // Technical Skills
            ['code' => 'DMS-TECH-001', 'name' => 'SEO (Search Engine Optimization)', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Google Digital Marketing Course'],
            ['code' => 'DMS-TECH-002', 'name' => 'SEM (Search Engine Marketing)', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Google Ads Certification'],
            ['code' => 'DMS-TECH-003', 'name' => 'Google Analytics', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Google Analytics Academy'],
            ['code' => 'DMS-TECH-004', 'name' => 'Social Media Marketing', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Meta Blueprint Certification'],
            ['code' => 'DMS-TECH-005', 'name' => 'Content Marketing', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DMS-TECH-006', 'name' => 'Email Marketing', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DMS-TECH-007', 'name' => 'Google Ads & Facebook Ads', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Google Ads Certification'],
            ['code' => 'DMS-TECH-008', 'name' => 'Marketing Automation', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DMS-TECH-009', 'name' => 'Copywriting', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DMS-TECH-010', 'name' => 'A/B Testing', 'category' => 'technical', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // Soft Skills
            ['code' => 'DMS-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DMS-SOFT-002', 'name' => 'Creativity', 'category' => 'soft_skill', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DMS-SOFT-003', 'name' => 'Analytical Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DMS-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DMS-SOFT-005', 'name' => 'Adaptability', 'category' => 'soft_skill', 'position_id' => $posIds[1], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // ============================================================
            // 2. DATA ANALYST (position_id: 2)
            // Code prefix: DA
            // ============================================================

            // Technical Skills
            ['code' => 'DA-TECH-001', 'name' => 'SQL', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-TECH-002', 'name' => 'Python (Pandas, NumPy)', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-TECH-003', 'name' => 'Microsoft Excel / Google Sheets', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-TECH-004', 'name' => 'Tableau / Power BI', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => 'Tableau Desktop Specialist'],
            ['code' => 'DA-TECH-005', 'name' => 'Statistical Analysis', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-TECH-006', 'name' => 'Data Visualization', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-TECH-007', 'name' => 'ETL Processes', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DA-TECH-008', 'name' => 'R Programming', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'DA-TECH-009', 'name' => 'Machine Learning Basics', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'DA-TECH-010', 'name' => 'Database Management', 'category' => 'technical', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // Soft Skills
            ['code' => 'DA-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-SOFT-003', 'name' => 'Attention to Detail', 'category' => 'soft_skill', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'DA-SOFT-004', 'name' => 'Critical Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DA-SOFT-005', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[2], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // ============================================================
            // 3. FRONTEND DEVELOPER (position_id: 3)
            // Code prefix: FE
            // ============================================================

            // Technical Skills
            ['code' => 'FE-TECH-001', 'name' => 'HTML/CSS', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'FE-TECH-002', 'name' => 'JavaScript', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'FE-TECH-003', 'name' => 'React.js / Vue.js / Angular', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-TECH-004', 'name' => 'TypeScript', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-TECH-005', 'name' => 'Responsive Design', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'FE-TECH-006', 'name' => 'CSS Frameworks (Tailwind, Bootstrap)', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-TECH-007', 'name' => 'Version Control (Git)', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-TECH-008', 'name' => 'REST API Integration', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-TECH-009', 'name' => 'Testing (Jest, Cypress)', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'FE-TECH-010', 'name' => 'Web Performance Optimization', 'category' => 'technical', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // Soft Skills
            ['code' => 'FE-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'FE-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'FE-SOFT-003', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'FE-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'FE-SOFT-005', 'name' => 'Adaptability', 'category' => 'soft_skill', 'position_id' => $posIds[3], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // ============================================================
            // 4. BACKEND DEVELOPER (position_id: 4)
            // Code prefix: BE
            // ============================================================

            // Technical Skills
            ['code' => 'BE-TECH-001', 'name' => 'PHP / Python / Java / Node.js', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'BE-TECH-002', 'name' => 'Laravel / Django / Spring / Express', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'BE-TECH-003', 'name' => 'SQL Databases (MySQL, PostgreSQL)', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'BE-TECH-004', 'name' => 'NoSQL Databases (MongoDB, Redis)', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-TECH-005', 'name' => 'RESTful API Design', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'BE-TECH-006', 'name' => 'Authentication & Authorization', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'BE-TECH-007', 'name' => 'Caching Strategies', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-TECH-008', 'name' => 'Message Queues (RabbitMQ, Kafka)', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'BE-TECH-009', 'name' => 'Docker / Containerization', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-TECH-010', 'name' => 'CI/CD Pipelines', 'category' => 'technical', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // Soft Skills
            ['code' => 'BE-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'BE-SOFT-003', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'BE-SOFT-005', 'name' => 'Analytical Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[4], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // ============================================================
            // 5. UI/UX DESIGNER (position_id: 5)
            // Code prefix: UX
            // ============================================================

            // Technical Skills
            ['code' => 'UX-TECH-001', 'name' => 'Figma / Sketch / Adobe XD', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'UX-TECH-002', 'name' => 'Wireframing & Prototyping', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'UX-TECH-003', 'name' => 'User Research', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-004', 'name' => 'Usability Testing', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-005', 'name' => 'Design Systems', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-006', 'name' => 'Information Architecture', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-007', 'name' => 'Interaction Design', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-008', 'name' => 'Visual Design', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-TECH-009', 'name' => 'Accessibility (WCAG)', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => 'WCAG 2.1 Guidelines'],
            ['code' => 'UX-TECH-010', 'name' => 'HTML/CSS Basics', 'category' => 'technical', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],

            // Soft Skills
            ['code' => 'UX-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-SOFT-002', 'name' => 'Creativity', 'category' => 'soft_skill', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'UX-SOFT-003', 'name' => 'Empathy', 'category' => 'soft_skill', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'UX-SOFT-004', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'UX-SOFT-005', 'name' => 'Presentation Skills', 'category' => 'soft_skill', 'position_id' => $posIds[5], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // ============================================================
            // 6. PROJECT MANAGER (position_id: 6)
            // Code prefix: PMG
            // ============================================================

            // Technical Skills
            ['code' => 'PMG-TECH-001', 'name' => 'Project Management Tools (Jira, Trello, Asana)', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => 'PMP Certification'],
            ['code' => 'PMG-TECH-002', 'name' => 'Agile/Scrum Methodology', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => 'Scrum Alliance'],
            ['code' => 'PMG-TECH-003', 'name' => 'Waterfall Methodology', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'PMI PMBOK'],
            ['code' => 'PMG-TECH-004', 'name' => 'Risk Management', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PMG-TECH-005', 'name' => 'Budget Management', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PMG-TECH-006', 'name' => 'Resource Allocation', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PMG-TECH-007', 'name' => 'Stakeholder Management', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PMG-TECH-008', 'name' => 'Microsoft Project', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'PMG-TECH-009', 'name' => 'Reporting & Documentation', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PMG-TECH-010', 'name' => 'Quality Assurance', 'category' => 'technical', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'PMG-SOFT-001', 'name' => 'Leadership', 'category' => 'soft_skill', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PMG-SOFT-002', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PMG-SOFT-003', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PMG-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PMG-SOFT-005', 'name' => 'Negotiation', 'category' => 'soft_skill', 'position_id' => $posIds[6], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // ============================================================
            // 7. HR SPECIALIST (position_id: 7)
            // Code prefix: HR
            // ============================================================

            // Technical Skills
            ['code' => 'HR-TECH-001', 'name' => 'HRIS (Human Resource Information System)', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-002', 'name' => 'Recruitment & Talent Acquisition', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-003', 'name' => 'Payroll Management', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-004', 'name' => 'Employee Relations', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-005', 'name' => 'Performance Management', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-006', 'name' => 'Training & Development', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'HR-TECH-007', 'name' => 'Labor Law & Compliance', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-008', 'name' => 'HR Analytics', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'HR-TECH-009', 'name' => 'Onboarding Processes', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-TECH-010', 'name' => 'Compensation & Benefits', 'category' => 'technical', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'HR-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'HR-SOFT-002', 'name' => 'Empathy', 'category' => 'soft_skill', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'HR-SOFT-003', 'name' => 'Conflict Resolution', 'category' => 'soft_skill', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'HR-SOFT-004', 'name' => 'Confidentiality', 'category' => 'soft_skill', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 9, 'source_reference' => null],
            ['code' => 'HR-SOFT-005', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[7], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // ============================================================
            // 8. PRODUCT MANAGER (position_id: 8)
            // Code prefix: PM
            // ============================================================

            // Technical Skills
            ['code' => 'PM-TECH-001', 'name' => 'Product Lifecycle Management', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-TECH-002', 'name' => 'Market Research & Analysis', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PM-TECH-003', 'name' => 'User Story Writing', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-TECH-004', 'name' => 'Roadmap Planning', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-TECH-005', 'name' => 'A/B Testing', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PM-TECH-006', 'name' => 'Analytics Tools (Mixpanel, Amplitude)', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PM-TECH-007', 'name' => 'Wireframing Basics', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'PM-TECH-008', 'name' => 'Technical Understanding (IT)', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'PM-TECH-009', 'name' => 'Pricing Strategy', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'PM-TECH-010', 'name' => 'Competitive Analysis', 'category' => 'technical', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'PM-SOFT-001', 'name' => 'Leadership', 'category' => 'soft_skill', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-SOFT-002', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-SOFT-003', 'name' => 'Strategic Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-SOFT-004', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'PM-SOFT-005', 'name' => 'Stakeholder Management', 'category' => 'soft_skill', 'position_id' => $posIds[8], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],

            // ============================================================
            // 9. WEB DEVELOPER (position_id: 9)
            // Code prefix: WD
            // ============================================================

            // Technical Skills
            ['code' => 'WD-TECH-001', 'name' => 'HTML/CSS', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-002', 'name' => 'JavaScript', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-003', 'name' => 'PHP', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-004', 'name' => 'Laravel / Framework PHP', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-005', 'name' => 'MySQL / Database', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-006', 'name' => 'RESTful API', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-007', 'name' => 'Git Version Control', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'WD-TECH-008', 'name' => 'Responsive Design', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-TECH-009', 'name' => 'Web Security (OWASP)', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => 'OWASP Top 10'],
            ['code' => 'WD-TECH-010', 'name' => 'Deployment & Hosting', 'category' => 'technical', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // Soft Skills
            ['code' => 'WD-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'WD-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'WD-SOFT-003', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'WD-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'WD-SOFT-005', 'name' => 'Continuous Learning', 'category' => 'soft_skill', 'position_id' => $posIds[9], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // ============================================================
            // 10. MOBILE DEVELOPER (position_id: 10)
            // Code prefix: MOB
            // ============================================================

            // Technical Skills
            ['code' => 'MOB-TECH-001', 'name' => 'Swift (iOS) / Kotlin (Android)', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-TECH-002', 'name' => 'Flutter / React Native', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-TECH-003', 'name' => 'Mobile UI/UX Principles', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-TECH-004', 'name' => 'REST API Integration', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-TECH-005', 'name' => 'Local Storage & Caching', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-TECH-006', 'name' => 'Push Notifications', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-TECH-007', 'name' => 'App Store Deployment', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-TECH-008', 'name' => 'Testing & Debugging (Mobile)', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-TECH-009', 'name' => 'Performance Optimization (Mobile)', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-TECH-010', 'name' => 'State Management', 'category' => 'technical', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'MOB-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'MOB-SOFT-003', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'MOB-SOFT-005', 'name' => 'Adaptability', 'category' => 'soft_skill', 'position_id' => $posIds[10], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // ============================================================
            // 11. DEVOPS ENGINEER (position_id: 11)
            // Code prefix: DO
            // ============================================================

            // Technical Skills
            ['code' => 'DO-TECH-001', 'name' => 'Linux Administration', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'DO-TECH-002', 'name' => 'Docker & Kubernetes', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => 'CKA Certification'],
            ['code' => 'DO-TECH-003', 'name' => 'CI/CD (Jenkins, GitHub Actions)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'DO-TECH-004', 'name' => 'Cloud Platforms (AWS, GCP, Azure)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'AWS Solutions Architect'],
            ['code' => 'DO-TECH-005', 'name' => 'Infrastructure as Code (Terraform, Ansible)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-TECH-006', 'name' => 'Monitoring & Logging (Prometheus, Grafana)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-TECH-007', 'name' => 'Scripting (Bash, Python)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-TECH-008', 'name' => 'Networking & Security', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-TECH-009', 'name' => 'Database Administration', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DO-TECH-010', 'name' => 'Version Control (Git)', 'category' => 'technical', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'DO-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DO-SOFT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],
            ['code' => 'DO-SOFT-003', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DO-SOFT-005', 'name' => 'Analytical Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[11], 'company_id' => null, 'min_level_required' => 8, 'source_reference' => null],

            // ============================================================
            // 12. DIGITAL MARKETING (position_id: 12)
            // Code prefix: DM
            // ============================================================

            // Technical Skills
            ['code' => 'DM-TECH-001', 'name' => 'SEO & SEM', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => 'Google Digital Marketing Course'],
            ['code' => 'DM-TECH-002', 'name' => 'Social Media Management', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DM-TECH-003', 'name' => 'Content Creation', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DM-TECH-004', 'name' => 'Google Analytics', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => 'Google Analytics Academy'],
            ['code' => 'DM-TECH-005', 'name' => 'Email Marketing Tools', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DM-TECH-006', 'name' => 'CRM Systems', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DM-TECH-007', 'name' => 'Marketing Automation', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DM-TECH-008', 'name' => 'Graphic Design Basics', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'DM-TECH-009', 'name' => 'Video Editing Basics', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'DM-TECH-010', 'name' => 'Copywriting', 'category' => 'technical', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],

            // Soft Skills
            ['code' => 'DM-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DM-SOFT-002', 'name' => 'Creativity', 'category' => 'soft_skill', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'DM-SOFT-003', 'name' => 'Analytical Thinking', 'category' => 'soft_skill', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DM-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'DM-SOFT-005', 'name' => 'Adaptability', 'category' => 'soft_skill', 'position_id' => $posIds[12], 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],

            // ============================================================
            // GENERIC / UMUM (position_id: NULL)
            // Code prefix: GEN
            // Berlaku untuk semua posisi
            // ============================================================

            // Technical Skills Umum
            ['code' => 'GEN-TECH-001', 'name' => 'Microsoft Office Suite', 'category' => 'technical', 'position_id' => null, 'company_id' => null, 'min_level_required' => 5, 'source_reference' => 'Microsoft Office Specialist'],
            ['code' => 'GEN-TECH-002', 'name' => 'Google Workspace', 'category' => 'technical', 'position_id' => null, 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'GEN-TECH-003', 'name' => 'Communication Tools (Slack, Teams)', 'category' => 'technical', 'position_id' => null, 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'GEN-TECH-004', 'name' => 'Basic Data Analysis', 'category' => 'technical', 'position_id' => null, 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],
            ['code' => 'GEN-TECH-005', 'name' => 'Presentation Skills (Tools)', 'category' => 'technical', 'position_id' => null, 'company_id' => null, 'min_level_required' => 5, 'source_reference' => null],

            // Soft Skills Umum
            ['code' => 'GEN-SOFT-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-002', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-003', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-004', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-005', 'name' => 'Adaptability', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-006', 'name' => 'Critical Thinking', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-007', 'name' => 'Leadership', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-008', 'name' => 'Work Ethic', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 7, 'source_reference' => null],
            ['code' => 'GEN-SOFT-009', 'name' => 'Interpersonal Skills', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
            ['code' => 'GEN-SOFT-010', 'name' => 'Stress Management', 'category' => 'soft_skill', 'position_id' => null, 'company_id' => null, 'min_level_required' => 6, 'source_reference' => null],
        ];

        foreach ($competencies as $comp) {
            Competency::updateOrCreate(
                ['code' => $comp['code']],
                array_merge($comp, ['company_id' => null])
            );
        }

        $this->command->info('CompetencySeeder: ' . count($competencies) . ' competencies seeded successfully.');
    }
}
