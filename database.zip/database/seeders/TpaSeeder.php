<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TpaQuestion;
use App\Models\TpaTest;

class TpaSeeder extends Seeder
{
    public function run(): void
    {
        $this->seedQuestions();
        $this->seedDefaultTest();
    }

    protected function seedQuestions()
    {
        // ==================== VERBAL ====================

        // Sinonim
        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'sinonim', 'difficulty' => 'easy',
            'question_text' => 'Pilih kata yang memiliki arti SAMA dengan kata SEDIH:',
            'options' => [
                ['key' => 'A', 'text' => 'Gembira'],
                ['key' => 'B', 'text' => 'Murung'],
                ['key' => 'C', 'text' => 'Marah'],
                ['key' => 'D', 'text' => 'Takut'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Murung memiliki arti yang sama dengan sedih, yaitu perasaan tidak gembira.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'sinonim', 'difficulty' => 'medium',
            'question_text' => 'Pilih kata yang memiliki arti SAMA dengan kata EFISIEN:',
            'options' => [
                ['key' => 'A', 'text' => 'Boros'],
                ['key' => 'B', 'text' => 'Efektif'],
                ['key' => 'C', 'text' => 'Lambat'],
                ['key' => 'D', 'text' => 'Rumit'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Efisien dan efektif keduanya menggambarkan cara melakukan sesuatu dengan baik dan tidak boros.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'sinonim', 'difficulty' => 'hard',
            'question_text' => 'Pilih kata yang memiliki arti SAMA dengan kata KONTEMPLASI:',
            'options' => [
                ['key' => 'A', 'text' => 'Meditasi'],
                ['key' => 'B', 'text' => 'Kekacauan'],
                ['key' => 'C', 'text' => 'Perdebatan'],
                ['key' => 'D', 'text' => 'Perayaan'],
            ],
            'correct_answer' => 'A',
            'explanation' => 'Kontemplasi berarti perenungan mendalam, sama dengan meditasi.',
        ]);

        // Antonim
        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'antonim', 'difficulty' => 'easy',
            'question_text' => 'Pilih kata yang berlawanan dengan kata TINGGI:',
            'options' => [
                ['key' => 'A', 'text' => 'Panjang'],
                ['key' => 'B', 'text' => 'Rendah'],
                ['key' => 'C', 'text' => 'Lebar'],
                ['key' => 'D', 'text' => 'Dalam'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Rendah adalah lawan kata dari tinggi.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'antonim', 'difficulty' => 'medium',
            'question_text' => 'Pilih kata yang berlawanan dengan kata MAKMUR:',
            'options' => [
                ['key' => 'A', 'text' => 'Sejahtera'],
                ['key' => 'B', 'text' => 'Kaya'],
                ['key' => 'C', 'text' => 'Miskin'],
                ['key' => 'D', 'text' => 'Sentosa'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Miskin adalah lawan kata dari makmur.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'antonim', 'difficulty' => 'hard',
            'question_text' => 'Pilih kata yang berlawanan dengan kata DESTRUKTIF:',
            'options' => [
                ['key' => 'A', 'text' => 'Agresif'],
                ['key' => 'B', 'text' => 'Konstruktif'],
                ['key' => 'C', 'text' => 'Pasif'],
                ['key' => 'D', 'text' => 'Defensif'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Konstruktif (membangun) adalah lawan kata dari destruktif (menghancurkan).',
        ]);

        // Analogi
        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'analogi', 'difficulty' => 'easy',
            'question_text' => 'Dokter : Rumah Sakit = Guru : ?',
            'options' => [
                ['key' => 'A', 'text' => 'Murid'],
                ['key' => 'B', 'text' => 'Sekolah'],
                ['key' => 'C', 'text' => 'Buku'],
                ['key' => 'D', 'text' => 'Pena'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Dokter bekerja di Rumah Sakit, maka Guru bekerja di Sekolah.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'analogi', 'difficulty' => 'medium',
            'question_text' => 'Mata : Melihat = Telinga : ?',
            'options' => [
                ['key' => 'A', 'text' => 'Suara'],
                ['key' => 'B', 'text' => 'Mendengar'],
                ['key' => 'C', 'text' => 'Kepala'],
                ['key' => 'D', 'text' => 'Musik'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Mata berfungsi untuk Melihat, maka Telinga berfungsi untuk Mendengar.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'analogi', 'difficulty' => 'hard',
            'question_text' => 'Epilog : Akhir = Prolog : ?',
            'options' => [
                ['key' => 'A', 'text' => 'Tengah'],
                ['key' => 'B', 'text' => 'Awal'],
                ['key' => 'C', 'text' => 'Cerita'],
                ['key' => 'D', 'text' => 'Buku'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Epilog adalah bagian penutup (akhir), maka Prolog adalah bagian pembuka (awal).',
        ]);

        // Pengelompokan Kata
        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'pengelompokan', 'difficulty' => 'easy',
            'question_text' => 'Pilih kata yang TIDAK termasuk dalam kelompok:',
            'options' => [
                ['key' => 'A', 'text' => 'Apel'],
                ['key' => 'B', 'text' => 'Mangga'],
                ['key' => 'C', 'text' => 'Jeruk'],
                ['key' => 'D', 'text' => 'Wortel'],
            ],
            'correct_answer' => 'D',
            'explanation' => 'Apel, Mangga, dan Jeruk adalah buah-buahan. Wortel adalah sayuran.',
        ]);

        // ==================== NUMERIK ====================

        // Aritmetik
        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'aritmetik', 'difficulty' => 'easy',
            'question_text' => 'Hasil dari 125 x 8 : 5 adalah...',
            'options' => [
                ['key' => 'A', 'text' => '100'],
                ['key' => 'B', 'text' => '150'],
                ['key' => 'C', 'text' => '200'],
                ['key' => 'D', 'text' => '250'],
            ],
            'correct_answer' => 'C',
            'explanation' => '125 x 8 = 1000. 1000 : 5 = 200.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'aritmetik', 'difficulty' => 'medium',
            'question_text' => 'Jika 40% dari sebuah bilangan adalah 60, maka bilangan tersebut adalah...',
            'options' => [
                ['key' => 'A', 'text' => '100'],
                ['key' => 'B', 'text' => '120'],
                ['key' => 'C', 'text' => '140'],
                ['key' => 'D', 'text' => '150'],
            ],
            'correct_answer' => 'D',
            'explanation' => '40% x = 60. x = 60 / 0.4 = 150.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'aritmetik', 'difficulty' => 'hard',
            'question_text' => 'Seorang pedagang membeli barang seharga Rp 800.000 dan menjual dengan kerugian 15%. Berapa harga jual?',
            'options' => [
                ['key' => 'A', 'text' => 'Rp 680.000'],
                ['key' => 'B', 'text' => 'Rp 700.000'],
                ['key' => 'C', 'text' => 'Rp 720.000'],
                ['key' => 'D', 'text' => 'Rp 750.000'],
            ],
            'correct_answer' => 'A',
            'explanation' => 'Kerugian = 15% x 800.000 = 120.000. Harga jual = 800.000 - 120.000 = 680.000.',
        ]);

        // Seri Angka
        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'seri_angka', 'difficulty' => 'easy',
            'question_text' => 'Lanjutkan deret berikut: 2, 4, 8, 16, ...',
            'options' => [
                ['key' => 'A', 'text' => '24'],
                ['key' => 'B', 'text' => '28'],
                ['key' => 'C', 'text' => '32'],
                ['key' => 'D', 'text' => '36'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Pola: setiap bilangan dikali 2. 16 x 2 = 32.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'seri_angka', 'difficulty' => 'medium',
            'question_text' => 'Lanjutkan deret berikut: 3, 6, 12, 24, 48, ...',
            'options' => [
                ['key' => 'A', 'text' => '72'],
                ['key' => 'B', 'text' => '84'],
                ['key' => 'C', 'text' => '96'],
                ['key' => 'D', 'text' => '108'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Pola: setiap bilangan dikali 2. 48 x 2 = 96.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'seri_angka', 'difficulty' => 'hard',
            'question_text' => 'Lanjutkan deret berikut: 1, 1, 2, 3, 5, 8, ...',
            'options' => [
                ['key' => 'A', 'text' => '10'],
                ['key' => 'B', 'text' => '11'],
                ['key' => 'C', 'text' => '12'],
                ['key' => 'D', 'text' => '13'],
            ],
            'correct_answer' => 'D',
            'explanation' => 'Ini adalah deret Fibonacci: 1+1=2, 1+2=3, 2+3=5, 3+5=8, 5+8=13.',
        ]);

        // Soal Cerita
        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'soal_cerita', 'difficulty' => 'medium',
            'question_text' => 'Sebuah mobil menempuh jarak 240 km dalam 3 jam. Berapa kecepatan rata-rata mobil tersebut?',
            'options' => [
                ['key' => 'A', 'text' => '60 km/jam'],
                ['key' => 'B', 'text' => '70 km/jam'],
                ['key' => 'C', 'text' => '80 km/jam'],
                ['key' => 'D', 'text' => '90 km/jam'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Kecepatan = Jarak / Waktu = 240 / 3 = 80 km/jam.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'soal_cerita', 'difficulty' => 'hard',
            'question_text' => 'Andi memiliki uang 2/3 dari uang Budi. Jika uang Budi Rp 450.000, berapa total uang mereka?',
            'options' => [
                ['key' => 'A', 'text' => 'Rp 650.000'],
                ['key' => 'B', 'text' => 'Rp 700.000'],
                ['key' => 'C', 'text' => 'Rp 750.000'],
                ['key' => 'D', 'text' => 'Rp 800.000'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Uang Andi = 2/3 x 450.000 = 300.000. Total = 450.000 + 300.000 = 750.000.',
        ]);

        // ==================== LOGIKA ====================

        // Silogisme
        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'silogisme', 'difficulty' => 'easy',
            'question_text' => "Premis 1: Semua mahasiswa rajin.\nPremis 2: Budi adalah mahasiswa.\nKesimpulan:",
            'options' => [
                ['key' => 'A', 'text' => 'Budi rajin'],
                ['key' => 'B', 'text' => 'Budi tidak rajin'],
                ['key' => 'C', 'text' => 'Budi mungkin rajin'],
                ['key' => 'D', 'text' => 'Tidak dapat disimpulkan'],
            ],
            'correct_answer' => 'A',
            'explanation' => 'Karena semua mahasiswa rajin dan Budi adalah mahasiswa, maka Budi rajin.',
        ]);

        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'silogisme', 'difficulty' => 'medium',
            'question_text' => "Premis 1: Beberapa kucing berwarna hitam.\nPremis 2: Semua hewan berwarna hitam sulit terlihat malam hari.\nKesimpulan yang BENAR:",
            'options' => [
                ['key' => 'A', 'text' => 'Semua kucing sulit terlihat malam hari'],
                ['key' => 'B', 'text' => 'Beberapa kucing sulit terlihat malam hari'],
                ['key' => 'C', 'text' => 'Tidak ada kucing yang sulit terlihat malam hari'],
                ['key' => 'D', 'text' => 'Tidak dapat disimpulkan'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Karena hanya BEBERAPA kucing berwarna hitam, maka hanya BEBERAPA kucing yang sulit terlihat.',
        ]);

        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'silogisme', 'difficulty' => 'hard',
            'question_text' => "Premis 1: Semua programmer menggunakan komputer.\nPremis 2: Tidak ada seniman yang menggunakan komputer.\nKesimpulan yang BENAR:",
            'options' => [
                ['key' => 'A', 'text' => 'Semua programmer adalah seniman'],
                ['key' => 'B', 'text' => 'Beberapa programmer adalah seniman'],
                ['key' => 'C', 'text' => 'Tidak ada programmer yang seniman'],
                ['key' => 'D', 'text' => 'Tidak dapat disimpulkan'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Karena semua programmer pakai komputer dan tidak ada seniman pakai komputer, maka tidak ada programmer yang seniman.',
        ]);

        // Logika Deduktif
        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'deduktif', 'difficulty' => 'easy',
            'question_text' => "Jika hujan, maka jalan basah. Saat ini jalan basah. Kesimpulan yang PALING TEPAT:",
            'options' => [
                ['key' => 'A', 'text' => 'Pasti hujan'],
                ['key' => 'B', 'text' => 'Pasti tidak hujan'],
                ['key' => 'C', 'text' => 'Mungkin hujan'],
                ['key' => 'D', 'text' => 'Tidak ada hubungannya'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Jalan basah bisa karena hujan atau penyebab lain. Kita tidak bisa memastikan hanya dari satu arah implikasi.',
        ]);

        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'deduktif', 'difficulty' => 'medium',
            'question_text' => "Jika A maka B. Jika B maka C. Jika C maka D. Saat ini D BENAR. Apa yang pasti benar?",
            'options' => [
                ['key' => 'A', 'text' => 'A benar'],
                ['key' => 'B', 'text' => 'B benar'],
                ['key' => 'C', 'text' => 'C benar'],
                ['key' => 'D', 'text' => 'Tidak ada yang pasti benar'],
            ],
            'correct_answer' => 'D',
            'explanation' => 'Implikasi hanya berlaku satu arah (A→B→C→D). D benar tidak berarti C, B, atau A benar.',
        ]);

        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'deduktif', 'difficulty' => 'hard',
            'question_text' => "Jika hari Minggu maka toko tutup. Jika toko tutup maka tidak bisa belanja. Saat ini bisa belanja. Apa yang pasti benar?",
            'options' => [
                ['key' => 'A', 'text' => 'Hari ini Minggu'],
                ['key' => 'B', 'text' => 'Hari ini bukan Minggu'],
                ['key' => 'C', 'text' => 'Toko buka'],
                ['key' => 'D', 'text' => 'B dan C benar'],
            ],
            'correct_answer' => 'D',
            'explanation' => 'Jika bisa belanja → toko buka (kontra dari tidak bisa belanja). Jika toko buka → bukan Minggu (kontra dari toko tutup).',
        ]);

        // Analitis
        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'analitis', 'difficulty' => 'medium',
            'question_text' => "Lima orang (A, B, C, D, E) duduk berjajar. A di sebelah B. C di sebelah kanan D. B di sebelah kiri C. Siapa yang duduk paling kanan?",
            'options' => [
                ['key' => 'A', 'text' => 'A'],
                ['key' => 'B', 'text' => 'C'],
                ['key' => 'C', 'text' => 'D'],
                ['key' => 'D', 'text' => 'E'],
            ],
            'correct_answer' => 'D',
            'explanation' => 'Urutan: A-B-C-D-E (atau variasi dengan E di ujung). Karena E tidak disebutkan dalam aturan, E berada di posisi yang tidak terikat, yaitu paling kanan.',
        ]);

        // ==================== SPASIAL ====================

        // Pola Gambar
        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'pola_gambar', 'difficulty' => 'easy',
            'question_text' => "Perhatikan pola berikut:\n○, △, □, ○, △, □, ○, ...\nSimbol selanjutnya adalah:",
            'options' => [
                ['key' => 'A', 'text' => '○'],
                ['key' => 'B', 'text' => '△'],
                ['key' => 'C', 'text' => '□'],
                ['key' => 'D', 'text' => '◇'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Pola berulang: ○, △, □. Setelah ○, simbol berikutnya adalah △.',
        ]);

        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'pola_gambar', 'difficulty' => 'medium',
            'question_text' => "Perhatikan pola berikut:\n1, 1, 2, 3, 5, 8, 13, ...\nAngka selanjutnya adalah:",
            'options' => [
                ['key' => 'A', 'text' => '18'],
                ['key' => 'B', 'text' => '20'],
                ['key' => 'C', 'text' => '21'],
                ['key' => 'D', 'text' => '24'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Ini deret Fibonacci: 5+8=13, 8+13=21.',
        ]);

        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'rotasi', 'difficulty' => 'medium',
            'question_text' => "Jika segitiga dirotasi 90° searah jarum jam, maka:\n- Puncak segitiga yang awalnya di atas akan berada di...",
            'options' => [
                ['key' => 'A', 'text' => 'Kanan'],
                ['key' => 'B', 'text' => 'Kiri'],
                ['key' => 'C', 'text' => 'Bawah'],
                ['key' => 'D', 'text' => 'Atas'],
            ],
            'correct_answer' => 'A',
            'explanation' => 'Rotasi 90° searah jarum jam: atas → kanan → bawah → kiri.',
        ]);

        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'bayangan_cermin', 'difficulty' => 'easy',
            'question_text' => "Jika huruf 'b' diletakkan di depan cermin datar, bayangan yang terlihat adalah:",
            'options' => [
                ['key' => 'A', 'text' => 'b'],
                ['key' => 'B', 'text' => 'd'],
                ['key' => 'C', 'text' => 'p'],
                ['key' => 'D', 'text' => 'q'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Cermin datar membalik secara horizontal. Huruf "b" menjadi "d".',
        ]);

        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'deret_gambar', 'difficulty' => 'hard',
            'question_text' => "Perhatikan deret:\n△, △△, △△△, △△△△, ...\nPola ke-10 memiliki berapa segitiga?",
            'options' => [
                ['key' => 'A', 'text' => '8'],
                ['key' => 'B', 'text' => '9'],
                ['key' => 'C', 'text' => '10'],
                ['key' => 'D', 'text' => '11'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Pola: ke-n memiliki n segitiga. Pola ke-10 memiliki 10 segitiga.',
        ]);

        // Tambahan soal untuk variasi
        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'pola_gambar', 'difficulty' => 'hard',
            'question_text' => "Perhatikan matriks 3x3:\n2, 4, 6\n8, 10, 12\n14, 16, ?\nAngka yang tepat untuk mengisi tanda tanya adalah:",
            'options' => [
                ['key' => 'A', 'text' => '17'],
                ['key' => 'B', 'text' => '18'],
                ['key' => 'C', 'text' => '20'],
                ['key' => 'D', 'text' => '22'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Pola: bilangan genap berurutan. 2,4,6,8,10,12,14,16,18.',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'seri_angka', 'difficulty' => 'medium',
            'question_text' => "Lanjutkan deret berikut: 1, 4, 9, 16, 25, ...",
            'options' => [
                ['key' => 'A', 'text' => '30'],
                ['key' => 'B', 'text' => '33'],
                ['key' => 'C', 'text' => '36'],
                ['key' => 'D', 'text' => '49'],
            ],
            'correct_answer' => 'C',
            'explanation' => 'Pola: bilangan kuadrat. 1², 2², 3², 4², 5², 6² = 36.',
        ]);

        TpaQuestion::create([
            'category' => 'logika', 'subcategory' => 'analitis', 'difficulty' => 'easy',
            'question_text' => "Jika semua mawar adalah bunga, dan semua bunga indah, maka...",
            'options' => [
                ['key' => 'A', 'text' => 'Semua mawar indah'],
                ['key' => 'B', 'text' => 'Beberapa mawar indah'],
                ['key' => 'C', 'text' => 'Tidak ada mawar yang indah'],
                ['key' => 'D', 'text' => 'Tidak dapat disimpulkan'],
            ],
            'correct_answer' => 'A',
            'explanation' => 'Semua mawar → bunga → indah. Maka semua mawar indah.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'sinonim', 'difficulty' => 'medium',
            'question_text' => "Pilih kata yang memiliki arti SAMA dengan kata PRODUKTIF:",
            'options' => [
                ['key' => 'A', 'text' => 'Malas'],
                ['key' => 'B', 'text' => 'Subur'],
                ['key' => 'C', 'text' => 'Lambat'],
                ['key' => 'D', 'text' => 'Pasif'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Produktif dan subur keduanya menggambarkan kemampuan menghasilkan sesuatu dengan baik.',
        ]);

        TpaQuestion::create([
            'category' => 'verbal', 'subcategory' => 'antonim', 'difficulty' => 'medium',
            'question_text' => "Pilih kata yang berlawanan dengan kata OPTIMIS:",
            'options' => [
                ['key' => 'A', 'text' => 'Realistis'],
                ['key' => 'B', 'text' => 'Pesimis'],
                ['key' => 'C', 'text' => 'Pragmatis'],
                ['key' => 'D', 'text' => 'Idealis'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Pesimis (melihat sisi negatif) adalah lawan kata dari optimis (melihat sisi positif).',
        ]);

        TpaQuestion::create([
            'category' => 'numerik', 'subcategory' => 'aritmetik', 'difficulty' => 'medium',
            'question_text' => "Hasil dari 15% dari 200 adalah...",
            'options' => [
                ['key' => 'A', 'text' => '20'],
                ['key' => 'B', 'text' => '25'],
                ['key' => 'C', 'text' => '30'],
                ['key' => 'D', 'text' => '35'],
            ],
            'correct_answer' => 'C',
            'explanation' => '15% x 200 = 0.15 x 200 = 30.',
        ]);

        TpaQuestion::create([
            'category' => 'spasial', 'subcategory' => 'rotasi', 'difficulty' => 'easy',
            'question_text' => "Jika huruf 'R' diputar 180°, huruf yang mirip dengan hasil rotasi adalah:",
            'options' => [
                ['key' => 'A', 'text' => 'R'],
                ['key' => 'B', 'text' => 'Я (R terbalik)'],
                ['key' => 'C', 'text' => 'P'],
                ['key' => 'D', 'text' => 'B'],
            ],
            'correct_answer' => 'B',
            'explanation' => 'Rotasi 180° membalik huruf secara vertikal dan horizontal.',
        ]);
    }

    protected function seedDefaultTest()
    {
        // Buat tes TPA default (template global, tidak terikat lowongan)
        TpaTest::create([
            'job_listing_id' => null,
            'created_by' => 1, // admin
            'title' => 'Tes Potensi Akademik - Standar',
            'description' => 'Tes TPA standar untuk mengukur kemampuan verbal, numerik, logika, dan spasial. Terdiri dari 40 soal dengan waktu 60 menit.',
            'total_questions' => 40,
            'time_limit_minutes' => 60,
            'verbal_count' => 10,
            'numerik_count' => 10,
            'logika_count' => 10,
            'spasial_count' => 10,
            'passing_score' => 60,
            'verbal_weight' => 30,
            'numerik_weight' => 30,
            'logika_weight' => 20,
            'spasial_weight' => 20,
            'randomize_questions' => true,
            'randomize_options' => true,
            'show_result_after' => true,
        ]);
    }
}
