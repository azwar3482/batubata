<?php

namespace Database\Seeders;

use App\Models\JobListing;
use App\Models\User;
use Illuminate\Database\Seeder;

class GeoLocationSeeder extends Seeder
{
    /**
     * Seed koordinat GPS dummy untuk User Job Seeker dan Job Listings.
     * Data koordinat ini merepresentasikan kota-kota besar di Indonesia.
     */
    public function run(): void
    {
        // Peta Koordinat Kota-Kota Besar Indonesia (Dummy Data)
        $cityCoordinates = [
            'Jakarta'       => ['lat' => -6.2088,  'lng' => 106.8456],
            'Jakarta Selatan' => ['lat' => -6.2615, 'lng' => 106.8106],
            'Jakarta Utara'   => ['lat' => -6.1214, 'lng' => 106.7742],
            'Bandung'       => ['lat' => -6.9147,  'lng' => 107.6098],
            'Surabaya'      => ['lat' => -7.2575,  'lng' => 112.7521],
            'Yogyakarta'    => ['lat' => -7.7956,  'lng' => 110.3695],
            'Medan'         => ['lat' => 3.5952,   'lng' => 98.6722],
            'Semarang'      => ['lat' => -6.9903,  'lng' => 110.4229],
            'Makassar'      => ['lat' => -5.1477,  'lng' => 119.4327],
            'Bali'          => ['lat' => -8.3405,  'lng' => 115.0920],
            'Depok'         => ['lat' => -6.4025,  'lng' => 106.7942],
            'Tangerang'     => ['lat' => -6.1702,  'lng' => 106.6402],
            'Bekasi'        => ['lat' => -6.2349,  'lng' => 106.9896],
            'Bogor'         => ['lat' => -6.5971,  'lng' => 106.8060],
        ];

        // Update koordinat dummy untuk semua User yang belum punya lokasi
        $users = User::whereNull('latitude')->whereNull('longitude')->get();
        foreach ($users as $index => $user) {
            $cities = array_values($cityCoordinates);
            $city = $cities[$index % count($cities)]; // Rotasi kota
            $user->update([
                'latitude'  => $city['lat'] + (rand(-50, 50) / 1000), // Sedikit variasi acak
                'longitude' => $city['lng'] + (rand(-50, 50) / 1000),
                'address'   => array_keys($cityCoordinates)[$index % count($cityCoordinates)],
            ]);
        }

        // Update koordinat dummy untuk semua Job Listings yang belum punya lokasi
        $jobs = JobListing::whereNull('latitude')->whereNull('longitude')->get();
        foreach ($jobs as $index => $job) {
            // Ambil koordinat berdasarkan nama kota di kolom location (jika ada)
            $jobCity = null;
            foreach ($cityCoordinates as $cityName => $coords) {
                if (str_contains(strtolower($job->location ?? ''), strtolower($cityName))) {
                    $jobCity = $coords;
                    break;
                }
            }

            // Jika tidak ditemukan, rotasi kota secara acak
            if (!$jobCity) {
                $cities = array_values($cityCoordinates);
                $jobCity = $cities[$index % count($cities)];
            }

            $job->update([
                'latitude'  => $jobCity['lat'] + (rand(-30, 30) / 1000),
                'longitude' => $jobCity['lng'] + (rand(-30, 30) / 1000),
            ]);
        }

        $this->command->info('✅ GeoLocationSeeder: Koordinat GPS berhasil di-seed untuk ' . $users->count() . ' user dan ' . $jobs->count() . ' lowongan!');
    }
}
