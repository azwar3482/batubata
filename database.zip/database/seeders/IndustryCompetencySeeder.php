<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IndustryCompetencySeeder extends Seeder
{
    public function run(): void
    {
        // Get companies
        $companies = DB::table('companies')->select('id', 'name', 'industry')->get();

        foreach ($companies as $company) {
            $competencies = $this->getCompetenciesForIndustry($company->industry);

            foreach ($competencies as $comp) {
                $exists = DB::table('competencies')
                    ->where('code', $comp['code'])
                    ->where('company_id', $company->id)
                    ->exists();

                if (!$exists) {
                    DB::table('competencies')->insert([
                        'code'               => $comp['code'],
                        'name'               => $comp['name'],
                        'category'           => $comp['category'],
                        'position_id'        => $comp['position_id'],
                        'company_id'         => $company->id,
                        'min_level_required' => $comp['min_level'],
                        'source_reference'   => $comp['source'] ?? null,
                        'created_at'         => now(),
                        'updated_at'         => now(),
                    ]);
                }
            }
        }
    }

    private function getCompetenciesForIndustry(string $industry): array
    {
        // Position IDs mapping
        $positions = DB::table('positions')->pluck('id', 'name');

        switch ($industry) {
            case 'Software House':
                return [
                    ['code' => 'TC-SH-001', 'name' => 'Laravel / PHP', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-002', 'name' => 'React.js / Vue.js', 'category' => 'technical', 'position_id' => $positions['Frontend Developer'] ?? 3, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-003', 'name' => 'RESTful API Design', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-004', 'name' => 'Git & CI/CD', 'category' => 'technical', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-005', 'name' => 'Docker & Containerization', 'category' => 'technical', 'position_id' => $positions['DevOps Engineer'] ?? 11, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-006', 'name' => 'Database Design (MySQL/PostgreSQL)', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-007', 'name' => 'Agile/Scrum', 'category' => 'technical', 'position_id' => $positions['Project Manager'] ?? 6, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-008', 'name' => 'Unit Testing', 'category' => 'technical', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-009', 'name' => 'Code Review & Best Practices', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-SH-010', 'name' => 'Microservices Architecture', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'SS-SH-001', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-SH-002', 'name' => 'Team Collaboration', 'category' => 'soft_skill', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-SH-003', 'name' => 'Continuous Learning', 'category' => 'soft_skill', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-SH-004', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $positions['Project Manager'] ?? 6, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-SH-005', 'name' => 'Time Management', 'category' => 'soft_skill', 'position_id' => $positions['Web Developer'] ?? 9, 'min_level' => 6, 'source' => 'Internal Standard'],
                ];

            case 'Keuangan':
                return [
                    ['code' => 'TC-BN-001', 'name' => 'Financial Analysis', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 8, 'source' => 'OJK Standard'],
                    ['code' => 'TC-BN-002', 'name' => 'Risk Management', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'OJK Standard'],
                    ['code' => 'TC-BN-003', 'name' => 'SQL & Database', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-004', 'name' => 'Excel & Spreadsheet Advanced', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-005', 'name' => 'Regulatory Compliance (OJK)', 'category' => 'technical', 'position_id' => $positions['HR Specialist'] ?? 7, 'min_level' => 7, 'source' => 'OJK Standard'],
                    ['code' => 'TC-BN-006', 'name' => 'Banking Operations', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-007', 'name' => 'Fraud Detection & Prevention', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-008', 'name' => 'Customer Relationship Management', 'category' => 'technical', 'position_id' => $positions['HR Specialist'] ?? 7, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-009', 'name' => 'Data Visualization (Tableau/Power BI)', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-BN-010', 'name' => 'Anti-Money Laundering (AML)', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'OJK Standard'],
                    ['code' => 'SS-BN-001', 'name' => 'Integrity & Ethics', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 9, 'source' => 'Internal Standard'],
                    ['code' => 'SS-BN-002', 'name' => 'Attention to Detail', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-BN-003', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $positions['HR Specialist'] ?? 7, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-BN-004', 'name' => 'Analytical Thinking', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-BN-005', 'name' => 'Confidentiality', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 9, 'source' => 'Internal Standard'],
                ];

            case 'E-Commerce':
                return [
                    ['code' => 'TC-EC-001', 'name' => 'Digital Marketing', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-002', 'name' => 'SEO & SEM', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-003', 'name' => 'Google Analytics & Tag Manager', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-004', 'name' => 'SQL for Data Analysis', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-005', 'name' => 'Python for Automation', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-006', 'name' => 'React.js / Next.js', 'category' => 'technical', 'position_id' => $positions['Frontend Developer'] ?? 3, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-007', 'name' => 'Payment Gateway Integration', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-008', 'name' => 'A/B Testing & CRO', 'category' => 'technical', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-009', 'name' => 'Supply Chain Management', 'category' => 'technical', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-EC-010', 'name' => 'UX Research & Design', 'category' => 'technical', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-EC-001', 'name' => 'Customer Obsession', 'category' => 'soft_skill', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-EC-002', 'name' => 'Data-Driven Thinking', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-EC-003', 'name' => 'Agility & Adaptability', 'category' => 'soft_skill', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-EC-004', 'name' => 'Creativity', 'category' => 'soft_skill', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-EC-005', 'name' => 'Cross-Functional Collaboration', 'category' => 'soft_skill', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                ];

            case 'Digital Marketing':
                return [
                    ['code' => 'TC-CA-001', 'name' => 'SEO & Content Strategy', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-002', 'name' => 'Social Media Management', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-003', 'name' => 'Google Ads & Facebook Ads', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-004', 'name' => 'Copywriting & Content Creation', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-005', 'name' => 'Figma & Adobe Creative Suite', 'category' => 'technical', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-006', 'name' => 'Google Analytics & Data Studio', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-007', 'name' => 'Email Marketing Automation', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-008', 'name' => 'Influencer Marketing', 'category' => 'technical', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-009', 'name' => 'Video Production & Editing', 'category' => 'technical', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-CA-010', 'name' => 'Brand Strategy', 'category' => 'technical', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-CA-001', 'name' => 'Creativity & Innovation', 'category' => 'soft_skill', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 9, 'source' => 'Internal Standard'],
                    ['code' => 'SS-CA-002', 'name' => 'Storytelling', 'category' => 'soft_skill', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-CA-003', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-CA-004', 'name' => 'Trend Awareness', 'category' => 'soft_skill', 'position_id' => $positions['Digital Marketing Specialist'] ?? 1, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-CA-005', 'name' => 'Project Management', 'category' => 'soft_skill', 'position_id' => $positions['Project Manager'] ?? 6, 'min_level' => 7, 'source' => 'Internal Standard'],
                ];

            case 'Financial Technology':
                return [
                    ['code' => 'TC-FT-001', 'name' => 'Blockchain & DLT', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-002', 'name' => 'API Security (OAuth, JWT)', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-003', 'name' => 'Python / Go for Backend', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-004', 'name' => 'React Native / Flutter', 'category' => 'technical', 'position_id' => $positions['Mobile Developer'] ?? 10, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-005', 'name' => 'Data Encryption & Security', 'category' => 'technical', 'position_id' => $positions['DevOps Engineer'] ?? 11, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-006', 'name' => 'Machine Learning for Fraud Detection', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-007', 'name' => 'Payment Systems Integration', 'category' => 'technical', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-008', 'name' => 'Cloud Infrastructure (AWS/GCP)', 'category' => 'technical', 'position_id' => $positions['DevOps Engineer'] ?? 11, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'TC-FT-009', 'name' => 'Regulatory Compliance (OJK)', 'category' => 'technical', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'OJK Standard'],
                    ['code' => 'TC-FT-010', 'name' => 'UI/UX for Financial Apps', 'category' => 'technical', 'position_id' => $positions['UI/UX Designer'] ?? 5, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-FT-001', 'name' => 'Security Mindset', 'category' => 'soft_skill', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 9, 'source' => 'Internal Standard'],
                    ['code' => 'SS-FT-002', 'name' => 'Problem Solving', 'category' => 'soft_skill', 'position_id' => $positions['Backend Developer'] ?? 4, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-FT-003', 'name' => 'Attention to Detail', 'category' => 'soft_skill', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 8, 'source' => 'Internal Standard'],
                    ['code' => 'SS-FT-004', 'name' => 'Innovation & Continuous Improvement', 'category' => 'soft_skill', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                    ['code' => 'SS-FT-005', 'name' => 'Cross-Team Collaboration', 'category' => 'soft_skill', 'position_id' => $positions['Product Manager'] ?? 8, 'min_level' => 7, 'source' => 'Internal Standard'],
                ];

            default:
                return [
                    ['code' => 'TC-DEF-001', 'name' => 'Microsoft Office', 'category' => 'technical', 'position_id' => null, 'min_level' => 5, 'source' => 'Internal Standard'],
                    ['code' => 'TC-DEF-002', 'name' => 'Data Analysis', 'category' => 'technical', 'position_id' => $positions['Data Analyst'] ?? 2, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'TC-DEF-003', 'name' => 'Project Management', 'category' => 'technical', 'position_id' => $positions['Project Manager'] ?? 6, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'SS-DEF-001', 'name' => 'Communication', 'category' => 'soft_skill', 'position_id' => null, 'min_level' => 6, 'source' => 'Internal Standard'],
                    ['code' => 'SS-DEF-002', 'name' => 'Teamwork', 'category' => 'soft_skill', 'position_id' => null, 'min_level' => 6, 'source' => 'Internal Standard'],
                ];
        }
    }
}
