<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class EducationCourseSeeder extends Seeder
{
    public function run(): void
    {
        // ============================================================
        // CREATE EDUCATION USERS
        // ============================================================

        $education1 = DB::table('users')->where('email', 'education@batubata.test')->value('id');
        if (!$education1) {
            $education1 = DB::table('users')->insertGetId([
                'name'              => 'Universitas Teknologi Digital',
                'email'             => 'education@batubata.test',
                'password'          => Hash::make('password'),
                'role'              => 'education',
                'email_verified_at' => now(),
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);
        }

        $education2 = DB::table('users')->where('email', 'education2@batubata.test')->value('id');
        if (!$education2) {
            $education2 = DB::table('users')->insertGetId([
                'name'              => 'Akademi Digital Indonesia',
                'email'             => 'education2@batubata.test',
                'password'          => Hash::make('password'),
                'role'              => 'education',
                'email_verified_at' => now(),
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);
        }

        // ============================================================
        // GET COMPETENCY IDs
        // ============================================================

        $laravelCompId = DB::table('competencies')->where('name', 'Laravel')->value('id');
        $phpCompId = DB::table('competencies')->where('name', 'PHP')->value('id');
        $htmlCompId = DB::table('competencies')->where('name', 'HTML & CSS')->value('id');
        $jsCompId = DB::table('competencies')->where('name', 'JavaScript')->value('id');
        $reactCompId = DB::table('competencies')->where('name', 'React.js')->value('id');
        $pythonCompId = DB::table('competencies')->where('name', 'Python')->value('id');
        $sqlCompId = DB::table('competencies')->where('name', 'SQL')->value('id');
        $figmaCompId = DB::table('competencies')->where('name', 'Figma')->value('id');
        $flutterCompId = DB::table('competencies')->where('name', 'Flutter')->value('id');
        $dockerCompId = DB::table('competencies')->where('name', 'Docker')->value('id');
        $commCompId = DB::table('competencies')->where('name', 'Komunikasi')->value('id');

        // ============================================================
        // EDUCATION 1 COURSES
        // ============================================================

        $course1A = DB::table('teacher_courses')->where('teacher_id', $education1)->where('title', 'Fullstack Web Development Bootcamp')->value('id');
        $course1A_is_new = false;
        if (!$course1A) {
            $course1A = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education1,
                'competency_id'  => $htmlCompId,
                'title'          => 'Fullstack Web Development Bootcamp',
                'description'    => 'Bootcamp intensif selama 80 jam untuk menjadi fullstack web developer. Kurikulum dirancang bersama industri, mencakup frontend (HTML, CSS, JavaScript, React), backend (Node.js/PHP, Express/Laravel), database (MySQL, MongoDB), dan deployment. Termasuk project akhir dan career coaching.',
                'objectives'     => "1. Menguasai HTML, CSS, dan JavaScript ES6+\n2. Mampu membangun frontend dengan React.js\n3. Membuat RESTful API dengan Node.js atau PHP/Laravel\n4. Mengelola database SQL dan NoSQL\n5. Deploy aplikasi ke cloud (Vercel, Railway, AWS)\n6. Membuat portfolio profesional dan CV developer",
                'category'       => 'technical',
                'level'          => 'intermediate',
                'duration_hours' => 80,
                'status'         => 'published',
                'price'          => 450000,
                'is_free'        => false,
                'tags'           => json_encode(['Fullstack', 'Bootcamp', 'React', 'Node.js', 'Laravel', 'Career']),
                'max_students'   => 25,
                'rating'         => 4.9,
                'total_enrolled' => 67,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course1A_is_new = true;
        }

        $course1B = DB::table('teacher_courses')->where('teacher_id', $education1)->where('title', 'Career Preparation & Soft Skills untuk Fresh Graduate')->value('id');
        $course1B_is_new = false;
        if (!$course1B) {
            $course1B = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education1,
                'competency_id'  => $commCompId,
                'title'          => 'Career Preparation & Soft Skills untuk Fresh Graduate',
                'description'    => 'Kursus persiapan karir untuk fresh graduate dan job seeker. Pelajari cara membuat CV yang ATS-friendly, teknik interview STAR, negosiasi gaji, personal branding di LinkedIn, dan soft skills yang dibutuhkan di dunia kerja modern.',
                'objectives'     => "1. Membuat CV dan surat lamaran yang lolos ATS\n2. Menguasai teknik interview STAR (Situation, Task, Action, Result)\n3. Membangun personal branding yang kuat di LinkedIn\n4. Memahami etika dan komunikasi profesional\n5. Mampu bernegosiasi gaji dan benefit\n6. Mempersiapkan portofolio dan dokumen pendukung karir",
                'category'       => 'soft_skill',
                'level'          => 'beginner',
                'duration_hours' => 20,
                'status'         => 'published',
                'price'          => 0,
                'is_free'        => true,
                'tags'           => json_encode(['Career', 'Soft Skills', 'CV', 'Interview', 'LinkedIn', 'Fresh Graduate']),
                'max_students'   => 50,
                'rating'         => 4.8,
                'total_enrolled' => 89,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course1B_is_new = true;
        }

        $course1C = DB::table('teacher_courses')->where('teacher_id', $education1)->where('title', 'Data Science Fundamentals dengan Python')->value('id');
        $course1C_is_new = false;
        if (!$course1C) {
            $course1C = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education1,
                'competency_id'  => $pythonCompId,
                'title'          => 'Data Science Fundamentals dengan Python',
                'description'    => 'Kursus pengantar data science menggunakan Python. Pelajari analisis data dengan Pandas, visualisasi dengan Matplotlib dan Seaborn, serta pengenalan machine learning. Cocok untuk pemula yang ingin memulai karir di bidang data.',
                'objectives'     => "1. Menguasai Python untuk analisis data\n2. Mampu membersihkan dan mentransformasi data\n3. Membuat visualisasi data yang informatif\n4. Memahami statistik dasar untuk data science\n5. Mengenal algoritma machine learning dasar\n6. Mengerjakan project data science end-to-end",
                'category'       => 'technical',
                'level'          => 'beginner',
                'duration_hours' => 45,
                'status'         => 'published',
                'price'          => 275000,
                'is_free'        => false,
                'tags'           => json_encode(['Python', 'Data Science', 'Pandas', 'Machine Learning', 'Analisis Data']),
                'max_students'   => 35,
                'rating'         => 4.7,
                'total_enrolled' => 42,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course1C_is_new = true;
        }

        $course1D = DB::table('teacher_courses')->where('teacher_id', $education1)->where('title', 'DevOps & Cloud Infrastructure')->value('id');
        $course1D_is_new = false;
        if (!$course1D) {
            $course1D = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education1,
                'competency_id'  => $dockerCompId,
                'title'          => 'DevOps & Cloud Infrastructure',
                'description'    => 'Kursus DevOps untuk memahami CI/CD pipeline, containerization dengan Docker, orchestration dengan Kubernetes, dan cloud deployment. Pelajari Infrastructure as Code dengan Terraform dan monitoring dengan Prometheus & Grafana.',
                'objectives'     => "1. Menguasai Docker dan Docker Compose\n2. Memahami Kubernetes fundamentals\n3. Membuat CI/CD pipeline dengan GitHub Actions\n4. Deploy aplikasi ke AWS/GCP\n5. Mengelola Infrastructure as Code\n6. Monitoring dan logging aplikasi production",
                'category'       => 'technical',
                'level'          => 'advanced',
                'duration_hours' => 55,
                'status'         => 'draft',
                'price'          => 500000,
                'is_free'        => false,
                'tags'           => json_encode(['DevOps', 'Docker', 'Kubernetes', 'CI/CD', 'Cloud', 'AWS']),
                'max_students'   => 20,
                'rating'         => 0,
                'total_enrolled' => 0,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course1D_is_new = true;
        }

        // ============================================================
        // EDUCATION 2 COURSES
        // ============================================================

        $course2A = DB::table('teacher_courses')->where('teacher_id', $education2)->where('title', 'UI/UX Design Masterclass')->value('id');
        $course2A_is_new = false;
        if (!$course2A) {
            $course2A = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education2,
                'competency_id'  => $figmaCompId,
                'title'          => 'UI/UX Design Masterclass',
                'description'    => 'Kursus lengkap desain UI/UX dari dasar hingga mahir. Pelajari design thinking, user research, wireframing, prototyping di Figma, dan usability testing. Bangun 5 project portfolio yang siap ditunjukkan ke perusahaan.',
                'objectives'     => "1. Memahami prinsip design thinking\n2. Mampu melakukan user research dan usability testing\n3. Menguasai Figma untuk wireframing dan prototyping\n4. Membuat design system yang konsisten\n5. Membangun portfolio desain UI/UX profesional\n6. Memahami accessibility dan inclusive design",
                'category'       => 'technical',
                'level'          => 'beginner',
                'duration_hours' => 50,
                'status'         => 'published',
                'price'          => 350000,
                'is_free'        => false,
                'tags'           => json_encode(['Figma', 'UI/UX', 'Design Thinking', 'Prototyping', 'User Research']),
                'max_students'   => 30,
                'rating'         => 4.8,
                'total_enrolled' => 55,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course2A_is_new = true;
        }

        $course2B = DB::table('teacher_courses')->where('teacher_id', $education2)->where('title', 'Mobile App Development dengan Flutter')->value('id');
        $course2B_is_new = false;
        if (!$course2B) {
            $course2B = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education2,
                'competency_id'  => $flutterCompId,
                'title'          => 'Mobile App Development dengan Flutter',
                'description'    => 'Belajar Flutter dari nol hingga mampu membangun aplikasi mobile untuk Android dan iOS. Pelajari Dart, widget system, state management, integrasi REST API, Firebase, dan deployment ke Play Store & App Store.',
                'objectives'     => "1. Menguasai bahasa Dart dan Flutter framework\n2. Mampu membangun UI responsif dengan widget system\n3. Mengelola state aplikasi menggunakan Provider/Riverpod\n4. Mengintegrasikan REST API ke aplikasi Flutter\n5. Mengimplementasi Firebase Auth dan Firestore\n6. Deploy aplikasi ke Play Store dan App Store",
                'category'       => 'technical',
                'level'          => 'intermediate',
                'duration_hours' => 60,
                'status'         => 'published',
                'price'          => 400000,
                'is_free'        => false,
                'tags'           => json_encode(['Flutter', 'Dart', 'Mobile Development', 'Android', 'iOS', 'Firebase']),
                'max_students'   => 25,
                'rating'         => 4.6,
                'total_enrolled' => 31,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course2B_is_new = true;
        }

        $course2C = DB::table('teacher_courses')->where('teacher_id', $education2)->where('title', 'JavaScript Modern: ES6+ hingga TypeScript')->value('id');
        $course2C_is_new = false;
        if (!$course2C) {
            $course2C = DB::table('teacher_courses')->insertGetId([
                'teacher_id'     => $education2,
                'competency_id'  => $jsCompId,
                'title'          => 'JavaScript Modern: ES6+ hingga TypeScript',
                'description'    => 'Kursus komprehensif JavaScript modern dari ES6+ hingga TypeScript. Pelajari async/await, modules, classes, destructuring, optional chaining, dan type safety dengan TypeScript. Cocok untuk developer yang ingin menguasai JavaScript secara mendalam.',
                'objectives'     => "1. Menguasai fitur ES6+ (arrow functions, destructuring, spread, dll)\n2. Memahami async programming dengan Promise dan async/await\n3. Menguasai OOP dan functional programming di JavaScript\n4. Menggunakan TypeScript untuk type safety\n5. Memahami module system (ESM, CommonJS)\n6. Membangun project nyata dengan JavaScript modern",
                'category'       => 'technical',
                'level'          => 'intermediate',
                'duration_hours' => 35,
                'status'         => 'published',
                'price'          => 0,
                'is_free'        => true,
                'tags'           => json_encode(['JavaScript', 'ES6', 'TypeScript', 'Async/Await', 'Modern JS']),
                'max_students'   => 45,
                'rating'         => 4.7,
                'total_enrolled' => 73,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
            $course2C_is_new = true;
        }

        // ============================================================
        // COURSE MODULES & MATERIALS
        // ============================================================

        $allCourses = [
            ['id' => $course1A, 'name' => 'Fullstack Web Development Bootcamp', 'is_new' => $course1A_is_new],
            ['id' => $course1B, 'name' => 'Career Preparation & Soft Skills', 'is_new' => $course1B_is_new],
            ['id' => $course1C, 'name' => 'Data Science Fundamentals dengan Python', 'is_new' => $course1C_is_new],
            ['id' => $course2A, 'name' => 'UI/UX Design Masterclass', 'is_new' => $course2A_is_new],
            ['id' => $course2B, 'name' => 'Mobile App Development dengan Flutter', 'is_new' => $course2B_is_new],
            ['id' => $course2C, 'name' => 'JavaScript Modern: ES6+ hingga TypeScript', 'is_new' => $course2C_is_new],
        ];

        foreach ($allCourses as $courseData) {
            if ($courseData['is_new']) {
                $this->createModulesAndMaterials($courseData['id'], $courseData['name']);
            }
        }

        // ============================================================
        // TEACHER CLASSES
        // ============================================================

        $class1A = DB::table('teacher_classes')->where('code', 'FS-EDU-2026-A1')->value('id');
        if (!$class1A) {
            $class1A = DB::table('teacher_classes')->insertGetId([
                'teacher_id'     => $education1,
                'course_id'      => $course1A,
                'name'           => 'Fullstack Bootcamp Batch 2026-A',
                'code'           => 'FS-EDU-2026-A1',
                'description'    => 'Kelas intensif fullstack web development. Career coaching included.',
                'start_date'     => '2026-07-01',
                'end_date'       => '2026-10-30',
                'max_students'   => 25,
                'status'         => 'active',
                'meeting_link'   => 'https://meet.google.com/edu-fs-2026',
                'schedule_info'  => 'Senin–Jumat, 09.00–12.00 WIB (intensif)',
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
        }

        $class1B = DB::table('teacher_classes')->where('code', 'CP-EDU-2026-A1')->value('id');
        if (!$class1B) {
            $class1B = DB::table('teacher_classes')->insertGetId([
                'teacher_id'     => $education1,
                'course_id'      => $course1B,
                'name'           => 'Career Prep Batch 2026-A',
                'code'           => 'CP-EDU-2026-A1',
                'description'    => 'Kelas persiapan karir untuk fresh graduate dan job seeker.',
                'start_date'     => '2026-07-15',
                'end_date'       => '2026-08-30',
                'max_students'   => 50,
                'status'         => 'active',
                'meeting_link'   => 'https://meet.google.com/edu-cp-2026',
                'schedule_info'  => 'Setiap Sabtu, 09.00–12.00 WIB',
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
        }

        $class2A = DB::table('teacher_classes')->where('code', 'UX-EDU-2026-A1')->value('id');
        if (!$class2A) {
            $class2A = DB::table('teacher_classes')->insertGetId([
                'teacher_id'     => $education2,
                'course_id'      => $course2A,
                'name'           => 'UI/UX Design Batch 2026-A',
                'code'           => 'UX-EDU-2026-A1',
                'description'    => 'Kelas desain UI/UX dengan Figma. Portfolio-based learning.',
                'start_date'     => '2026-07-21',
                'end_date'       => '2026-10-21',
                'max_students'   => 30,
                'status'         => 'active',
                'meeting_link'   => 'https://meet.google.com/edu-ux-2026',
                'schedule_info'  => 'Setiap Senin & Kamis, 16.00–18.00 WIB',
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
        }

        $class2B = DB::table('teacher_classes')->where('code', 'JS-EDU-2026-A1')->value('id');
        if (!$class2B) {
            $class2B = DB::table('teacher_classes')->insertGetId([
                'teacher_id'     => $education2,
                'course_id'      => $course2C,
                'name'           => 'JavaScript Modern Batch 2026-A',
                'code'           => 'JS-EDU-2026-A1',
                'description'    => 'Kelas JavaScript modern dari ES6+ hingga TypeScript.',
                'start_date'     => '2026-08-01',
                'end_date'       => '2026-09-30',
                'max_students'   => 45,
                'status'         => 'active',
                'meeting_link'   => 'https://meet.google.com/edu-js-2026',
                'schedule_info'  => 'Setiap Selasa & Kamis, 19.00–21.00 WIB',
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
        }

        // ============================================================
        // ENROLLMENTS
        // ============================================================

        $seekerIds = DB::table('users')->where('role', 'job_seeker')->pluck('id')->toArray();

        if (count($seekerIds) >= 5) {
            $seekerSlice1 = array_slice($seekerIds, 0, 5);
            $seekerSlice2 = array_slice($seekerIds, 5, 5);

            // Enrollments for Class 1A (Fullstack Bootcamp)
            foreach ($seekerSlice1 as $i => $seekerId) {
                $exists = DB::table('class_enrollments')->where('class_id', $class1A)->where('user_id', $seekerId)->exists();
                if (!$exists) {
                    $progress = [75, 60, 45, 90, 30][$i];
                    DB::table('class_enrollments')->insert([
                        'class_id'            => $class1A,
                        'user_id'             => $seekerId,
                        'status'              => 'active',
                        'progress_percentage' => $progress,
                        'completed_modules'   => intval($progress / 20),
                        'enrolled_at'         => Carbon::now()->subDays(30 - $i * 3),
                        'completed_at'        => null,
                        'final_score'         => null,
                        'created_at'          => now(),
                        'updated_at'          => now(),
                    ]);
                }
            }

            // Enrollments for Class 2A (UI/UX Design)
            foreach ($seekerSlice2 as $i => $seekerId) {
                $exists = DB::table('class_enrollments')->where('class_id', $class2A)->where('user_id', $seekerId)->exists();
                if (!$exists) {
                    $progress = [80, 55, 100, 40, 65][$i];
                    DB::table('class_enrollments')->insert([
                        'class_id'            => $class2A,
                        'user_id'             => $seekerId,
                        'status'              => $progress >= 100 ? 'completed' : 'active',
                        'progress_percentage' => min($progress, 100),
                        'completed_modules'   => intval(min($progress, 100) / 20),
                        'enrolled_at'         => Carbon::now()->subDays(35 - $i * 4),
                        'completed_at'        => $progress >= 100 ? Carbon::now()->subDays(2) : null,
                        'final_score'         => $progress >= 100 ? 88.5 : null,
                        'created_at'          => now(),
                        'updated_at'          => now(),
                    ]);
                }
            }
        }
    }

    private function createModulesAndMaterials(int $courseId, string $courseName): void
    {
        $modules = [];

        if (str_contains($courseName, 'Fullstack') || str_contains($courseName, 'Web')) {
            $modules = [
                ['title' => 'Frontend Basic: HTML, CSS & JavaScript', 'description' => 'HTML semantic, CSS Flexbox & Grid, JavaScript ES6+, DOM manipulation.', 'duration_minutes' => 480],
                ['title' => 'Frontend Advanced: React.js', 'description' => 'Components, hooks, state management, routing, dan API integration dengan React.', 'duration_minutes' => 400],
                ['title' => 'Backend Development', 'description' => 'RESTful API, middleware, authentication, error handling, dan testing.', 'duration_minutes' => 400],
                ['title' => 'Database & Deployment', 'description' => 'MySQL, MongoDB, ORM, Docker basics, deploy ke cloud.', 'duration_minutes' => 350],
            ];
        } elseif (str_contains($courseName, 'Career')) {
            $modules = [
                ['title' => 'Membuat CV & Surat Lamaran', 'description' => 'Format CV ATS-friendly, struktur surat lamaran, dan tips menulis deskripsi pengalaman.', 'duration_minutes' => 120],
                ['title' => 'Teknik Interview & Negosiasi', 'description' => 'Metode STAR, behavioral questions, technical interview, dan negosiasi gaji.', 'duration_minutes' => 150],
                ['title' => 'Personal Branding & LinkedIn', 'description' => 'Optimasi LinkedIn, networking strategy, personal branding.', 'duration_minutes' => 120],
            ];
        } elseif (str_contains($courseName, 'Data Science')) {
            $modules = [
                ['title' => 'Setup Python & Jupyter Notebook', 'description' => 'Instalasi Python, pip, virtual environment, Jupyter Notebook.', 'duration_minutes' => 120],
                ['title' => 'Pandas: Membaca dan Membersihkan Data', 'description' => 'DataFrame, Series, read_csv, data cleaning, handling missing values.', 'duration_minutes' => 240],
                ['title' => 'Visualisasi Data dengan Matplotlib & Seaborn', 'description' => 'Membuat chart, plot, dan grafik yang informative.', 'duration_minutes' => 200],
                ['title' => 'Analisis Statistik Dasar', 'description' => 'Mean, median, modus, standar deviasi, korelasi.', 'duration_minutes' => 180],
                ['title' => 'Studi Kasus: Analisis Data Bisnis', 'description' => 'Project akhir: analisis dataset bisnis dari cleaning hingga insight.', 'duration_minutes' => 300],
            ];
        } elseif (str_contains($courseName, 'UI/UX')) {
            $modules = [
                ['title' => 'Pengenalan UI/UX & Design Thinking', 'description' => 'Prinsip desain, design thinking process, empati pengguna.', 'duration_minutes' => 180],
                ['title' => 'Mengenal Figma: Tools & Interface', 'description' => 'Navigasi Figma, frame, shape, text, auto layout, components.', 'duration_minutes' => 240],
                ['title' => 'Wireframing & Low-fidelity Prototype', 'description' => 'Teknik wireframing, user flow, information architecture.', 'duration_minutes' => 200],
                ['title' => 'Visual Design: Warna, Tipografi & Ikon', 'description' => 'Color theory, typography hierarchy, iconography.', 'duration_minutes' => 180],
                ['title' => 'High-fidelity Prototype & Interaksi', 'description' => 'Membuat hi-fi prototype dengan micro-interactions.', 'duration_minutes' => 250],
                ['title' => 'User Testing & Iterasi', 'description' => 'Usability testing, heuristic evaluation, A/B testing.', 'duration_minutes' => 200],
            ];
        } elseif (str_contains($courseName, 'Flutter') || str_contains($courseName, 'Mobile')) {
            $modules = [
                ['title' => 'Dart Programming Fundamentals', 'description' => 'Sintaks Dart, OOP, async/await, null safety.', 'duration_minutes' => 200],
                ['title' => 'Flutter Widget System', 'description' => 'StatelessWidget, StatefulWidget, layout widgets.', 'duration_minutes' => 280],
                ['title' => 'State Management dengan Provider', 'description' => 'Provider, ChangeNotifier, Consumer, MultiProvider.', 'duration_minutes' => 250],
                ['title' => 'REST API & Firebase Integration', 'description' => 'HTTP client, JSON serialization, Firebase Auth, Firestore.', 'duration_minutes' => 300],
            ];
        } elseif (str_contains($courseName, 'JavaScript')) {
            $modules = [
                ['title' => 'ES6+ Fundamentals', 'description' => 'Arrow functions, destructuring, spread/rest, template literals.', 'duration_minutes' => 180],
                ['title' => 'Async JavaScript: Promise & Async/Await', 'description' => 'Asynchronous programming, fetch API, error handling.', 'duration_minutes' => 200],
                ['title' => 'OOP & Functional Programming', 'description' => 'Classes, prototypes, closures, higher-order functions.', 'duration_minutes' => 220],
                ['title' => 'TypeScript Essentials', 'description' => 'Types, interfaces, generics, utility types.', 'duration_minutes' => 250],
            ];
        } else {
            $modules = [
                ['title' => 'Pengenalan & Setup Environment', 'description' => 'Setup development environment dan pengenalan tools.', 'duration_minutes' => 120],
                ['title' => 'Konsep Dasar', 'description' => 'Mempelajari konsep dasar dan fundamental.', 'duration_minutes' => 180],
                ['title' => 'Praktik Lanjutan', 'description' => 'Studi kasus dan implementasi nyata.', 'duration_minutes' => 240],
            ];
        }

        foreach ($modules as $index => $moduleData) {
            $moduleId = DB::table('course_modules')->insertGetId([
                'course_id'      => $courseId,
                'title'          => $moduleData['title'],
                'description'    => $moduleData['description'],
                'order_number'   => $index + 1,
                'duration_minutes' => $moduleData['duration_minutes'],
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);

            // Add materials for each module
            DB::table('course_materials')->insert([
                [
                    'module_id'       => $moduleId,
                    'title'           => "Handout: {$moduleData['title']}",
                    'type'            => 'document',
                    'file_path'       => "materials/documents/" . str_replace([' ', ':', '/'], '-', strtolower($moduleData['title'])) . ".pdf",
                    'file_name'       => str_replace([' ', ':', '/'], '-', strtolower($moduleData['title'])) . ".pdf",
                    'file_size'       => rand(300000, 800000),
                    'mime_type'       => 'application/pdf',
                    'content'         => "Handout materi pembelajaran untuk modul: {$moduleData['title']}.",
                    'external_url'    => null,
                    'order_number'    => 1,
                    'is_downloadable' => true,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
                [
                    'module_id'       => $moduleId,
                    'title'           => "Video Tutorial: {$moduleData['title']}",
                    'type'            => 'video',
                    'file_path'       => null,
                    'file_name'       => null,
                    'file_size'       => null,
                    'mime_type'       => null,
                    'content'         => "Video tutorial pembelajaran untuk modul: {$moduleData['title']}.",
                    'external_url'    => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                    'order_number'    => 2,
                    'is_downloadable' => false,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
                [
                    'module_id'       => $moduleId,
                    'title'           => "Tugas Praktik: {$moduleData['title']}",
                    'type'            => 'assignment',
                    'file_path'       => null,
                    'file_name'       => null,
                    'file_size'       => null,
                    'mime_type'       => null,
                    'content'         => "Kerjakan tugas praktik berikut untuk memperdalam pemahaman materi '{$moduleData['title']}'.",
                    'external_url'    => null,
                    'order_number'    => 3,
                    'is_downloadable' => false,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ],
            ]);
        }
    }
}
