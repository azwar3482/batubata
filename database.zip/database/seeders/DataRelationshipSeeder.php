<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DataRelationshipSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        // =============================================
        // 1. CLASSES untuk courses yang belum punya kelas
        // =============================================

        $existing9 = DB::table('teacher_classes')->where('code', 'SQL-2026-A1')->first();
        $class9 = $existing9 ? $existing9->id : DB::table('teacher_classes')->insertGetId([
            'teacher_id' => 79, 'course_id' => 9,
            'name' => 'SQL Data Analyst Batch 2026-A', 'code' => 'SQL-2026-A1',
            'description' => 'Kelas SQL dari dasar hingga advanced untuk calon data analyst.',
            'start_date' => '2026-07-15', 'end_date' => '2026-10-15',
            'max_students' => 35, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/sql-batch-a1',
            'schedule_info' => 'Setiap Selasa & Kamis, 19.00–21.00 WIB',
            'created_at' => $now, 'updated_at' => $now,
        ]);

        $existing11 = DB::table('teacher_classes')->where('code', 'FL-2026-A1')->first();
        $class11 = $existing11 ? $existing11->id : DB::table('teacher_classes')->insertGetId([
            'teacher_id' => 80, 'course_id' => 11,
            'name' => 'Flutter Mobile Batch 2026-A', 'code' => 'FL-2026-A1',
            'description' => 'Kelas Flutter untuk pemula. Bangun 3 aplikasi mobile selama kursus.',
            'start_date' => '2026-07-21', 'end_date' => '2026-10-21',
            'max_students' => 30, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/flutter-batch-a1',
            'schedule_info' => 'Setiap Senin & Rabu, 19.00–21.30 WIB',
            'created_at' => $now, 'updated_at' => $now,
        ]);

        $existing13 = DB::table('teacher_classes')->where('code', 'CP-2026-A1')->first();
        $class13 = $existing13 ? $existing13->id : DB::table('teacher_classes')->insertGetId([
            'teacher_id' => 81, 'course_id' => 13,
            'name' => 'Career Prep Batch 2026-A', 'code' => 'CP-2026-A1',
            'description' => 'Kelas persiapan karir untuk fresh graduate. CV review, mock interview, dan coaching.',
            'start_date' => '2026-07-07', 'end_date' => '2026-09-07',
            'max_students' => 50, 'status' => 'active',
            'meeting_link' => 'https://meet.google.com/career-prep-a1',
            'schedule_info' => 'Setiap Jumat, 16.00–18.00 WIB',
            'created_at' => $now, 'updated_at' => $now,
        ]);

        // =============================================
        // 2. ENROLLMENT: Sebarkan seekers ke semua kelas
        // =============================================

        // Seeker IDs yang aktif (10 pertama)
        $seekers = DB::table('users')->where('role', 'job_seeker')->pluck('id')->take(10)->toArray();

        // Mapping: seeker -> kelas yang akan diikuti
        // Kelas 4 (Laravel): sudah ada 5 (seeker 2-6)
        // Kelas 5 (React): tambahkan 4 seeker
        // Kelas 6 (Python): sudah ada 5 (seeker 7-11)
        // Kelas 7 (Figma): tambahkan 4 seeker
        // Kelas 8 (Fullstack): tambahkan 3 seeker
        // Kelas $class9 (SQL): tambahkan 4 seeker
        // Kelas $class11 (Flutter): tambahkan 3 seeker
        // Kelas $class13 (Career Prep): tambahkan 6 seeker

        $enrollments = [
            // Kelas 5 (React + Laravel SPA) - seekers 2,3,4,7
            ['class_id' => 5, 'user_id' => 2, 'progress' => 40, 'modules' => 2],
            ['class_id' => 5, 'user_id' => 3, 'progress' => 65, 'modules' => 3],
            ['class_id' => 5, 'user_id' => 4, 'progress' => 25, 'modules' => 1],
            ['class_id' => 5, 'user_id' => 7, 'progress' => 55, 'modules' => 2],

            // Kelas 7 (UI/UX Figma) - seekers 5,8,9,10
            ['class_id' => 7, 'user_id' => 5, 'progress' => 50, 'modules' => 3],
            ['class_id' => 7, 'user_id' => 8, 'progress' => 35, 'modules' => 2],
            ['class_id' => 7, 'user_id' => 9, 'progress' => 70, 'modules' => 4],
            ['class_id' => 7, 'user_id' => 10, 'progress' => 20, 'modules' => 1],

            // Kelas 8 (Fullstack Bootcamp) - seekers 2,6,11
            ['class_id' => 8, 'user_id' => 2, 'progress' => 30, 'modules' => 1],
            ['class_id' => 8, 'user_id' => 6, 'progress' => 55, 'modules' => 2],
            ['class_id' => 8, 'user_id' => 11, 'progress' => 45, 'modules' => 2],

            // Kelas $class9 (SQL) - seekers 3,5,7,10
            ['class_id' => $class9, 'user_id' => 3, 'progress' => 60, 'modules' => 2],
            ['class_id' => $class9, 'user_id' => 5, 'progress' => 40, 'modules' => 1],
            ['class_id' => $class9, 'user_id' => 7, 'progress' => 80, 'modules' => 2],
            ['class_id' => $class9, 'user_id' => 10, 'progress' => 25, 'modules' => 1],

            // Kelas $class11 (Flutter) - seekers 4,6,9
            ['class_id' => $class11, 'user_id' => 4, 'progress' => 35, 'modules' => 1],
            ['class_id' => $class11, 'user_id' => 6, 'progress' => 60, 'modules' => 3],
            ['class_id' => $class11, 'user_id' => 9, 'progress' => 45, 'modules' => 2],

            // Kelas $class13 (Career Prep) - seekers 2,3,4,5,8,11
            ['class_id' => $class13, 'user_id' => 2, 'progress' => 80, 'modules' => 2],
            ['class_id' => $class13, 'user_id' => 3, 'progress' => 100, 'modules' => 3],
            ['class_id' => $class13, 'user_id' => 4, 'progress' => 60, 'modules' => 2],
            ['class_id' => $class13, 'user_id' => 5, 'progress' => 45, 'modules' => 1],
            ['class_id' => $class13, 'user_id' => 8, 'progress' => 90, 'modules' => 3],
            ['class_id' => $class13, 'user_id' => 11, 'progress' => 70, 'modules' => 2],
        ];

        foreach ($enrollments as $e) {
            $exists = DB::table('class_enrollments')
                ->where('class_id', $e['class_id'])
                ->where('user_id', $e['user_id'])
                ->exists();

            if (!$exists) {
                $status = $e['progress'] >= 100 ? 'completed' : 'active';
                DB::table('class_enrollments')->insert([
                    'class_id'            => $e['class_id'],
                    'user_id'             => $e['user_id'],
                    'status'              => $status,
                    'progress_percentage' => min($e['progress'], 100),
                    'completed_modules'   => $e['modules'],
                    'enrolled_at'         => Carbon::now()->subDays(rand(15, 40)),
                    'completed_at'        => $status === 'completed' ? Carbon::now()->subDays(2) : null,
                    'final_score'         => $status === 'completed' ? rand(75, 95) : null,
                    'created_at'          => $now,
                    'updated_at'          => $now,
                ]);
            }
        }

        // =============================================
        // 3. SUBMISSIONS untuk enrollment baru
        // =============================================

        // Ambil semua enrollment yang belum punya submission
        $newEnrollments = DB::table('class_enrollments')
            ->where('progress_percentage', '>=', 30)
            ->get();

        foreach ($newEnrollments as $enr) {
            $hasSubmission = DB::table('submissions')->where('enrollment_id', $enr->id)->exists();
            if ($hasSubmission) continue;

            // Cari assignment material dari kelas ini
            $classInfo = DB::table('teacher_classes')->where('id', $enr->class_id)->first();
            if (!$classInfo) continue;

            $courseModules = DB::table('course_modules')->where('course_id', $classInfo->course_id)->pluck('id');
            $assignment = DB::table('course_materials')
                ->whereIn('module_id', $courseModules)
                ->where('type', 'assignment')
                ->first();

            if (!$assignment) continue;

            $isGraded = $enr->progress_percentage >= 50;
            DB::table('submissions')->insert([
                'enrollment_id' => $enr->id,
                'material_id'   => $assignment->id,
                'content'       => "Berikut adalah hasil tugas praktik yang telah saya kerjakan. Saya telah mengimplementasikan konsep yang dipelajari dengan membuat project sederhana.",
                'file_path'     => "submissions/user-{$enr->user_id}/tugas-{$assignment->id}.pdf",
                'file_name'     => "tugas-praktik-{$assignment->id}.pdf",
                'file_size'     => rand(100000, 500000),
                'status'        => $isGraded ? 'graded' : 'submitted',
                'score'         => $isGraded ? rand(65, 95) : null,
                'feedback'      => $isGraded ? "Kerja bagus! Sudah sesuai dengan materi yang dipelajari. Tingkatkan lagi di tugas berikutnya." : null,
                'submitted_at'  => Carbon::now()->subDays(rand(3, 15)),
                'graded_at'     => $isGraded ? Carbon::now()->subDays(rand(1, 5)) : null,
                'created_at'    => $now,
                'updated_at'    => $now,
            ]);
        }

        // =============================================
        // 4. COURSE PROGRESS untuk external courses
        //    (seekers yang belum punya progress)
        // =============================================

        $seekersNeedingProgress = [9, 10, 11]; // seekers yang belum punya external course progress
        $externalCourseIds = DB::table('courses')->pluck('id')->toArray();

        foreach ($seekersNeedingProgress as $sid) {
            $hasProgress = DB::table('user_course_progress')->where('user_id', $sid)->exists();
            if ($hasProgress) continue;

            // Assign 2-3 random external courses
            $randomCourses = array_rand(array_flip($externalCourseIds), min(3, count($externalCourseIds)));
            if (!is_array($randomCourses)) $randomCourses = [$randomCourses];

            foreach ($randomCourses as $cid) {
                $progress = rand(20, 85);
                DB::table('user_course_progress')->insert([
                    'user_id'            => $sid,
                    'course_id'          => $cid,
                    'status'             => $progress >= 100 ? 'completed' : 'in_progress',
                    'progress_percentage'=> min($progress, 100),
                    'completed_modules'  => intval($progress / 25),
                    'total_modules'      => 4,
                    'started_at'         => Carbon::now()->subDays(rand(10, 30)),
                    'completed_at'       => $progress >= 100 ? Carbon::now()->subDays(2) : null,
                    'created_at'         => $now,
                    'updated_at'         => $now,
                ]);
            }
        }

        // =============================================
        // 5. JOB APPLICATIONS tambahan untuk seekers
        //    yang belum punya lamaran
        // =============================================

        $seekersNeedingApps = DB::table('users')
            ->where('role', 'job_seeker')
            ->whereNotIn('id', DB::table('user_job_applications')->pluck('user_id'))
            ->pluck('id')
            ->take(5);

        $jobIds = DB::table('job_listings')->pluck('id')->toArray();

        foreach ($seekersNeedingApps as $sid) {
            $randomJobs = array_rand(array_flip($jobIds), min(2, count($jobIds)));
            if (!is_array($randomJobs)) $randomJobs = [$randomJobs];

            foreach ($randomJobs as $jid) {
                $exists = DB::table('user_job_applications')
                    ->where('user_id', $sid)
                    ->where('job_listing_id', $jid)
                    ->exists();

                if (!$exists) {
                    DB::table('user_job_applications')->insert([
                        'user_id'             => $sid,
                        'job_listing_id'      => $jid,
                        'status'              => 'applied',
                        'matching_percentage' => rand(50, 85),
                        'applied_at'          => Carbon::now()->subDays(rand(1, 15)),
                        'created_at'          => $now,
                        'updated_at'          => $now,
                    ]);
                }
            }
        }

        // =============================================
        // 6. ASSESSMENT tambahan untuk seekers baru
        // =============================================

        $positionIds = DB::table('positions')->pluck('id')->toArray();

        $seekersNeedingAssess = DB::table('users')
            ->where('role', 'job_seeker')
            ->whereNotIn('id', DB::table('user_assessments')->pluck('user_id'))
            ->pluck('id')
            ->take(3);

        foreach ($seekersNeedingAssess as $sid) {
            $randomPos = $positionIds[array_rand($positionIds)];

            $assessId = DB::table('user_assessments')->insertGetId([
                'user_id'             => $sid,
                'position_id'         => $randomPos,
                'assessment_date'     => $now,
                'total_gap_percentage'=> rand(10, 45),
                'status'              => 'completed',
                'created_at'          => $now,
                'updated_at'          => $now,
            ]);

            // Tambah competency scores untuk assessment ini
            $competencies = DB::table('competencies')
                ->where('position_id', $randomPos)
                ->take(5)
                ->get();

            foreach ($competencies as $comp) {
                $gap = rand(5, 40);
                DB::table('user_competency_scores')->insert([
                    'assessment_id'       => $assessId,
                    'competency_id'       => $comp->id,
                    'self_assessed_level' => rand(1, 5),
                    'ai_analyzed_level'   => rand(1, 5),
                    'gap_percentage'      => $gap,
                    'priority'            => $gap > 20 ? 'high' : 'low',
                    'created_at'          => $now,
                    'updated_at'          => $now,
                ]);
            }
        }

        // Cleanup temp file
        @unlink(__DIR__ . '/../analyze_data.php');
        @unlink(__DIR__ . '/../analyze_relations.php');
    }
}
