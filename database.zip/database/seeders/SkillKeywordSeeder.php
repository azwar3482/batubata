<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SkillKeywordSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $technical_skills = [
            'programming' => ['python', 'java', 'javascript', 'php', 'c++', 'ruby', 'go', 'rust'],
            'web_development' => ['html', 'css', 'react', 'vue', 'angular', 'laravel', 'django', 'flask'],
            'database' => ['mysql', 'postgresql', 'mongodb', 'oracle', 'sql server', 'redis'],
            'data_science' => ['python', 'r', 'tensorflow', 'pytorch', 'scikit-learn', 'pandas', 'numpy'],
            'cloud' => ['aws', 'google cloud', 'azure', 'docker', 'kubernetes', 'terraform'],
            'soft_skills' => ['communication', 'leadership', 'teamwork', 'problem solving', 'critical thinking']
        ];

        foreach ($technical_skills as $category => $keywords) {
            foreach ($keywords as $keyword) {
                \App\Models\SkillKeyword::firstOrCreate([
                    'category' => $category,
                    'keyword' => $keyword,
                ], [
                    'is_active' => true
                ]);
            }
        }
    }
}
