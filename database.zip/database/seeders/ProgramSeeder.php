<?php

namespace Database\Seeders;

use App\Models\Institution;
use App\Models\Program;
use Illuminate\Database\Seeder;

class ProgramSeeder extends Seeder
{
    public function run(): void
    {
        $institution = Institution::first();

        $programs = [
            [
                'name' => 'Bootcamp Full-Stack Web Development',
                'type' => 'Bootcamp',
                'description' => 'Program bootcamp intensif 3 bulan untuk menjadi full-stack web developer. Mencakup HTML, CSS, JavaScript, React, Node.js, database, dan deployment. Peserta akan membangun 5 project portfolio.',
                'duration' => '3 Bulan',
                'max_students' => 30,
                'status' => 'active',
                'start_date' => now()->subDays(30),
                'end_date' => now()->addDays(60),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Tokopedia', 'Gojek', 'Traveloka'],
            ],
            [
                'name' => 'Sertifikasi Data Analyst Professional',
                'type' => 'Sertifikasi',
                'description' => 'Program sertifikasi 6 minggu untuk menjadi data analyst profesional. Pelajari Python, SQL, Tableau, statistik, dan data storytelling. Termasuk proyek akhir dengan data industri nyata.',
                'duration' => '6 Minggu',
                'max_students' => 25,
                'status' => 'active',
                'start_date' => now()->subDays(15),
                'end_date' => now()->addDays(27),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Bank Mandiri', 'BCA', 'Bukalapak'],
            ],
            [
                'name' => 'Workshop UI/UX Design Sprint',
                'type' => 'Workshop',
                'description' => 'Workshop intensif 5 hari menggunakan metode Google Design Sprint. Peserta akan belajar user research, ideation, prototyping, dan testing dalam satu siklus sprint lengkap.',
                'duration' => '5 Hari',
                'max_students' => 20,
                'status' => 'upcoming',
                'start_date' => now()->addDays(14),
                'end_date' => now()->addDays(19),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Gojek', 'Bukalapak'],
            ],
            [
                'name' => 'Program Magang Digital Marketing',
                'type' => 'Magang',
                'description' => 'Program magang 3 bulan di perusahaan partner. Peserta akan terlibat langsung dalam kampanye digital marketing, SEO optimization, content creation, dan analytics reporting.',
                'duration' => '3 Bulan',
                'max_students' => 15,
                'status' => 'active',
                'start_date' => now()->subDays(45),
                'end_date' => now()->addDays(45),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Traveloka', 'Blibli', 'Tiket.com'],
            ],
            [
                'name' => 'Bootcamp Mobile App Development',
                'type' => 'Bootcamp',
                'description' => 'Bootcamp 2 bulan untuk pengembangan aplikasi mobile. Pelajari Flutter/Dart untuk cross-platform development, Firebase integration, state management, dan app store deployment.',
                'duration' => '2 Bulan',
                'max_students' => 25,
                'status' => 'upcoming',
                'start_date' => now()->addDays(30),
                'end_date' => now()->addDays(90),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Gojek', 'Tokopedia'],
            ],
            [
                'name' => 'Sertifikasi AWS Cloud Practitioner',
                'type' => 'Sertifikasi',
                'description' => 'Program persiapan sertifikasi AWS Cloud Practitioner selama 4 minggu. Mencakup konsep cloud computing, layanan AWS core, security, pricing, dan arsitektur cloud.',
                'duration' => '4 Minggu',
                'max_students' => 30,
                'status' => 'completed',
                'start_date' => now()->subDays(60),
                'end_date' => now()->subDays(30),
                'institution_id' => $institution?->id,
                'industry_partners' => ['AWS', 'Accenture'],
            ],
            [
                'name' => 'Workshop Agile & Scrum untuk Tim',
                'type' => 'Workshop',
                'description' => 'Workshop 3 hari tentang implementasi Agile dan Scrum dalam tim pengembangan. Pelajari sprint planning, daily standup, retrospective, dan servant leadership.',
                'duration' => '3 Hari',
                'max_students' => 35,
                'status' => 'active',
                'start_date' => now()->subDays(7),
                'end_date' => now()->addDays(2),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Bank BRI', 'Telkom Indonesia'],
            ],
            [
                'name' => 'Program Bootcamp Cybersecurity',
                'type' => 'Bootcamp',
                'description' => 'Bootcamp intensif 2 bulan tentang keamanan siber. Mencakup network security, ethical hacking, incident response, dan security compliance. Lab praktik dengan real-world scenarios.',
                'duration' => '2 Bulan',
                'max_students' => 20,
                'status' => 'upcoming',
                'start_date' => now()->addDays(45),
                'end_date' => now()->addDays(105),
                'institution_id' => $institution?->id,
                'industry_partners' => ['Kemenkominfo', 'Telkom Indonesia'],
            ],
        ];

        foreach ($programs as $program) {
            Program::updateOrCreate(
                ['name' => $program['name']],
                $program
            );
        }
    }
}
