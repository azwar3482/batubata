<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ChatFaq;

class ChatFaqSeeder extends Seeder
{
    public function run(): void
    {
        $faqs = array_merge(
            $this->umumFaqs(),
            $this->profileFaqs(),
            $this->jobSeekerFaqs(),
            $this->industryFaqs(),
            $this->educationFaqs(),
            $this->adminFaqs(),
            $this->tpaFaqs(),
        );

        foreach ($faqs as $faq) {
            ChatFaq::create($faq);
        }
    }

    // ==================== UMUM ====================
    protected function umumFaqs(): array
    {
        return [
            [
                'question' => 'Apa itu KOMPASKARIR?',
                'answer' => "KOMPASKARIR adalah platform pengembangan karir yang menghubungkan 3 pihak:\n\n1. **Job Seeker** (Pencari Kerja) - Mencari pekerjaan, meningkatkan skill, mengikuti tes TPA\n2. **Industry** (Perusahaan/Employer) - Posting lowongan, mencari kandidat, melakukan seleksi\n3. **Education** (Institusi Pendidikan) - Mengelola kursus, program, dan kolaborasi dengan industri\n\nPlatform ini menggunakan teknologi AI untuk membantu mencocokkan kandidat dengan lowongan yang sesuai berdasarkan skill dan kompetensi.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['kompaskarir', 'aplikasi', 'platform', 'tentang', 'apa itu', 'aplikasi apa'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/dashboard'],
                    ['label' => 'Profil Saya', 'url' => '/profile'],
                ],
                'priority' => 10,
            ],
            [
                'question' => 'Bagaimana cara mengubah bahasa aplikasi?',
                'answer' => "Untuk mengubah bahasa aplikasi:\n\n1. Klik tombol bahasa di pojok **kanan atas** (navbar)\n2. Pilih **Indonesia** 🇮🇩 atau **English** 🇬🇧\n3. Bahasa akan berubah secara otomatis\n\nPengaturan bahasa tersimpan di session, jadi Anda perlu mengatur ulang setelah logout.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['bahasa', 'language', 'ubah', 'ganti', 'indonesia', 'english', 'translate'],
                'deep_links' => null,
                'priority' => 5,
            ],
            [
                'question' => 'Bagaimana cara menghubungi admin atau support?',
                'answer' => "Anda bisa menghubungi tim support melalui:\n\n1. **Email**: support@kompaskarir.com\n2. **Form Bantuan**: Klik ikon ? di pojok kanan atas\n\nAdmin akan merespons dalam 1x24 jam pada hari kerja.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['admin', 'hubungi', 'kontak', 'bantuan', 'support', 'help', 'cs', 'customer service'],
                'deep_links' => null,
                'priority' => 3,
            ],
            [
                'question' => 'Bagaimana cara melihat notifikasi?',
                'answer' => "Untuk melihat notifikasi:\n\n1. Klik **ikon lonceng** 🔔 di pojok kanan atas\n2. Akan muncul dropdown berisi notifikasi terbaru\n3. Klik notifikasi untuk langsung ke halaman terkait\n4. Klik **\"Tandai semua dibaca\"** untuk menandai semua sudah dibaca\n\nNotifikasi mencakup: undangan TPA, status lamaran, lowongan baru yang cocok, dll.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['notifikasi', 'notification', 'lonceng', 'bell', 'pemberitahuan'],
                'deep_links' => [
                    ['label' => 'Semua Notifikasi', 'url' => '/notifications'],
                ],
                'priority' => 5,
            ],
            [
                'question' => 'Bagaimana cara mengedit profil?',
                'answer' => "Untuk mengedit profil:\n\n1. Klik **nama Anda** di pojok kanan atas\n2. Pilih **\"Profil\"** dari dropdown\n3. Klik **\"Edit Profil\"**\n4. Ubah data yang diperlukan\n5. Klik **\"Simpan\"**\n\nAnda juga bisa upload foto profil dan CV dari halaman profil.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['profil', 'profile', 'edit', 'ubah', 'ganti', 'data diri'],
                'deep_links' => [
                    ['label' => 'Edit Profil', 'url' => '/profile'],
                ],
                'priority' => 6,
            ],
        ];
    }

    // ==================== PROFIL ====================
    protected function profileFaqs(): array
    {
        return [
            [
                'question' => 'Bagaimana cara upload CV?',
                'answer' => "Untuk mengupload CV:\n\n1. Buka halaman **Profil** (klik nama → Profil)\n2. Scroll ke bagian **\"Upload CV\"**\n3. Klik tombol **\"Pilih File\"** atau drag & drop\n4. Pilih file CV (format PDF, DOC, DOCX)\n5. Tunggu hingga proses upload selesai\n\nCV akan dianalisis oleh AI untuk mengekstrak skill dan pengalaman Anda. Pastikan CV Anda lengkap dan terbaru.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['upload', 'cv', 'resume', 'curriculum', 'vitae'],
                'deep_links' => [
                    ['label' => 'Upload CV', 'url' => '/profile'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Bagaimana cara upload foto profil?',
                'answer' => "Untuk mengupload foto profil:\n\n1. Buka halaman **Profil**\n2. Klik **ikon kamera** pada foto profil\n3. Pilih foto dari komputer Anda\n4. Foto akan diupload otomatis\n\nFormat yang didukung: JPG, PNG, GIF. Ukuran maksimal: 2MB.",
                'category' => 'umum',
                'roles' => null,
                'keywords' => ['foto', 'photo', 'avatar', 'profil', 'upload', 'gambar'],
                'deep_links' => [
                    ['label' => 'Edit Profil', 'url' => '/profile'],
                ],
                'priority' => 5,
            ],
            [
                'question' => 'Dokumen apa saja yang bisa diupload?',
                'answer' => "Anda bisa mengupload dokumen berikut:\n\n1. **CV** (Curriculum Vitae) - format PDF, DOC, DOCX\n2. **Ijazah** - format PDF, JPG, PNG\n3. **Transkrip Nilai** - format PDF\n4. **Sertifikat** - format PDF, JPG, PNG\n5. **Portofolio** - format PDF atau link URL\n\nSemua dokumen akan dianalisis oleh AI untuk mengekstrak informasi yang relevan.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['dokumen', 'document', 'upload', 'ijazah', 'transkrip', 'sertifikat', 'portofolio'],
                'deep_links' => [
                    ['label' => 'Upload Dokumen', 'url' => '/profile'],
                ],
                'priority' => 7,
            ],
        ];
    }

    // ==================== JOB SEEKER ====================
    protected function jobSeekerFaqs(): array
    {
        return [
            // DASHBOARD
            [
                'question' => 'Apa yang ada di Dashboard Job Seeker?',
                'answer' => "Dashboard Job Seeker menampilkan:\n\n1. **Status Profil** - Persentase kelengkapan profil Anda\n2. **Skill Gap** - Celah keahlian terakhir dari assessment\n3. **Rekomendasi Lowongan** - Pekerjaan yang cocok dengan skill Anda\n4. **Rekomendasi Kursus** - Kursus untuk menutup skill gap\n5. **Status Lamaran** - Lamaran terbaru dan statusnya\n6. **Notifikasi** - Undangan TPA, status lamaran, dll\n\nDashboard adalah halaman utama setelah login.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['dashboard', 'halaman utama', 'beranda', 'home', 'ringkasan'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/dashboard'],
                ],
                'priority' => 8,
            ],

            // ASSESSMENT
            [
                'question' => 'Apa itu Competency Assessment?',
                'answer' => "**Competency Assessment** adalah tes mandiri untuk mengukur kemampuan Anda dibandingkan dengan standar kompetensi yang dibutuhkan oleh posisi kerja.\n\n**Cara kerja:**\n1. Pilih posisi target (misal: Web Developer)\n2. Sistem menampilkan daftar kompetensi yang dibutuhkan\n3. Anda menilai kemampuan diri sendiri (skala 1-5)\n4. Sistem menghitung **skill gap** (selisih antara kemampuan Anda dan yang dibutuhkan)\n5. Hasil: rekomendasi kursus untuk menutup gap\n\n**Mengapa penting?**\n- Skill gap ≤ 30% diperlukan untuk bisa melamar kerja\n- Mengetahui kelemahan Anda membantu fokus belajar",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['assessment', 'asesmen', 'kompetensi', 'competency', 'skill gap', 'tes', 'kemampuan'],
                'deep_links' => [
                    ['label' => 'Mulai Assessment', 'url' => '/seeker/assessment'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Bagaimana cara mengikuti Assessment?',
                'answer' => "Langkah-langkah mengikuti Assessment:\n\n1. Buka menu **\"Competency Assessment\"** di sidebar\n2. Klik **\"Mulai Assessment\"**\n3. **Pilih posisi target** yang Anda inginkan (misal: Web Developer)\n4. Baca setiap kompetensi yang ditampilkan\n5. **Nilai kemampuan Anda** (1-5) untuk setiap kompetensi:\n   - 1 = Tidak tahu\n   - 2 = Pemula\n   - 3 = Menengah\n   - 4 = Mahir\n   - 5 = Ahli\n6. Klik **\"Submit\"** untuk melihat hasil\n7. Lihat **skill gap** dan rekomendasi kursus\n\nAnda bisa mengulang assessment kapan saja.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['assessment', 'cara', 'ikut', 'kerjakan', 'mulai', 'bagaimana'],
                'deep_links' => [
                    ['label' => 'Assessment', 'url' => '/seeker/assessment'],
                ],
                'priority' => 8,
            ],

            // ROADMAP
            [
                'question' => 'Apa itu Career Roadmap?',
                'answer' => "**Career Roadmap** adalah rencana belajar 6 bulan yang dibuat berdasarkan hasil assessment Anda.\n\n**Isi Roadmap:**\n- **Bulan 1-6**: Target kompetensi per bulan\n- **Kursus yang direkomendasikan** untuk setiap target\n- **Milestone** yang harus dicapai\n- **Progress tracking** untuk memantau kemajuan\n\n**Cara membuat:**\n1. Selesaikan assessment terlebih dahulu\n2. Buka menu **\"Career Roadmap\"**\n3. Klik **\"Generate Roadmap\"**\n4. Sistem akan membuat rencana belajar berdasarkan skill gap Anda\n5. Ikuti roadmap dan tandai milestone yang sudah selesai",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['roadmap', 'career', 'karir', 'rencana', 'belajar', 'plan'],
                'deep_links' => [
                    ['label' => 'Career Roadmap', 'url' => '/seeker/roadmap'],
                ],
                'priority' => 8,
            ],

            // JOBS
            [
                'question' => 'Bagaimana cara mencari dan melamar kerja?',
                'answer' => "Untuk mencari dan melamar kerja:\n\n**Mencari Lowongan:**\n1. Buka menu **\"Job Vacancies\"** di sidebar\n2. Gunakan **filter** untuk mencari:\n   - Kata kunci (judul, skill)\n   - Lokasi\n   - Tipe kerja (remote/onsite/hybrid)\n   - Range gaji\n3. Klik lowongan untuk melihat detail\n\n**Melamar Kerja:**\n1. Klik tombol **\"Lamar\"** pada lowongan yang diminati\n2. Tulis **surat lamaran** (opsional)\n3. Klik **\"Kirim Lamaran\"**\n\n**Syarat Melamar:**\n- Profil 100% lengkap\n- Skill gap ≤ 30%\n\n**Fitur Lain:**\n- **Skill Match**: Lihat persentase kecocokan Anda dengan lowongan\n- **Simpan Lowongan**: Simpan lowongan untuk dilihat nanti\n- **Lacak Lamaran**: Pantau status lamaran Anda",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['lamar', 'apply', 'melamar', 'kerja', 'pekerjaan', 'lowongan', 'job', 'cari'],
                'deep_links' => [
                    ['label' => 'Cari Lowongan', 'url' => '/seeker/jobs'],
                    ['label' => 'Lamaran Saya', 'url' => '/seeker/jobs/my-applications'],
                ],
                'priority' => 10,
            ],
            [
                'question' => 'Apa itu Skill Match dan bagaimana cara menggunakannya?',
                'answer' => "**Skill Match** adalah fitur yang menunjukkan persentase kecocokan antara skill Anda dengan kebutuhan lowongan.\n\n**Cara menggunakan:**\n1. Buka detail lowongan\n2. Klik tombol **\"Analisis Skill Match\"**\n3. Sistem menampilkan:\n   - **Matching Percentage**: Persentase kecocokan keseluruhan\n   - **Matched Skills**: Skill yang Anda miliki sesuai kebutuhan\n   - **Missing Skills**: Skill yang kurang\n   - **Extra Skills**: Skill tambahan yang Anda miliki\n\nSemakin tinggi persentase, semakin besar peluang Anda dipanggil interview.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['skill match', 'kecocokan', 'matching', 'cocok', 'persentase', 'match'],
                'deep_links' => [
                    ['label' => 'Cari Lowongan', 'url' => '/seeker/jobs'],
                ],
                'priority' => 7,
            ],
            [
                'question' => 'Bagaimana cara melihat status lamaran saya?',
                'answer' => "Untuk melihat status lamaran:\n\n1. Buka menu **\"Job Vacancies\"** di sidebar\n2. Klik tab **\"Lamaran Saya\"**\n3. Anda akan melihat daftar lamaran beserta statusnya:\n   - **Disimpan**: Lowongan yang Anda simpan (belum melamar)\n   - **Dikirim**: Lamaran sudah dikirim\n   - **Ditinjau**: Perusahaan sedang meninjau lamaran Anda\n   - **Interview**: Anda dipanggil interview\n   - **Diterima**: Anda mendapat tawaran kerja\n   - **Ditolak**: Lamaran tidak berhasil\n\nAnda juga bisa **menarik lamaran** jika sudah tidak berminat.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['status', 'lamaran', 'melamar', 'progress', 'tracking', 'pantau'],
                'deep_links' => [
                    ['label' => 'Lamaran Saya', 'url' => '/seeker/jobs/my-applications'],
                ],
                'priority' => 8,
            ],

            // COURSES
            [
                'question' => 'Apa itu fitur Courses dan bagaimana cara menggunakannya?',
                'answer' => "**Courses** adalah fitur untuk mengikuti kursus online yang direkomendasikan berdasarkan skill gap Anda.\n\n**Fitur yang tersedia:**\n- **Daftar Kursus**: Kursus dari berbagai platform\n- **Rekomendasi**: Kursus yang sesuai dengan kebutuhan Anda\n- **Enrollment**: Daftar kursus yang diminati\n- **Progress Tracking**: Pantau kemajuan belajar\n- **Completion**: Tandai kursus yang sudah selesai\n\n**Cara menggunakan:**\n1. Buka menu **\"Courses\"** di sidebar\n2. Cari kursus yang diminati\n3. Klik **\"Enroll\"** untuk mendaftar\n4. Klik **\"Mulai Belajar\"** untuk membuka materi\n5. Update progress secara berkala\n6. Klik **\"Selesai\"** jika sudah menyelesaikan kursus\n\nKursus yang selesai akan menambah poin di profil Anda.",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['kursus', 'course', 'belajar', 'pelatihan', 'training', 'enroll'],
                'deep_links' => [
                    ['label' => 'Daftar Kursus', 'url' => '/seeker/courses'],
                    ['label' => 'Progress Saya', 'url' => '/seeker/courses/my-progress'],
                ],
                'priority' => 8,
            ],

            // LAPORAN
            [
                'question' => 'Bagaimana cara download laporan assessment?',
                'answer' => "Untuk download laporan assessment dalam format PDF:\n\n1. Buka menu **\"Competency Assessment\"**\n2. Klik **\"Riwayat Assessment\"**\n3. Pilih assessment yang ingin diunduh\n4. Klik tombol **\"Download PDF\"**\n\nLaporan berisi:\n- Hasil skill gap per kompetensi\n- Skor keseluruhan\n- Rekomendasi kursus\n- Grafik visualisasi",
                'category' => 'job_seeker',
                'roles' => ['job_seeker'],
                'keywords' => ['laporan', 'report', 'download', 'pdf', 'assessment', 'unduh'],
                'deep_links' => [
                    ['label' => 'Riwayat Assessment', 'url' => '/seeker/assessment/history'],
                ],
                'priority' => 6,
            ],
        ];
    }

    // ==================== INDUSTRY ====================
    protected function industryFaqs(): array
    {
        return [
            // DASHBOARD
            [
                'question' => 'Apa yang ada di Dashboard Industry?',
                'answer' => "Dashboard Industry menampilkan:\n\n1. **Statistik Lowongan** - Jumlah lowongan aktif, total pelamar\n2. **Pipeline Rekrutmen** - Pelamar per status (applied/reviewed/interviewed/offered)\n3. **Pelamar Terbaru** - Daftar pelamar terbaru\n4. **Grafik Rekrutmen** - Visualisasi data rekrutmen\n5. **Download Laporan** - Export laporan rekrutmen ke Excel\n\nDashboard adalah pusat kontrol untuk mengelola proses rekrutmen.",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager', 'staf_recruiter'],
                'keywords' => ['dashboard', 'halaman utama', 'beranda', 'statistik', 'ringkasan'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/industry/dashboard'],
                ],
                'priority' => 8,
            ],

            // POSTING LOWONGAN
            [
                'question' => 'Bagaimana cara posting lowongan kerja?',
                'answer' => "Untuk memposting lowongan kerja:\n\n1. Buka menu **\"Post Job\"** di sidebar\n2. Klik **\"Buat Lowongan Baru\"**\n3. Isi formulir:\n   - **Judul lowongan** (wajib)\n   - **Deskripsi pekerjaan** - tanggung jawab utama\n   - **Persyaratan** - kualifikasi yang dibutuhkan\n   - **Skill yang dibutuhkan** - pilih dari daftar\n   - **Lokasi** - kota atau alamat\n   - **Tipe kerja** - Remote / Onsite / Hybrid\n   - **Range gaji** - minimum dan maksimum\n   - **Tanggal berakhir** - batas waktu lamaran\n4. Klik **\"Simpan\"**\n\nLowongan akan langsung aktif dan terlihat oleh job seeker. Job seeker yang skill-nya cocok akan mendapat notifikasi.",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager'],
                'keywords' => ['posting', 'lowongan', 'kerja', 'pekerjaan', 'job', 'vacancy', 'buat', 'baru'],
                'deep_links' => [
                    ['label' => 'Posting Lowongan', 'url' => '/industry/jobs/create'],
                    ['label' => 'Daftar Lowongan', 'url' => '/industry/jobs'],
                ],
                'priority' => 10,
            ],
            [
                'question' => 'Bagaimana cara mengedit atau menghapus lowongan?',
                'answer' => "Untuk mengedit atau menghapus lowongan:\n\n1. Buka menu **\"Post Job\"** di sidebar\n2. Cari lowongan yang ingin diubah\n3. Klik tombol **\"Edit\"** (ikon pensil) untuk mengedit\n4. Ubah data yang diperlukan\n5. Klik **\"Simpan\"**\n\nUntuk menghapus:\n1. Klik tombol **\"Hapus\"** (ikon tempat sampah)\n2. Konfirmasi penghapusan\n\n**Catatan:** Lowongan yang sudah memiliki pelamar sebaiknya di-nonaktifkan, bukan dihapus.",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager'],
                'keywords' => ['edit', 'hapus', 'ubah', 'lowongan', 'manage', 'kelola'],
                'deep_links' => [
                    ['label' => 'Daftar Lowongan', 'url' => '/industry/jobs'],
                ],
                'priority' => 7,
            ],

            // KANDIDAT
            [
                'question' => 'Bagaimana cara melihat dan mengelola kandidat?',
                'answer' => "Untuk melihat dan mengelola kandidat:\n\n1. Buka menu **\"Search Candidates\"** di sidebar\n2. Anda akan melihat daftar pelamar beserta:\n   - Nama dan kontak\n   - Posisi yang dilamar\n   - **Matching percentage** - kecocokan dengan lowongan\n   - Status lamaran\n3. Klik nama kandidat untuk melihat **profil lengkap**\n4. Di halaman profil, Anda bisa:\n   - Melihat CV dan dokumen\n   - Melihat skill dan assessment\n   - **Mengubah status lamaran** (reviewed/interviewed/offered/rejected)\n   - **Mengundang ke TPA**\n   - **Mengirim tawaran kerja** langsung\n\n**Filter yang tersedia:**\n- Berdasarkan lowongan\n- Berdasarkan status lamaran\n- Berdasarkan matching percentage",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager', 'staf_recruiter', 'staf_talent_sourcer'],
                'keywords' => ['kandidat', 'candidate', 'pelamar', 'cari', 'search', 'manage', 'kelola'],
                'deep_links' => [
                    ['label' => 'Daftar Kandidat', 'url' => '/industry/candidates'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Bagaimana cara mengubah status lamaran kandidat?',
                'answer' => "Untuk mengubah status lamaran:\n\n1. Buka halaman profil kandidat\n2. Di sidebar kanan, cari bagian **\"Status Lamaran\"**\n3. Klik tombol status yang diinginkan:\n   - **\"Tinjau\"** - Lamaran sedang ditinjau\n   - **\"Interview\"** - Jadwalkan interview\n   - **\"Terima\"** - Berikan tawaran kerja\n   - **\"Tolak\"** - Tolak lamaran\n4. Konfirmasi perubahan status\n\nKandidat akan mendapat notifikasi setiap kali status berubah.",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager', 'staf_recruiter'],
                'keywords' => ['status', 'lamaran', 'ubah', 'change', 'review', 'interview', 'offer', 'reject'],
                'deep_links' => [
                    ['label' => 'Kandidat', 'url' => '/industry/candidates'],
                ],
                'priority' => 8,
            ],

            // TIM
            [
                'question' => 'Bagaimana cara mengelola tim rekrutmen?',
                'answer' => "Untuk mengelola tim rekrutmen:\n\n1. Buka menu **\"Manage Team\"** di sidebar\n2. Klik **\"Undang Staff\"**\n3. Masukkan **email** staff baru\n4. Pilih **role**:\n   - **HR Manager**: Akses penuh ke semua fitur\n   - **Recruiter**: Lihat kandidat, jadwalkan interview\n   - **Talent Sourcer**: Lihat kandidat saja\n   - **Interviewer**: Lihat kandidat, beri feedback\n5. Klik **\"Kirim Undangan\"**\n\nStaff akan menerima email undangan. Setelah bergabung, mereka bisa mengakses dashboard industry sesuai permission-nya.\n\n**Mengelola Staff:**\n- **Ubah Role**: Klik nama staff → pilih role baru\n- **Hapus Staff**: Klik tombol \"Hapus\" di sebelah nama staff",
                'category' => 'industry',
                'roles' => ['industry'],
                'keywords' => ['tim', 'team', 'staff', 'undang', 'invite', 'kelola', 'manage', 'hr', 'recruiter'],
                'deep_links' => [
                    ['label' => 'Kelola Tim', 'url' => '/industry/team'],
                ],
                'priority' => 8,
            ],

            // LAPORAN
            [
                'question' => 'Bagaimana cara download laporan rekrutmen?',
                'answer' => "Untuk download laporan rekrutmen:\n\n1. Buka menu **\"Dashboard\"**\n2. Klik tombol **\"Download Laporan\"** di pojok kanan atas\n3. Pilih format: **Excel** (.xlsx)\n4. File akan terdownload otomatis\n\nLaporan berisi:\n- Daftar lowongan dan status\n- Statistik pelamar per lowongan\n- Pipeline rekrutmen\n- Data kandidat\n\nAnda juga bisa download laporan per lowongan dari halaman detail lowongan.",
                'category' => 'industry',
                'roles' => ['industry', 'staf_hr_manager'],
                'keywords' => ['laporan', 'report', 'download', 'excel', 'rekrutmen', 'export'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/industry/dashboard'],
                ],
                'priority' => 6,
            ],
        ];
    }

    // ==================== EDUCATION ====================
    protected function educationFaqs(): array
    {
        return [
            // DASHBOARD
            [
                'question' => 'Apa yang ada di Dashboard Education?',
                'answer' => "Dashboard Education menampilkan:\n\n1. **Statistik Institusi** - Jumlah mahasiswa, kursus, program\n2. **Analytics** - Data enrollment dan completion rate\n3. **Kolaborasi Terbaru** - Status proposal kolaborasi\n4. **Quick Actions** - Aksi cepat untuk membuat kursus/program\n\nDashboard adalah pusat kontrol untuk mengelola institusi pendidikan.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['dashboard', 'halaman utama', 'beranda', 'statistik', 'analytics'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/education/dashboard'],
                ],
                'priority' => 8,
            ],

            // KURSUS
            [
                'question' => 'Bagaimana cara mengelola kursus?',
                'answer' => "Untuk mengelola kursus:\n\n**Membuat Kursus Baru:**\n1. Buka menu **\"Courses\"** di sidebar\n2. Klik **\"Buat Kursus Baru\"**\n3. Isi formulir:\n   - Judul kursus\n   - Deskripsi\n   - Platform (Coursera, Udemy, Custom, dll)\n   - URL kursus\n   - Level (Pemula/Menengah/Lanjutan)\n   - Harga\n   - Rating\n4. Klik **\"Simpan\"**\n\n**Mengedit/Menghapus:**\n1. Buka daftar kursus\n2. Klik **\"Edit\"** atau **\"Hapus\"** pada kursus yang diinginkan\n\nKursus yang Anda buat akan muncul di rekomendasi untuk job seeker yang membutuhkan kompetensi terkait.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['kursus', 'course', 'kelola', 'manage', 'buat', 'tambah', 'edit'],
                'deep_links' => [
                    ['label' => 'Kelola Kursus', 'url' => '/education/courses'],
                    ['label' => 'Buat Kursus', 'url' => '/education/courses/create'],
                ],
                'priority' => 9,
            ],

            // PROGRAM
            [
                'question' => 'Bagaimana cara membuat program pendidikan?',
                'answer' => "Untuk membuat program pendidikan:\n\n1. Buka menu **\"Program\"** di sidebar\n2. Klik **\"Buat Program Baru\"**\n3. Isi formulir:\n   - **Judul program**\n   - **Tipe**: Bootcamp / Sertifikasi / Workshop / Kursus\n   - **Deskripsi**\n   - **Tanggal mulai & selesai**\n   - **Biaya**\n   - **Jumlah peserta maksimal**\n4. Klik **\"Simpan\"**\n\nProgram akan terlihat oleh job seeker yang membutuhkan pengembangan skill.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['program', 'pendidikan', 'bootcamp', 'sertifikasi', 'workshop', 'buat', 'baru'],
                'deep_links' => [
                    ['label' => 'Kelola Program', 'url' => '/education/programs'],
                    ['label' => 'Buat Program', 'url' => '/education/programs/create'],
                ],
                'priority' => 8,
            ],

            // PARTNER
            [
                'question' => 'Bagaimana cara mencari mitra industri?',
                'answer' => "Untuk mencari mitra industri:\n\n1. Buka menu **\"Partners\"** di sidebar\n2. Anda akan melihat daftar perusahaan yang bisa dijadikan mitra\n3. Gunakan **filter** untuk mencari:\n   - Bidang industri\n   - Lokasi\n   - Ukuran perusahaan\n4. Klik perusahaan untuk melihat **profil lengkap**\n5. Klik **\"Ajukan Kerjasama\"** untuk mengirim proposal\n\nAnda juga bisa melihat lowongan aktif dari perusahaan tersebut.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['mitra', 'partner', 'industri', 'cari', 'perusahaan', 'kolaborasi'],
                'deep_links' => [
                    ['label' => 'Cari Mitra', 'url' => '/education/partners'],
                ],
                'priority' => 7,
            ],

            // KOLABORASI
            [
                'question' => 'Bagaimana cara mengajukan kolaborasi dengan industri?',
                'answer' => "Untuk mengajukan kolaborasi:\n\n1. Buka menu **\"Partners\"** di sidebar\n2. Cari perusahaan yang ingin diajak kerjasama\n3. Klik **\"Lihat Profil\"** perusahaan\n4. Klik **\"Ajukan Kerjasama\"**\n5. Isi formulir proposal:\n   - **Judul kerjasama**\n   - **Tipe**: Magang / Pelatihan / Riset / Lainnya\n   - **Deskripsi** rencana kerjasama\n6. Klik **\"Kirim Proposal\"**\n\nPerusahaan akan menerima email notifikasi dan bisa merespon proposal Anda.\n\n**Melihat Status:**\nBuka menu **\"Collaboration\"** → **\"Riwayat Proposal\"** untuk melihat status proposal yang sudah dikirim.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['kolaborasi', 'kerjasama', 'mitra', 'partner', 'proposal', 'ajukan'],
                'deep_links' => [
                    ['label' => 'Cari Mitra', 'url' => '/education/partners'],
                    ['label' => 'Riwayat Proposal', 'url' => '/education/collaboration/history'],
                ],
                'priority' => 8,
            ],

            // MAHASISWA
            [
                'question' => 'Bagaimana cara melihat data mahasiswa?',
                'answer' => "Untuk melihat data mahasiswa:\n\n1. Buka menu **\"Students\"** di sidebar\n2. Anda akan melihat daftar mahasiswa yang terkait dengan institusi Anda\n3. Data yang tersedia:\n   - Nama dan kontak\n   - Program studi\n   - Status enrollment\n   - Progress kursus\n\nMahasiswa terhubung ke institusi melalui `institution_id` di profil mereka.",
                'category' => 'education',
                'roles' => ['education'],
                'keywords' => ['mahasiswa', 'student', 'siswa', 'data', 'lihat', 'daftar'],
                'deep_links' => [
                    ['label' => 'Data Mahasiswa', 'url' => '/education/students'],
                ],
                'priority' => 7,
            ],
        ];
    }

    // ==================== ADMIN ====================
    protected function adminFaqs(): array
    {
        return [
            // DASHBOARD
            [
                'question' => 'Apa yang ada di Dashboard Admin?',
                'answer' => "Dashboard Admin menampilkan:\n\n1. **Statistik Sistem** - Total user, lowongan, assessment\n2. **User per Role** - Jumlah user per role\n3. **Grafik Aktivitas** - Aktivitas sistem terbaru\n4. **Quick Actions** - Aksi cepat untuk manajemen\n\nAdmin memiliki akses penuh ke seluruh sistem.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['dashboard', 'admin', 'statistik', 'sistem'],
                'deep_links' => [
                    ['label' => 'Dashboard', 'url' => '/admin/dashboard'],
                ],
                'priority' => 8,
            ],

            // USER
            [
                'question' => 'Bagaimana cara mengelola user?',
                'answer' => "Untuk mengelola user:\n\n1. Buka menu **\"Users\"** di sidebar\n2. Anda akan melihat daftar semua user\n3. **Filter** berdasarkan role, status, atau pencarian\n4. **Membuat User Baru:**\n   - Klik \"Tambah User\"\n   - Isi data: nama, email, password, role\n   - Klik \"Simpan\"\n5. **Mengedit User:**\n   - Klik \"Edit\" pada user\n   - Ubah data yang diperlukan\n   - Klik \"Simpan\"\n6. **Menghapus User:**\n   - Klik \"Hapus\" pada user\n   - Konfirmasi penghapusan\n\n**Role yang tersedia:**\n- admin, job_seeker, industry, education\n- staf_hr_manager, staf_recruiter, staf_talent_sourcer, staf_interviewer",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['user', 'pengguna', 'kelola', 'manage', 'tambah', 'edit', 'hapus'],
                'deep_links' => [
                    ['label' => 'Kelola User', 'url' => '/admin/users'],
                ],
                'priority' => 10,
            ],

            // KOMPETENSI
            [
                'question' => 'Bagaimana cara mengelola kompetensi?',
                'answer' => "Untuk mengelola kompetensi:\n\n1. Buka menu **\"Competencies\"** di sidebar\n2. **Menambah Kompetensi:**\n   - Klik \"Tambah Kompetensi\"\n   - Isi: kode, nama, kategori (technical/soft_skill)\n   - Pilih posisi terkait\n   - Tentukan level minimum (1-5)\n   - Klik \"Simpan\"\n3. **Mengedit:** Klik \"Edit\" pada kompetensi\n4. **Menghapus:** Klik \"Hapus\" pada kompetensi\n\nKompetensi digunakan dalam assessment untuk mengukur skill gap job seeker.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['kompetensi', 'competency', 'skill', 'kelola', 'manage', 'tambah'],
                'deep_links' => [
                    ['label' => 'Kelola Kompetensi', 'url' => '/admin/competencies'],
                ],
                'priority' => 9,
            ],

            // KATEGORI
            [
                'question' => 'Bagaimana cara mengelola kategori?',
                'answer' => "Untuk mengelola kategori:\n\n1. Buka menu **\"Categories\"** di sidebar\n2. Kategori digunakan untuk mengelompokkan:\n   - **Kompetensi** (technical, soft_skill)\n   - **Posisi** (IT, Marketing, Finance, dll)\n3. **CRUD** standar: Tambah, Edit, Hapus\n\nKategori membantu organisasi data dalam sistem.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['kategori', 'category', 'kelola', 'manage'],
                'deep_links' => [
                    ['label' => 'Kelola Kategori', 'url' => '/admin/categories'],
                ],
                'priority' => 6,
            ],

            // POSISI
            [
                'question' => 'Bagaimana cara mengelola posisi?',
                'answer' => "Untuk mengelola posisi:\n\n1. Buka menu **\"Positions\"** di sidebar\n2. Posisi adalah jabatan/pekerjaan yang tersedia\n3. Setiap posisi memiliki:\n   - Nama posisi (misal: Web Developer)\n   - Deskripsi\n   - Kategori terkait\n   - Daftar kompetensi yang dibutuhkan\n4. **CRUD** standar: Tambah, Edit, Hapus\n\nPosisi digunakan dalam assessment dan lowongan kerja.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['posisi', 'position', 'jabatan', 'pekerjaan', 'kelola'],
                'deep_links' => [
                    ['label' => 'Kelola Posisi', 'url' => '/admin/positions'],
                ],
                'priority' => 7,
            ],

            // SKILL KEYWORDS
            [
                'question' => 'Apa itu Skill Keywords dan bagaimana mengelolanya?',
                'answer' => "**Skill Keywords** adalah daftar kata kunci yang digunakan oleh AI untuk mengekstrak skill dari CV dan dokumen.\n\n**Cara mengelola:**\n1. Buka menu **\"Skill Keywords\"** di sidebar\n2. **Menambah Keyword:**\n   - Klik \"Tambah Keyword\"\n   - Isi: kategori (programming, design, dll)\n   - Isi: keyword (misal: \"laravel\", \"php\")\n   - Klik \"Simpan\"\n3. **Mengedit/Menghapus:** Klik tombol yang sesuai\n\n**Mengapa penting?**\nSemakin lengkap keyword, semakin akurat AI dalam mengekstrak skill dari CV kandidat.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['skill', 'keyword', 'kata kunci', 'ai', 'nlp', 'ekstraksi'],
                'deep_links' => [
                    ['label' => 'Skill Keywords', 'url' => '/admin/skill-keywords'],
                ],
                'priority' => 8,
            ],

            // DOCUMENT WEIGHTS
            [
                'question' => 'Apa itu Document Weights?',
                'answer' => "**Document Weights** adalah konfigurasi bobot penilaian dokumen kandidat.\n\n**Dokumen yang dinilai:**\n- CV\n- Ijazah\n- Transkrip\n- Sertifikat\n- Portofolio\n\n**Cara kerja:**\nSetiap dokumen dianalisis oleh AI dan diberi skor. Skor akhir kandidat dihitung berdasarkan bobot yang Anda konfigurasi.\n\n**Mengelola:**\n1. Buka menu **\"Document Weights\"**\n2. Atur bobot untuk setiap dokumen (total harus 100%)\n3. Klik \"Simpan\"\n\nBobot default bisa di-override per lowongan oleh industry.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['document', 'weight', 'bobot', 'dokumen', 'penilaian', 'scoring'],
                'deep_links' => [
                    ['label' => 'Document Weights', 'url' => '/admin/document-weights'],
                ],
                'priority' => 7,
            ],

            // AI WORKFLOW
            [
                'question' => 'Apa itu AI Workflow dan bagaimana cara memantaunya?',
                'answer' => "**AI Workflow** adalah halaman diagnostik untuk memantau dan menguji integrasi AI.\n\n**Fitur yang tersedia:**\n1. **Test Koneksi** - Cek apakah Python AI service berjalan\n2. **Test Ekstraksi** - Uji ekstraksi text dari dokumen\n3. **Test Analisis** - Uji analisis skill dari text\n4. **Debug Pipeline** - Lihat detail proses AI\n5. **User Documents** - Lihat dokumen yang sudah dianalisis\n\n**Cara menggunakan:**\n1. Buka menu **\"AI Workflow\"** di sidebar\n2. Pilih test yang ingin dijalankan\n3. Klik \"Jalankan Diagnostik\"\n4. Lihat hasil di halaman yang sama",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['ai', 'workflow', 'diagnostik', 'diagnostic', 'test', 'monitoring'],
                'deep_links' => [
                    ['label' => 'AI Workflow', 'url' => '/admin/ai-workflow'],
                ],
                'priority' => 7,
            ],

            // SETTINGS
            [
                'question' => 'Apa yang ada di halaman Settings?',
                'answer' => "Halaman **Settings** memungkinkan admin mengkonfigurasi:\n\n1. **Pengaturan Kompetensi**\n   - Update level kompetensi\n   - Sinkronisasi kompetensi\n\n2. **Pengaturan Sistem**\n   - Konfigurasi umum aplikasi\n   - Pengaturan AI\n\n**Cara mengakses:**\n1. Buka menu **\"Settings\"** di sidebar\n2. Ubah pengaturan yang diperlukan\n3. Klik \"Simpan\"",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['settings', 'pengaturan', 'konfigurasi', 'setting', 'config'],
                'deep_links' => [
                    ['label' => 'Settings', 'url' => '/admin/settings'],
                ],
                'priority' => 6,
            ],

            // REPORTS
            [
                'question' => 'Bagaimana cara melihat dan mengirim laporan?',
                'answer' => "Untuk melihat laporan:\n\n1. Buka menu **\"Reports\"** di sidebar\n2. Lihat laporan sistem secara keseluruhan\n3. Filter berdasarkan periode atau kategori\n\n**Mengirim Laporan via Email:**\n1. Klik tombol **\"Kirim Laporan\"**\n2. Masukkan email tujuan\n3. Pilih format laporan\n4. Klik \"Kirim\"\n\nLaporan akan dikirim sebagai attachment email.",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['laporan', 'report', 'kirim', 'email', 'export'],
                'deep_links' => [
                    ['label' => 'Laporan', 'url' => '/admin/reports'],
                ],
                'priority' => 6,
            ],

            // CHAT FAQ
            [
                'question' => 'Bagaimana cara mengelola FAQ Chat Agent?',
                'answer' => "Untuk mengelola FAQ Chat Agent:\n\n1. Buka menu **\"Chat FAQ\"** di sidebar\n2. **Menambah FAQ:**\n   - Klik \"Tambah FAQ\"\n   - Isi: pertanyaan, jawaban, kategori\n   - Tentukan role yang bisa melihat\n   - Tambahkan keywords untuk pencarian\n   - Tambahkan deep links (opsional)\n   - Atur prioritas (0-100)\n   - Klik \"Simpan\"\n3. **Mengedit:** Klik \"Edit\" pada FAQ\n4. **Menghapus:** Klik \"Hapus\" pada FAQ\n\n**Tips:**\n- Gunakan keywords yang relevan untuk pencarian akurat\n- Set prioritas lebih tinggi untuk FAQ yang sering ditanyakan\n- Tambahkan deep links untuk navigasi langsung ke fitur terkait",
                'category' => 'admin',
                'roles' => ['admin'],
                'keywords' => ['faq', 'chat', 'agent', 'kelola', 'manage', 'pertanyaan', 'jawaban'],
                'deep_links' => [
                    ['label' => 'Chat FAQ', 'url' => '/admin/chat-faqs'],
                ],
                'priority' => 7,
            ],
        ];
    }

    // ==================== TPA ====================
    protected function tpaFaqs(): array
    {
        return [
            // TPA UMUM
            [
                'question' => 'Apa itu Tes TPA?',
                'answer' => "**TPA (Tes Potensi Akademik)** adalah tes yang mengukur kemampuan berpikir logis, analitis, numerik, dan verbal.\n\n**4 Kategori Soal:**\n1. **Verbal** (30%) - Sinonim, Antonim, Analogi, Pengelompokan Kata\n2. **Numerik** (30%) - Aritmetik, Deret Angka, Soal Cerita\n3. **Logika** (20%) - Silogisme, Deduktif, Analitis\n4. **Spasial** (20%) - Pola Gambar, Rotasi, Bayangan Cermin\n\n**Informasi Tes:**\n- Soal pilihan ganda (A/B/C/D)\n- Ada batas waktu (biasanya 60 menit)\n- Passing score ditentukan oleh perusahaan (biasanya 60%)\n- Hasil langsung terlihat setelah selesai\n\n**Skor Bappenas:**\n- Range: 200-800\n- Rata-rata nasional: 500\n- Baik: 600+\n- Sangat baik: 700+",
                'category' => 'tpa',
                'roles' => ['job_seeker', 'industry'],
                'keywords' => ['tpa', 'tes', 'potensi', 'akademik', 'ujian', 'test', 'apa itu'],
                'deep_links' => [
                    ['label' => 'Tes TPA Saya', 'url' => '/seeker/tpa'],
                    ['label' => 'Assessment Skill', 'url' => '/seeker/assessment'],
                ],
                'priority' => 10,
            ],

            // TPA JOB SEEKER
            [
                'question' => 'Bagaimana cara mengerjakan Tes TPA?',
                'answer' => "Cara mengerjakan Tes TPA:\n\n1. Buka menu **\"Tes TPA\"** di sidebar\n2. Klik **\"Mulai Tes\"** pada undangan yang tersedia\n3. Timer akan berjalan otomatis\n4. **Navigasi soal:**\n   - Klik tombol \"Selanjutnya\" atau \"Sebelumnya\"\n   - Klik nomor soal di panel navigasi\n5. **Menjawab:** Klik pilihan A/B/C/D\n6. **Tandai soal:** Klik bintang untuk review nanti\n7. Jawaban **tersimpan otomatis**\n8. Klik **\"Selesai\"** jika sudah selesai\n9. Konfirmasi submit\n\n**Tips:**\n- Kerjakan soal yang mudah terlebih dahulu\n- Jangan terlalu lama di satu soal (< 1 menit/soal)\n- Perhatikan sisa waktu di timer\n- Jangan keluar dari halaman tes\n- Tandai soal yang ragu untuk review nanti",
                'category' => 'tpa',
                'roles' => ['job_seeker'],
                'keywords' => ['tpa', 'kerjakan', 'mengerjakan', 'cara', 'ujian', 'tes', 'mulai', 'test'],
                'deep_links' => [
                    ['label' => 'Tes TPA Saya', 'url' => '/seeker/tpa'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Apa yang terjadi jika saya tidak lulus TPA?',
                'answer' => "Jika Anda tidak lulus TPA (skor < passing score):\n\n1. **Status lamaran** bisa berubah menjadi \"failed\" (tergantung kebijakan perusahaan)\n2. **Anda tetap bisa** melamar lowongan lain yang tidak menggunakan TPA\n3. **Anda bisa mengulang** TPA jika perusahaan mengirim undangan baru\n\n**Tips untuk meningkatkan skor:**\n- Latihan soal TPA secara rutin\n- Fokus pada kategori yang lemah\n- Pelajari pola soal verbal, numerik, logika, spasial\n- Manajemen waktu yang baik saat tes",
                'category' => 'tpa',
                'roles' => ['job_seeker'],
                'keywords' => ['tpa', 'gagal', 'tidak lulus', 'fail', 'skor', 'rendah'],
                'deep_links' => [
                    ['label' => 'Tes TPA Saya', 'url' => '/seeker/tpa'],
                ],
                'priority' => 7,
            ],

            // TPA INDUSTRY
            [
                'question' => 'Bagaimana cara membuat Tes TPA?',
                'answer' => "Untuk membuat Tes TPA:\n\n1. Buka menu **\"Tes TPA\"** di sidebar\n2. Klik **\"Buat Tes Baru\"**\n3. Isi formulir:\n   - **Judul tes** (misal: \"TPA Software Engineer\")\n   - **Deskripsi** (opsional)\n   - **Lowongan terkait** (opsional)\n   - **Durasi** (dalam menit, default 60)\n   - **Passing score** (%, default 60)\n   - **Jumlah soal per kategori** (Verbal, Numerik, Logika, Spasial)\n   - **Bobot per kategori** (total harus 100%)\n4. Atur **pengaturan:**\n   - Acak urutan soal\n   - Acak pilihan jawaban\n   - Tampilkan hasil setelah selesai\n5. Klik **\"Simpan\"**\n\nTes yang dibuat bisa digunakan untuk mengundang kandidat ke TPA.",
                'category' => 'tpa',
                'roles' => ['industry'],
                'keywords' => ['tpa', 'buat', 'membuat', 'tes', 'test', 'konfigurasi', 'setting'],
                'deep_links' => [
                    ['label' => 'Buat Tes TPA', 'url' => '/industry/tpa/create'],
                    ['label' => 'Daftar Tes', 'url' => '/industry/tpa'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Bagaimana cara mengundang kandidat ke TPA?',
                'answer' => "Untuk mengundang kandidat ke TPA:\n\n1. Buka menu **\"Tes TPA\"** → tab **\"Kirim Undangan\"**\n2. Pilih **Tipe Tes** (Online/Offline)\n3. Pilih **Tes TPA** yang akan digunakan\n4. Centang **kandidat** yang ingin diundang\n5. Klik **\"Kirim Undangan\"**\n\n**Tipe Undangan:**\n- **Online**: Kandidat mengerjakan tes di browser\n- **Offline**: Kandidat datang ke lokasi tes (perlu isi jadwal, lokasi, PIC)\n\nKandidat akan menerima notifikasi dan bisa mengerjakan tes.",
                'category' => 'tpa',
                'roles' => ['industry'],
                'keywords' => ['tpa', 'undang', 'invite', 'kirim', 'kandidat', 'tes'],
                'deep_links' => [
                    ['label' => 'Kirim Undangan', 'url' => '/industry/tpa'],
                ],
                'priority' => 9,
            ],
            [
                'question' => 'Bagaimana cara melihat hasil TPA kandidat?',
                'answer' => "Untuk melihat hasil TPA kandidat:\n\n1. Buka menu **\"Tes TPA\"** → tab **\"Riwayat Undangan\"**\n2. Anda akan melihat daftar kandidat yang sudah mengerjakan tes\n3. Klik **\"Detail Hasil\"** pada kandidat\n4. Hasil menampilkan:\n   - **Skor per kategori** (Verbal, Numerik, Logika, Spasial)\n   - **Skor total** (weighted)\n   - **Skor Bappenas** (200-800)\n   - **Status** (Lulus/Tidak Lulus)\n   - **Detail jawaban** per soal\n5. Klik **\"Download PDF\"** untuk mengunduh laporan\n\nAnda juga bisa filter hasil berdasarkan tes atau status kelulusan.",
                'category' => 'tpa',
                'roles' => ['industry'],
                'keywords' => ['tpa', 'hasil', 'result', 'kandidat', 'skor', 'lihat', 'download'],
                'deep_links' => [
                    ['label' => 'Hasil TPA', 'url' => '/industry/tpa/results'],
                ],
                'priority' => 8,
            ],
        ];
    }
}
