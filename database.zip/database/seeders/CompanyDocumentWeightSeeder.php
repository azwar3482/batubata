<?php

namespace Database\Seeders;

use App\Models\CompanyDocumentWeight;
use Illuminate\Database\Seeder;

class CompanyDocumentWeightSeeder extends Seeder
{
    public function run(): void
    {
        // Konfigurasi DEFAULT untuk semua perusahaan (company_id = null)
        CompanyDocumentWeight::updateOrCreate(
            ['company_id' => null],
            [
                'name' => 'Default (Semua Perusahaan)',
                'cv_weight' => 50.00,
                'ijazah_weight' => 20.00,
                'transkrip_weight' => 15.00,
                'sertifikat_weight' => 10.00,
                'portofolio_weight' => 5.00,
                'is_active' => true,
            ]
        );

        // Contoh konfigurasi khusus untuk Startup Teknologi (company_id = 1)
        CompanyDocumentWeight::updateOrCreate(
            ['company_id' => 1],
            [
                'name' => 'Startup Teknologi (Portofolio Prioritas)',
                'cv_weight' => 30.00,
                'ijazah_weight' => 10.00,
                'transkrip_weight' => 10.00,
                'sertifikat_weight' => 20.00,
                'portofolio_weight' => 30.00,
                'is_active' => true,
            ]
        );

        // Contoh konfigurasi untuk Perusahaan Keuangan/BUMN (ijazah & transkrip prioritas)
        CompanyDocumentWeight::updateOrCreate(
            ['company_id' => 2],
            [
                'name' => 'Perusahaan BUMN/Keuangan (Akademik Prioritas)',
                'cv_weight' => 35.00,
                'ijazah_weight' => 30.00,
                'transkrip_weight' => 25.00,
                'sertifikat_weight' => 5.00,
                'portofolio_weight' => 5.00,
                'is_active' => true,
            ]
        );
    }
}
