<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Teknis', 'type' => 'competency', 'description' => 'Kompetensi teknis terkait pemrograman, data, dan teknologi'],
            ['name' => 'Soft Skill', 'type' => 'competency', 'description' => 'Kompetensi non-teknis seperti komunikasi, kepemimpinan, dan kerja tim'],
            ['name' => 'Teknologi Informasi', 'type' => 'industry', 'description' => 'Industri teknologi informasi dan perangkat lunak'],
            ['name' => 'Keuangan', 'type' => 'industry', 'description' => 'Industri jasa keuangan dan perbankan'],
            ['name' => 'Kesehatan', 'type' => 'industry', 'description' => 'Industri kesehatan dan farmasi'],
            ['name' => 'Pendidikan', 'type' => 'industry', 'description' => 'Industri pendidikan dan pelatihan'],
            ['name' => 'E-Commerce', 'type' => 'industry', 'description' => 'Industri perdagangan elektronik'],
            ['name' => 'Web Developer', 'type' => 'position', 'description' => 'Pengembang aplikasi web frontend dan backend'],
            ['name' => 'Data Analyst', 'type' => 'position', 'description' => 'Analis data dan business intelligence'],
            ['name' => 'UI/UX Designer', 'type' => 'position', 'description' => 'Desainer antarmuka dan pengalaman pengguna'],
            ['name' => 'Mobile Developer', 'type' => 'position', 'description' => 'Pengembang aplikasi mobile iOS dan Android'],
            ['name' => 'DevOps Engineer', 'type' => 'position', 'description' => 'Insinyur operasi pengembangan dan infrastruktur'],
            ['name' => 'Product Manager', 'type' => 'position', 'description' => 'Manajer produk dan strategi digital'],
            ['name' => 'Digital Marketing', 'type' => 'position', 'description' => 'Pemasaran digital dan analisis kampanye'],
        ];

        foreach ($categories as $category) {
            Category::updateOrCreate(
                ['name' => $category['name']],
                $category
            );
        }
    }
}
