<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Company;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class RecruitmentTeamSeeder extends Seeder
{
    public function run(): void
    {
        $companies = Company::all();

        if ($companies->isEmpty()) {
            $this->command->warn('Tidak ada company ditemukan. Jalankan KompskarirSeeder terlebih dahulu.');
            return;
        }

        $staffRoles = [
            'staf_hr_manager',
            'staf_recruiter',
            'staf_talent_sourcer',
            'staf_interviewer',
        ];

        $staffNames = [
            'staf_hr_manager' => ['Rina HR Manager', 'Dian HR Manager', 'Putri HR Manager'],
            'staf_recruiter' => ['Budi Recruiter', 'Siti Recruiter', 'Andi Recruiter'],
            'staf_talent_sourcer' => ['Dewi Sourcer', 'Ahmad Sourcer', 'Rizky Sourcer'],
            'staf_interviewer' => ['Ahmad Interviewer', 'Farhan Interviewer', 'Dimas Interviewer'],
        ];

        $counter = 1;
        foreach ($companies as $company) {
            foreach ($staffRoles as $role) {
                $name = $staffNames[$role][($counter - 1) % 3];
                $emailPrefix = strtolower(explode('@', $company->user->email)[0] ?? 'company');
                
                User::create([
                    'name' => $name . ' ' . $counter,
                    'email' => 'staf_' . $counter . '_' . $emailPrefix . '@' . $company->name . '.id',
                    'password' => Hash::make('password'),
                    'role' => $role,
                    'company_id' => $company->id,
                    'status' => 'active',
                    'email_verified_at' => now(),
                ]);
                $counter++;
            }
        }

        $this->command->info('Recruitment TeamSeeder berhasil!');
        $this->command->info('Staff members created: ' . ($counter - 1));
    }
}
