<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Setting;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // General / Aplikasi
            ['group' => 'general', 'key' => 'app_name', 'value' => 'KOMPASKARIR', 'type' => 'string', 'label' => 'Nama Aplikasi', 'description' => 'Nama yang ditampilkan di aplikasi'],
            ['group' => 'general', 'key' => 'app_locale', 'value' => 'id', 'type' => 'string', 'label' => 'Bahasa Default', 'description' => 'Bahasa default aplikasi (id/en)'],
            ['group' => 'general', 'key' => 'maintenance_mode', 'value' => '0', 'type' => 'boolean', 'label' => 'Mode Maintenance', 'description' => 'Aktifkan mode maintenance'],

            // AI & Analysis
            ['group' => 'ai', 'key' => 'ai_analysis_enabled', 'value' => '1', 'type' => 'boolean', 'label' => 'Aktifkan Analisis AI', 'description' => 'Aktifkan fitur analisis skill berbasis AI'],
            ['group' => 'ai', 'key' => 'ai_service_url', 'value' => 'http://localhost:5000', 'type' => 'string', 'label' => 'URL Service AI', 'description' => 'URL Python AI microservice'],
            ['group' => 'ai', 'key' => 'auto_match_threshold', 'value' => '70', 'type' => 'integer', 'label' => 'Threshold Matching (%)', 'description' => 'Minimum persentase kecocokan untuk rekomendasi'],
            ['group' => 'ai', 'key' => 'skill_gap_max', 'value' => '30', 'type' => 'integer', 'label' => 'Maks Skill Gap (%)', 'description' => 'Maximum skill gap yang diizinkan untuk melamar'],
            ['group' => 'ai', 'key' => 'gemini_api_key', 'value' => '', 'type' => 'string', 'label' => 'Gemini API Key', 'description' => 'API key untuk Google Gemini (Chat Agent)'],
            ['group' => 'ai', 'key' => 'gemini_model', 'value' => 'gemini-2.0-flash', 'type' => 'string', 'label' => 'Model Gemini', 'description' => 'Model Gemini yang digunakan'],

            // Job Rules / Aturan Lamaran
            ['group' => 'job_rules', 'key' => 'require_profile_complete', 'value' => '1', 'type' => 'boolean', 'label' => 'Wajib Profil Lengkap', 'description' => 'Profil harus 100% untuk melamar'],
            ['group' => 'job_rules', 'key' => 'require_assessment', 'value' => '1', 'type' => 'boolean', 'label' => 'Wajib Assessment', 'description' => 'Harus sudah assessment sebelum melamar'],
            ['group' => 'job_rules', 'key' => 'allow_withdraw', 'value' => '1', 'type' => 'boolean', 'label' => 'Izinkan Tarik Lamaran', 'description' => 'Job seeker bisa menarik lamaran'],

            // Notifications / Notifikasi
            ['group' => 'notifications', 'key' => 'email_notifications', 'value' => '1', 'type' => 'boolean', 'label' => 'Notifikasi Email', 'description' => 'Aktifkan notifikasi via email'],
            ['group' => 'notifications', 'key' => 'notify_new_application', 'value' => '1', 'type' => 'boolean', 'label' => 'Notifikasi Lamaran Baru', 'description' => 'Notifikasi ke industry saat ada lamaran baru'],
            ['group' => 'notifications', 'key' => 'notify_status_change', 'value' => '1', 'type' => 'boolean', 'label' => 'Notifikasi Perubahan Status', 'description' => 'Notifikasi ke seeker saat status lamaran berubah'],
            ['group' => 'notifications', 'key' => 'notify_job_match', 'value' => '1', 'type' => 'boolean', 'label' => 'Notifikasi Lowongan Cocok', 'description' => 'Notifikasi ke seeker saat ada lowongan yang cocok'],

            // Security / Keamanan
            ['group' => 'security', 'key' => 'session_lifetime', 'value' => '120', 'type' => 'integer', 'label' => 'Batas Waktu Session (menit)', 'description' => 'Durasi session sebelum expire'],
            ['group' => 'security', 'key' => 'require_email_verification', 'value' => '1', 'type' => 'boolean', 'label' => 'Wajib Verifikasi Email', 'description' => 'User harus verifikasi email sebelum menggunakan aplikasi'],

            // Documents / Dokumen
            ['group' => 'documents', 'key' => 'max_upload_size_mb', 'value' => '10', 'type' => 'integer', 'label' => 'Ukuran Maks Upload (MB)', 'description' => 'Ukuran maksimal file yang bisa diupload'],
            ['group' => 'documents', 'key' => 'allowed_file_types', 'value' => 'pdf,doc,docx,jpg,png', 'type' => 'string', 'label' => 'Tipe File Diizinkan', 'description' => 'Tipe file yang bisa diupload (pisahkan koma)'],
            ['group' => 'documents', 'key' => 'cv_weight', 'value' => '30', 'type' => 'integer', 'label' => 'Bobot CV (%)', 'description' => 'Bobot penilaian CV dalam scoring'],
            ['group' => 'documents', 'key' => 'ijazah_weight', 'value' => '20', 'type' => 'integer', 'label' => 'Bobot Ijazah (%)', 'description' => 'Bobot penilaian ijazah dalam scoring'],
            ['group' => 'documents', 'key' => 'transkrip_weight', 'value' => '15', 'type' => 'integer', 'label' => 'Bobot Transkrip (%)', 'description' => 'Bobot penilaian transkrip dalam scoring'],
            ['group' => 'documents', 'key' => 'sertifikat_weight', 'value' => '20', 'type' => 'integer', 'label' => 'Bobot Sertifikat (%)', 'description' => 'Bobot penilaian sertifikat dalam scoring'],
            ['group' => 'documents', 'key' => 'portofolio_weight', 'value' => '15', 'type' => 'integer', 'label' => 'Bobot Portofolio (%)', 'description' => 'Bobot penilaian portofolio dalam scoring'],

            // TPA Settings
            ['group' => 'tpa', 'key' => 'tpa_default_passing_score', 'value' => '60', 'type' => 'integer', 'label' => 'Passing Score Default (%)', 'description' => 'Passing score default untuk tes TPA'],
            ['group' => 'tpa', 'key' => 'tpa_default_time_limit', 'value' => '60', 'type' => 'integer', 'label' => 'Durasi Default (menit)', 'description' => 'Durasi default tes TPA'],
            ['group' => 'tpa', 'key' => 'tpa_invitation_expiry_hours', 'value' => '48', 'type' => 'integer', 'label' => 'Batas Undangan (jam)', 'description' => 'Batas waktu undangan TPA sebelum expire'],
        ];

        foreach ($settings as $setting) {
            Setting::updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }
}
