<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\JobListing;
use App\Models\UserJobApplication;
use App\Models\Company;
use Illuminate\Support\Str;

class TestLolosApplicantSeeder extends Seeder
{
    public function run()
    {
        // Get or create a company
        $companyUser = User::where('role', 'industry')->first();
        if (!$companyUser) {
            $companyUser = User::create([
                'name' => 'Dummy Company User',
                'email' => 'company_' . Str::random(5) . '@test.com',
                'password' => bcrypt('password'),
                'role' => 'industry',
            ]);
        }
        
        $company = Company::firstOrCreate(
            ['user_id' => $companyUser->id],
            [
                'name' => 'PT Dummy Testing Lolos',
                'industry' => 'Teknologi Informasi',
                'size' => '10-50',
                'website' => 'https://dummytesting.com',
            ]
        );

        // Create 2 Job Listings
        $job1 = JobListing::create([
            'company_id' => $company->id,
            'user_id' => $companyUser->id,
            'title' => 'Software Engineer (Test Lolos 1)',
            'company_name' => $company->name,
            'source_platform' => 'Internal',
            'location' => 'Jakarta',
            'work_type' => 'onsite',
            'experience_required' => '1 Tahun',
            'required_skills' => ['PHP', 'Laravel'],
            'application_url' => 'https://dummytesting.com/apply',
            'description' => 'Testing description 1',
            'posted_date' => now(),
            'expires_date' => now()->addDays(30),
            'is_active' => true,
        ]);

        $job2 = JobListing::create([
            'company_id' => $company->id,
            'user_id' => $companyUser->id,
            'title' => 'Frontend Developer (Test Lolos 2)',
            'company_name' => $company->name,
            'source_platform' => 'Internal',
            'location' => 'Bandung',
            'work_type' => 'onsite',
            'experience_required' => '2 Tahun',
            'required_skills' => ['Vue', 'React'],
            'application_url' => 'https://dummytesting.com/apply',
            'description' => 'Testing description 2',
            'posted_date' => now(),
            'expires_date' => now()->addDays(30),
            'is_active' => true,
        ]);

        // Create 30 Users and apply them to the jobs
        for ($i = 1; $i <= 30; $i++) {
            $user = User::create([
                'name' => 'Pelamar Lolos ' . $i,
                'email' => 'pelamar_lolos_' . $i . '_' . Str::random(4) . '@test.com',
                'password' => bcrypt('password'),
                'role' => 'job_seeker',
                'gender' => $i % 2 == 0 ? 'male' : 'female',
                'phone' => '081234567' . str_pad($i, 3, '0', STR_PAD_LEFT),
            ]);

            // Assign half to job1, half to job2
            $job = $i <= 15 ? $job1 : $job2;

            UserJobApplication::create([
                'user_id' => $user->id,
                'job_listing_id' => $job->id,
                'status' => 'offered',
                'matching_percentage' => rand(80, 100),
                'applied_at' => now()->subDays(rand(1, 10)),
            ]);
        }
    }
}
