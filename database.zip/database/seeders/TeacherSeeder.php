<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\TeacherProfile;
use App\Models\TeacherCourse;
use App\Models\CourseModule;
use App\Models\CourseMaterial;
use App\Models\TeacherClass;
use App\Models\ClassEnrollment;
use App\Models\Submission;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class TeacherSeeder extends Seeder
{
    public function run(): void
    {
        // Create teacher users
        $teachers = [
            [
                'name' => 'Pak Budi Santoso',
                'email' => 'teacher@batubata.test',
                'password' => Hash::make('password'),
                'role' => 'teacher',
            ],
            [
                'name' => 'Ibu Sari Dewi',
                'email' => 'teacher2@batubata.test',
                'password' => Hash::make('password'),
                'role' => 'teacher',
            ],
        ];

        foreach ($teachers as $teacherData) {
            $teacher = User::updateOrCreate(
                ['email' => $teacherData['email']],
                $teacherData
            );

            // Create teacher profile
            TeacherProfile::updateOrCreate(
                ['user_id' => $teacher->id],
                [
                    'specialization' => $teacher->email === 'teacher@batubata.test' ? 'Web Development' : 'Data Science',
                    'bio' => $teacher->email === 'teacher@batubata.test'
                        ? 'Senior Web Developer dengan pengalaman 10+ tahun. Spesialisasi Laravel, React, dan arsitektur microservices.'
                        : 'Data Scientist dan AI Researcher. Berpengalaman di bidang machine learning dan analisis data.',
                    'qualification' => $teacher->email === 'teacher@batubata.test' ? 'S.Kom Informatika' : 'M.Kom Ilmu Komputer',
                    'institution_name' => $teacher->email === 'teacher@batubata.test' ? 'Universitas Teknologi Indonesia' : 'Institut Teknologi Bandung',
                    'experience_years' => $teacher->email === 'teacher@batubata.test' ? 12 : 8,
                    'expertise_areas' => $teacher->email === 'teacher@batubata.test'
                        ? ['Laravel', 'React', 'Node.js', 'Docker', 'AWS']
                        : ['Python', 'Machine Learning', 'TensorFlow', 'SQL', 'Tableau'],
                    'is_verified' => true,
                ]
            );
        }

        $teacher1 = User::where('email', 'teacher@batubata.test')->first();
        $teacher2 = User::where('email', 'teacher2@batubata.test')->first();

        // Create courses for teacher 1 (Web Dev)
        $courses1 = [
            [
                'title' => 'Full-Stack Web Development dengan Laravel & Vue.js',
                'description' => 'Kursus lengkap membangun aplikasi web modern dari nol menggunakan Laravel 11 sebagai backend dan Vue.js 3 sebagai frontend. Mencakup authentication, REST API, database design, testing, dan deployment ke production.',
                'objectives' => 'Mampu membangun aplikasi web full-stack, memahami arsitektur MVC, menguasai Eloquent ORM, membuat REST API, dan deploy ke server.',
                'category' => 'technical',
                'level' => 'intermediate',
                'duration_hours' => 80,
                'is_free' => true,
                'price' => 0,
                'tags' => ['laravel', 'vue.js', 'fullstack', 'php', 'javascript'],
                'status' => 'published',
                'max_students' => 30,
            ],
            [
                'title' => 'Dasar-Dasar HTML, CSS & JavaScript',
                'description' => 'Kursus pemula untuk mempelajari fondasi web development. Dari HTML semantic, CSS Flexbox & Grid, hingga JavaScript modern (ES6+). Cocok untuk yang baru memulai belajar coding.',
                'objectives' => 'Mampu membuat website responsif, memahami DOM manipulation, dan menggunakan JavaScript ES6+.',
                'category' => 'technical',
                'level' => 'beginner',
                'duration_hours' => 40,
                'is_free' => true,
                'price' => 0,
                'tags' => ['html', 'css', 'javascript', 'pemula'],
                'status' => 'published',
                'max_students' => 50,
            ],
            [
                'title' => 'Docker & Kubernetes untuk Developer',
                'description' => 'Pelajari containerization dan orchestration dari dasar hingga mahir. Bangun CI/CD pipeline, deploy aplikasi ke cluster, dan kelola microservices dengan Kubernetes.',
                'objectives' => 'Menguasai Docker, membuat Dockerfile, mengelola Docker Compose, dan memahami Kubernetes fundamentals.',
                'category' => 'technical',
                'level' => 'advanced',
                'duration_hours' => 35,
                'is_free' => false,
                'price' => 250000,
                'tags' => ['docker', 'kubernetes', 'devops', 'ci/cd'],
                'status' => 'draft',
                'max_students' => 20,
            ],
        ];

        foreach ($courses1 as $courseData) {
            $courseData['teacher_id'] = $teacher1->id;
            $course = TeacherCourse::updateOrCreate(
                ['title' => $courseData['title'], 'teacher_id' => $teacher1->id],
                $courseData
            );

            // Add modules and materials for published courses
            if ($course->status === 'published' && $course->modules()->count() === 0) {
                $this->createModulesAndMaterials($course);
            }
        }

        // Create courses for teacher 2 (Data Science)
        $courses2 = [
            [
                'title' => 'Python untuk Data Science',
                'description' => 'Kursus komprehensif Python untuk analisis data. Pelajari Pandas, NumPy, Matplotlib, dan Seaborn. Bangun project nyata analisis dataset real-world.',
                'objectives' => 'Menguasai Python untuk analisis data, visualisasi data, dan data wrangling.',
                'category' => 'technical',
                'level' => 'beginner',
                'duration_hours' => 50,
                'is_free' => true,
                'price' => 0,
                'tags' => ['python', 'data science', 'pandas', 'analisis data'],
                'status' => 'published',
                'max_students' => 40,
            ],
            [
                'title' => 'Machine Learning dengan Scikit-Learn & TensorFlow',
                'description' => 'Pelajari machine learning dari supervised hingga deep learning. Implementasikan algoritma ML menggunakan Scikit-Learn dan bangun neural network dengan TensorFlow.',
                'objectives' => 'Memahami algoritma ML, mampu membangun model prediksi, dan menguasai TensorFlow dasar.',
                'category' => 'technical',
                'level' => 'advanced',
                'duration_hours' => 60,
                'is_free' => false,
                'price' => 350000,
                'tags' => ['machine learning', 'tensorflow', 'python', 'ai'],
                'status' => 'published',
                'max_students' => 25,
            ],
        ];

        foreach ($courses2 as $courseData) {
            $courseData['teacher_id'] = $teacher2->id;
            $course = TeacherCourse::updateOrCreate(
                ['title' => $courseData['title'], 'teacher_id' => $teacher2->id],
                $courseData
            );

            if ($course->status === 'published' && $course->modules()->count() === 0) {
                $this->createModulesAndMaterials($course);
            }
        }

        // Create classes
        $webDevCourse = TeacherCourse::where('teacher_id', $teacher1->id)->where('title', 'like', '%Full-Stack%')->first();
        $htmlCourse = TeacherCourse::where('teacher_id', $teacher1->id)->where('title', 'like', '%HTML%')->first();
        $pythonCourse = TeacherCourse::where('teacher_id', $teacher2->id)->where('title', 'like', '%Python%')->first();

        if ($webDevCourse) {
            $class = TeacherClass::updateOrCreate(
                ['code' => 'WEBDEV01'],
                [
                    'teacher_id' => $teacher1->id,
                    'course_id' => $webDevCourse->id,
                    'name' => 'Full-Stack Web Batch 1 - 2026',
                    'description' => 'Kelas intensif full-stack web development selama 3 bulan.',
                    'start_date' => '2026-07-01',
                    'end_date' => '2026-09-30',
                    'max_students' => 30,
                    'status' => 'active',
                    'schedule_info' => 'Setiap Selasa & Kamis, 19:00-21:00 WIB',
                ]
            );

            // Enroll some job seekers
            $seekers = User::where('role', 'job_seeker')->take(5)->get();
            foreach ($seekers as $seeker) {
                ClassEnrollment::firstOrCreate(
                    ['class_id' => $class->id, 'user_id' => $seeker->id],
                    ['status' => 'active', 'enrolled_at' => now(), 'progress_percentage' => rand(10, 60)]
                );
            }
        }

        if ($htmlCourse) {
            TeacherClass::updateOrCreate(
                ['code' => 'HTMLCSS01'],
                [
                    'teacher_id' => $teacher1->id,
                    'course_id' => $htmlCourse->id,
                    'name' => 'HTML & CSS untuk Pemula Batch 1',
                    'description' => 'Kelas dasar web development untuk pemula.',
                    'start_date' => '2026-07-15',
                    'end_date' => '2026-08-30',
                    'max_students' => 50,
                    'status' => 'active',
                    'schedule_info' => 'Setiap Senin & Rabu, 16:00-18:00 WIB',
                ]
            );
        }

        if ($pythonCourse) {
            TeacherClass::updateOrCreate(
                ['code' => 'PYTHOND1'],
                [
                    'teacher_id' => $teacher2->id,
                    'course_id' => $pythonCourse->id,
                    'name' => 'Python Data Science Batch 1',
                    'description' => 'Kelas Python untuk data science.',
                    'start_date' => '2026-07-10',
                    'end_date' => '2026-10-10',
                    'max_students' => 40,
                    'status' => 'active',
                    'schedule_info' => 'Setiap Rabu & Jumat, 19:00-21:00 WIB',
                ]
            );
        }
    }

    private function createModulesAndMaterials(TeacherCourse $course): void
    {
        $isWebDev = str_contains($course->title, 'Full-Stack') || str_contains($course->title, 'HTML');

        if ($isWebDev) {
            $modules = [
                ['title' => 'Pengenalan & Setup Environment', 'description' => 'Setup development environment dan pengenalan tools.', 'duration_minutes' => 120],
                ['title' => 'Fundamental Web Development', 'description' => 'HTML, CSS, dan JavaScript dasar.', 'duration_minutes' => 180],
                ['title' => 'Backend Development', 'description' => 'Membangun backend dengan framework.', 'duration_minutes' => 240],
                ['title' => 'Frontend Development', 'description' => 'Membangun frontend modern.', 'duration_minutes' => 200],
                ['title' => 'Deployment & Best Practices', 'description' => 'Deploy ke production dan best practices.', 'duration_minutes' => 150],
            ];
        } else {
            $modules = [
                ['title' => 'Pengenalan Python & Setup', 'description' => 'Install Python dan pengenalan syntax dasar.', 'duration_minutes' => 120],
                ['title' => 'Data Types & Structures', 'description' => 'List, dictionary, tuple, dan set.', 'duration_minutes' => 150],
                ['title' => 'Pandas & Data Manipulation', 'description' => 'Mengolah data dengan Pandas DataFrame.', 'duration_minutes' => 200],
                ['title' => 'Visualisasi Data', 'description' => 'Matplotlib, Seaborn, dan Plotly.', 'duration_minutes' => 180],
                ['title' => 'Project Akhir', 'description' => 'Analisis dataset real-world.', 'duration_minutes' => 240],
            ];
        }

        foreach ($modules as $index => $moduleData) {
            $module = CourseModule::create([
                'course_id' => $course->id,
                'title' => $moduleData['title'],
                'description' => $moduleData['description'],
                'order_number' => $index + 1,
                'duration_minutes' => $moduleData['duration_minutes'],
            ]);

            // Add materials for each module
            $materials = [
                ['title' => 'Slide Presentasi - ' . $module->title, 'type' => 'document', 'content' => 'Slide materi pembelajaran untuk modul ' . $module->title],
                ['title' => 'Video Tutorial - ' . $module->title, 'type' => 'video', 'external_url' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'],
                ['title' => 'Tugas Praktik - ' . $module->title, 'type' => 'assignment', 'content' => 'Kerjakan tugas praktik berikut untuk memperdalam pemahaman materi ' . $module->title],
            ];

            foreach ($materials as $matIndex => $matData) {
                CourseMaterial::create([
                    'module_id' => $module->id,
                    'title' => $matData['title'],
                    'type' => $matData['type'],
                    'content' => $matData['content'] ?? null,
                    'external_url' => $matData['external_url'] ?? null,
                    'order_number' => $matIndex + 1,
                    'is_downloadable' => true,
                ]);
            }
        }
    }
}
