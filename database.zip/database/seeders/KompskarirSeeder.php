<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Position;
use App\Models\Competency;
use App\Models\Course;
use App\Models\JobListing;
use App\Models\UserAssessment;
use App\Models\UserCompetencyScore;
use App\Models\CareerRoadmap;
use App\Models\UserCourseProgress;
use App\Models\UserJobApplication;
use App\Models\Institution;
use App\Models\Company;
use App\Models\Category;
use App\Models\Program;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class KompskarirSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0');
        DB::table('user_job_applications')->truncate();
        DB::table('career_roadmaps')->truncate();
        DB::table('user_course_progress')->truncate();
        DB::table('user_competency_scores')->truncate();
        DB::table('user_assessments')->truncate();
        DB::table('courses')->truncate();
        DB::table('competencies')->truncate();
        DB::table('positions')->truncate();
        DB::table('job_listings')->truncate();
        DB::table('programs')->truncate();
        DB::table('companies')->truncate();
        DB::table('institutions')->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1');

        // ============================================================
        // 1. USERS (20 users)
        // ============================================================
        
        // Admin
        User::create(['name' => 'Admin KompasKarir', 'email' => 'admin@kompaskarir.id', 'password' => Hash::make('password'), 'role' => 'admin', 'email_verified_at' => now()]);

        // Job Seekers (10 users)
        $seekers = [];
        $seekerData = [
            ['name' => 'Budi Santoso', 'email' => 'budi@seeker.com', 'phone' => '08123456789', 'education_level' => 'S1', 'major' => 'Teknik Informatika', 'experience_years' => 1, 'gender' => 'male', 'address' => 'Jakarta Selatan'],
            ['name' => 'Andi Prasetyo', 'email' => 'andi@seeker.com', 'phone' => '08123456790', 'education_level' => 'S1', 'major' => 'Sistem Informasi', 'experience_years' => 2, 'gender' => 'male', 'address' => 'Jakarta Barat'],
            ['name' => 'Dewi Lestari', 'email' => 'dewi@seeker.com', 'phone' => '08123456791', 'education_level' => 'S1', 'major' => 'Manajemen', 'experience_years' => 0, 'gender' => 'female', 'address' => 'Bandung'],
            ['name' => 'Rina Wati', 'email' => 'rina@seeker.com', 'phone' => '08123456792', 'education_level' => 'D3', 'major' => 'Manajemen Informatika', 'experience_years' => 1, 'gender' => 'female', 'address' => 'Surabaya'],
            ['name' => 'Farhan Maulana', 'email' => 'farhan@seeker.com', 'phone' => '08123456793', 'education_level' => 'S1', 'major' => 'Teknik Komputer', 'experience_years' => 3, 'gender' => 'male', 'address' => 'Yogyakarta'],
            ['name' => 'Siti Nurhaliza', 'email' => 'siti@seeker.com', 'phone' => '08123456794', 'education_level' => 'S1', 'major' => 'Komunikasi', 'experience_years' => 1, 'gender' => 'female', 'address' => 'Jakarta Pusat'],
            ['name' => 'Dimas Prayoga', 'email' => 'dimas@seeker.com', 'phone' => '08123456795', 'education_level' => 'S2', 'major' => 'Data Science', 'experience_years' => 4, 'gender' => 'male', 'address' => 'Tangerang'],
            ['name' => 'Putri Amelia', 'email' => 'putri@seeker.com', 'phone' => '08123456796', 'education_level' => 'S1', 'major' => 'Desain Komunikasi Visual', 'experience_years' => 2, 'gender' => 'female', 'address' => 'Bandung'],
            ['name' => 'Rizky Aditya', 'email' => 'rizky@seeker.com', 'phone' => '08123456797', 'education_level' => 'S1', 'major' => 'Teknik Informatika', 'experience_years' => 0, 'gender' => 'male', 'address' => 'Semarang'],
            ['name' => 'Maya Putri', 'email' => 'maya@seeker.com', 'phone' => '08123456798', 'education_level' => 'D3', 'major' => 'Akuntansi', 'experience_years' => 1, 'gender' => 'female', 'address' => 'Medan'],
        ];

        foreach ($seekerData as $sd) {
            $seekers[] = User::create(array_merge($sd, [
                'password' => Hash::make('password'),
                'role' => 'job_seeker',
                'email_verified_at' => now(),
            ]));
        }

        // Industry/HRD (5 users + companies)
        $industries = [];
        $industryData = [
            ['name' => 'Siti HRD Manager', 'email' => 'hrd@techcorp.com', 'company' => ['name' => 'Tech Corp Indonesia', 'industry' => 'Software House', 'size' => '50-200']],
            ['name' => 'Ahmad HRD BUMN', 'email' => 'hrd@bumn.id', 'company' => ['name' => 'Bank BUMN Nusantara', 'industry' => 'Keuangan', 'size' => '1000+']],
            ['name' => 'Budi HR Startup', 'email' => 'hrd@startup.com', 'company' => ['name' => 'Startup Unicorn ID', 'industry' => 'E-Commerce', 'size' => '200-500']],
            ['name' => 'Rina HR Agency', 'email' => 'hrd@agency.com', 'company' => ['name' => 'Creative Agency Jakarta', 'industry' => 'Digital Marketing', 'size' => '20-50']],
            ['name' => 'Dian HR FinTech', 'email' => 'hrd@fintech.com', 'company' => ['name' => 'FinTech Nusantara', 'industry' => 'Financial Technology', 'size' => '100-200']],
        ];

        foreach ($industryData as $id) {
            $user = User::create([
                'name' => $id['name'], 'email' => $id['email'], 'password' => Hash::make('password'),
                'role' => 'industry', 'email_verified_at' => now(),
            ]);
            $company = Company::create([
                'user_id' => $user->id, 'name' => $id['company']['name'],
                'industry' => $id['company']['industry'], 'size' => $id['company']['size'],
                'website' => 'https://' . str_replace(' ', '', strtolower($id['company']['name'])) . '.id',
            ]);
            $user->update(['company_id' => $company->id]);
            $industries[] = $user;
        }

        // Education (3 users + institutions)
        $educations = [];
        $eduData = [
            ['name' => 'Dr. Universitas Digital', 'email' => 'info@univdigital.ac.id', 'inst' => ['name' => 'Universitas Digital Nusantara', 'type' => 'university']],
            ['name' => 'Prof. Institut Teknologi', 'email' => 'info@itk.ac.id', 'inst' => ['name' => 'Institut Teknologi Kompas', 'type' => 'university']],
            ['name' => 'Dr. Politeknik Bisnis', 'email' => 'info@polbis.ac.id', 'inst' => ['name' => 'Politeknik Bisnis Digital', 'type' => 'polytechnic']],
        ];

        foreach ($eduData as $ed) {
            $user = User::create([
                'name' => $ed['name'], 'email' => $ed['email'], 'password' => Hash::make('password'),
                'role' => 'education', 'email_verified_at' => now(),
            ]);
            $inst = Institution::create([
                'user_id' => $user->id, 'name' => $ed['inst']['name'],
                'type' => $ed['inst']['type'], 'address' => 'Jakarta', 'accreditation' => 'A',
            ]);
            $user->update(['institution_id' => $inst->id]);
            $educations[] = $user;
        }

        // ============================================================
        // 2. CATEGORIES (dari posisi yang akan di-seed)
        // ============================================================
        $categoriesData = [
            ['name' => 'Marketing', 'type' => 'position', 'description' => 'Posisi terkait pemasaran digital dan tradisional.'],
            ['name' => 'Data & Analytics', 'type' => 'position', 'description' => 'Posisi terkait analisis data, data science, dan business intelligence.'],
            ['name' => 'Engineering', 'type' => 'position', 'description' => 'Posisi terkait pengembangan software dan teknik.'],
            ['name' => 'Design', 'type' => 'position', 'description' => 'Posisi terkait desain UI/UX dan visual.'],
            ['name' => 'Management', 'type' => 'position', 'description' => 'Posisi terkait manajemen proyek dan tim.'],
            ['name' => 'Human Resources', 'type' => 'position', 'description' => 'Posisi terkait pengelolaan sumber daya manusia.'],
            ['name' => 'Product', 'type' => 'position', 'description' => 'Posisi terkait manajemen produk.'],
            ['name' => 'Technical', 'type' => 'competency', 'description' => 'Kompetensi teknis/hard skill.'],
            ['name' => 'Soft Skill', 'type' => 'competency', 'description' => 'Kompetensi non-teknis/soft skill.'],
        ];

        foreach ($categoriesData as $cat) {
            Category::create($cat);
        }

        // ============================================================
        // 3. POSITIONS & COMPETENCIES (8 posisi, 55 kompetensi)
        // ============================================================
        $positionsData = [
            ['name' => 'Digital Marketing Specialist', 'description' => 'Ahli strategi pemasaran digital, SEO/SEM, analytics, dan content marketing.', 'category' => 'Marketing'],
            ['name' => 'Data Analyst', 'description' => 'Menganalisis data untuk insight bisnis menggunakan SQL, Python, dan tools visualisasi.', 'category' => 'Data & Analytics'],
            ['name' => 'Frontend Developer', 'description' => 'Membangun antarmuka web responsif menggunakan framework modern JavaScript.', 'category' => 'Engineering'],
            ['name' => 'Backend Developer', 'description' => 'Membangun server-side logic, API, dan integrasi database untuk aplikasi web.', 'category' => 'Engineering'],
            ['name' => 'UI/UX Designer', 'description' => 'Merancang pengalaman pengguna yang intuitif dan antarmuka yang menarik.', 'category' => 'Design'],
            ['name' => 'Project Manager', 'description' => 'Mengelola proyek teknologi dari perencanaan hingga delivery dengan metodologi Agile.', 'category' => 'Management'],
            ['name' => 'HR Specialist', 'description' => 'Mengelola rekrutmen, pengembangan karyawan, dan kebijakan SDM perusahaan.', 'category' => 'Human Resources'],
            ['name' => 'Product Manager', 'description' => 'Mendefinisikan visi produk, roadmap, dan strategi berdasarkan kebutuhan pasar.', 'category' => 'Product'],
        ];

        $positions = [];
        foreach ($positionsData as $pd) {
            $positions[] = Position::create($pd);
        }

        $competenciesData = [
            [['DM-T01','Google Analytics & Tag Manager','technical',4],['DM-T02','SEO & SEM (Google Ads)','technical',4],['DM-T03','Social Media Marketing & Ads','technical',3],['DM-T04','Content Strategy & Copywriting','technical',3],['DM-T05','Email Marketing & Automation','technical',3],['DM-S01','Komunikasi Efektif','soft_skill',4],['DM-S02','Kreativitas & Problem Solving','soft_skill',3]],
            [['DA-T01','SQL & Database Query','technical',5],['DA-T02','Python untuk Analisis Data','technical',4],['DA-T03','Data Visualization (Tableau/PowerBI)','technical',4],['DA-T04','Statistika & Probability','technical',3],['DA-T05','Excel Advanced & Google Sheets','technical',3],['DA-S01','Critical Thinking','soft_skill',5],['DA-S02','Storytelling dengan Data','soft_skill',4]],
            [['FE-T01','HTML, CSS & JavaScript ES6+','technical',5],['FE-T02','React.js / Vue.js / Angular','technical',4],['FE-T03','Responsive Design & Tailwind CSS','technical',4],['FE-T04','REST API Integration','technical',3],['FE-T05','Version Control (Git)','technical',3],['FE-S01','Collaboration & Teamwork','soft_skill',4],['FE-S02','Attention to Detail','soft_skill',4]],
            [['BE-T01','PHP / Node.js / Python','technical',5],['BE-T02','Framework (Laravel/Express/Django)','technical',4],['BE-T03','Database Design (MySQL/PostgreSQL)','technical',4],['BE-T04','RESTful API & Authentication','technical',4],['BE-T05','Docker & CI/CD','technical',3],['BE-S01','Problem Solving & Debugging','soft_skill',4],['BE-S02','Time Management','soft_skill',3]],
            [['UX-T01','Figma / Adobe XD / Sketch','technical',5],['UX-T02','User Research & Usability Testing','technical',4],['UX-T03','Wireframing & Prototyping','technical',4],['UX-T04','Design System & Components','technical',3],['UX-T05','HTML/CSS Dasar','technical',2],['UX-S01','Empathy & User-Centered Thinking','soft_skill',5],['UX-S02','Komunikasi Visual','soft_skill',4]],
            [['PM-T01','Agile & Scrum Methodology','technical',4],['PM-T02','Project Management Tools (Jira/Trello)','technical',4],['PM-T03','Risk Management & Budgeting','technical',3],['PM-T04','Stakeholder Management','technical',3],['PM-S01','Leadership & Decision Making','soft_skill',5],['PM-S02','Negosiasi & Conflict Resolution','soft_skill',4],['PM-S03','Komunikasi & Presentasi','soft_skill',4]],
            [['HR-T01','Rekrutmen & Talent Acquisition','technical',4],['HR-T02','HRIS & Payroll System','technical',3],['HR-T03','Employment Law & Compliance','technical',3],['HR-T04','Training & Development','technical',3],['HR-S01','Interpersonal & Empathy','soft_skill',5],['HR-S02','Discretion & Confidentiality','soft_skill',4]],
            [['PRD-T01','Product Strategy & Roadmapping','technical',5],['PRD-T02','Market Research & Competitive Analysis','technical',4],['PRD-T03','Data Analytics & Metrics','technical',3],['PRD-T04','Agile/Scrum untuk Product','technical',4],['PRD-S01','Strategic Thinking','soft_skill',5],['PRD-S02','Cross-functional Collaboration','soft_skill',4],['PRD-S03','Presentation & Storytelling','soft_skill',4]],
        ];

        $platforms = ['Coursera', 'Dicoding', 'Udemy', 'Skill Academy', 'MySkill', 'Hariseni'];
        $allCompetencies = [];

        foreach ($positions as $idx => $position) {
            foreach ($competenciesData[$idx] as $skill) {
                $comp = Competency::create([
                    'code' => $skill[0], 'name' => $skill[1], 'category' => $skill[2],
                    'position_id' => $position->id, 'min_level_required' => $skill[3],
                    'source_reference' => 'BNSP & LinkedIn Jobs'
                ]);
                $allCompetencies[] = $comp;

                Course::create([
                    'title' => 'Mastering ' . $skill[1],
                    'description' => 'Kursus lengkap untuk menguasai ' . $skill[1] . ' dari dasar hingga mahir.',
                    'platform' => $platforms[array_rand($platforms)],
                    'category' => $skill[2],
                    'competency_id' => $comp->id,
                    'duration_hours' => rand(10, 40),
                    'level' => ['beginner', 'intermediate', 'advanced'][rand(0, 2)],
                    'url' => 'https://example.com/course/' . $skill[0],
                    'price' => rand(0, 500000),
                    'is_free' => rand(0, 1) == 1,
                ]);
            }
        }

        // ============================================================
        // 3. JOB LISTINGS (20 lowongan)
        // ============================================================
        $jobListings = [
            ['pos' => 0, 'title' => 'Junior Digital Marketing Staff', 'company' => 'Tech Corp Indonesia', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 6000000, 'max' => 9000000, 'exp' => '1-2 Tahun', 'skills' => ['Google Analytics','SEO','Social Media']],
            ['pos' => 0, 'title' => 'Digital Marketing Specialist', 'company' => 'Creative Agency Jakarta', 'loc' => 'Jakarta Barat', 'work' => 'onsite', 'min' => 8000000, 'max' => 12000000, 'exp' => '2-3 Tahun', 'skills' => ['Google Ads','Content Strategy','Email Marketing']],
            ['pos' => 1, 'title' => 'Data Analyst - Business Intelligence', 'company' => 'Bank BUMN Nusantara', 'loc' => 'Jakarta Pusat', 'work' => 'onsite', 'min' => 8000000, 'max' => 12000000, 'exp' => '1-3 Tahun', 'skills' => ['SQL','Python','Tableau']],
            ['pos' => 1, 'title' => 'Senior Data Analyst', 'company' => 'FinTech Nusantara', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 12000000, 'max' => 18000000, 'exp' => '3-5 Tahun', 'skills' => ['Python','Machine Learning','BigQuery']],
            ['pos' => 2, 'title' => 'Frontend Developer - React.js', 'company' => 'Tech Corp Indonesia', 'loc' => 'Remote', 'work' => 'remote', 'min' => 7000000, 'max' => 14000000, 'exp' => '1-2 Tahun', 'skills' => ['React.js','JavaScript','Tailwind CSS']],
            ['pos' => 2, 'title' => 'Vue.js Developer', 'company' => 'Startup Unicorn ID', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 9000000, 'max' => 15000000, 'exp' => '2-3 Tahun', 'skills' => ['Vue.js','TypeScript','Nuxt']],
            ['pos' => 3, 'title' => 'Backend Developer - Laravel', 'company' => 'Tech Corp Indonesia', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 8000000, 'max' => 15000000, 'exp' => '2-4 Tahun', 'skills' => ['PHP','Laravel','MySQL']],
            ['pos' => 3, 'title' => 'Node.js Backend Engineer', 'company' => 'Startup Unicorn ID', 'loc' => 'Remote', 'work' => 'remote', 'min' => 10000000, 'max' => 18000000, 'exp' => '2-4 Tahun', 'skills' => ['Node.js','Express','MongoDB']],
            ['pos' => 4, 'title' => 'UI/UX Designer - Product Design', 'company' => 'Startup Unicorn ID', 'loc' => 'Bandung', 'work' => 'hybrid', 'min' => 6000000, 'max' => 11000000, 'exp' => '1-3 Tahun', 'skills' => ['Figma','User Research','Prototyping']],
            ['pos' => 4, 'title' => 'Senior UI/UX Designer', 'company' => 'FinTech Nusantara', 'loc' => 'Jakarta Pusat', 'work' => 'onsite', 'min' => 12000000, 'max' => 20000000, 'exp' => '3-5 Tahun', 'skills' => ['Figma','Design System','Usability Testing']],
            ['pos' => 5, 'title' => 'IT Project Manager', 'company' => 'Bank BUMN Nusantara', 'loc' => 'Jakarta Pusat', 'work' => 'onsite', 'min' => 12000000, 'max' => 20000000, 'exp' => '3-5 Tahun', 'skills' => ['Agile','Scrum','Jira']],
            ['pos' => 5, 'title' => 'Scrum Master', 'company' => 'Tech Corp Indonesia', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 10000000, 'max' => 16000000, 'exp' => '2-4 Tahun', 'skills' => ['Scrum','Agile','Facilitation']],
            ['pos' => 6, 'title' => 'HR Generalist', 'company' => 'Creative Agency Jakarta', 'loc' => 'Jakarta Barat', 'work' => 'onsite', 'min' => 6000000, 'max' => 9000000, 'exp' => '1-2 Tahun', 'skills' => ['Rekrutmen','HRIS','Training']],
            ['pos' => 6, 'title' => 'Talent Acquisition Specialist', 'company' => 'Startup Unicorn ID', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 8000000, 'max' => 13000000, 'exp' => '2-3 Tahun', 'skills' => ['Sourcing','Interviewing','Employer Branding']],
            ['pos' => 7, 'title' => 'Associate Product Manager', 'company' => 'FinTech Nusantara', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 10000000, 'max' => 16000000, 'exp' => '1-3 Tahun', 'skills' => ['Product Strategy','Agile','Data Analytics']],
            ['pos' => 7, 'title' => 'Senior Product Manager', 'company' => 'Bank BUMN Nusantara', 'loc' => 'Jakarta Pusat', 'work' => 'onsite', 'min' => 18000000, 'max' => 30000000, 'exp' => '5+ Tahun', 'skills' => ['Roadmapping','OKR','Stakeholder Management']],
            ['pos' => 0, 'title' => 'Content Marketing Specialist', 'company' => 'FinTech Nusantara', 'loc' => 'Remote', 'work' => 'remote', 'min' => 7000000, 'max' => 11000000, 'exp' => '1-2 Tahun', 'skills' => ['Content Strategy','SEO','Social Media']],
            ['pos' => 1, 'title' => 'Junior Data Analyst', 'company' => 'Creative Agency Jakarta', 'loc' => 'Jakarta Barat', 'work' => 'onsite', 'min' => 5000000, 'max' => 8000000, 'exp' => 'Fresh Graduate', 'skills' => ['Excel','SQL','Google Sheets']],
            ['pos' => 2, 'title' => 'Fullstack Developer', 'company' => 'Bank BUMN Nusantara', 'loc' => 'Jakarta Pusat', 'work' => 'onsite', 'min' => 10000000, 'max' => 18000000, 'exp' => '2-4 Tahun', 'skills' => ['React','Node.js','PostgreSQL']],
            ['pos' => 4, 'title' => 'Junior UI Designer', 'company' => 'Tech Corp Indonesia', 'loc' => 'Jakarta Selatan', 'work' => 'hybrid', 'min' => 5000000, 'max' => 8000000, 'exp' => 'Fresh Graduate', 'skills' => ['Figma','Photoshop','Illustrator']],
        ];

        $createdJobs = [];
        foreach ($jobListings as $jl) {
            $hrdUser = $industries[array_rand($industries)];
            $createdJobs[] = JobListing::create([
                'user_id' => $hrdUser->id,
                'position_id' => $positions[$jl['pos']]->id,
                'external_id' => 'JOB-' . str_pad(count($createdJobs) + 1, 3, '0', STR_PAD_LEFT),
                'source_platform' => 'Internal',
                'title' => $jl['title'],
                'company_name' => $jl['company'],
                'location' => $jl['loc'],
                'work_type' => $jl['work'],
                'salary_min' => $jl['min'],
                'salary_max' => $jl['max'],
                'experience_required' => $jl['exp'],
                'description' => 'Lowongan kerja untuk posisi ' . $jl['title'] . ' di perusahaan ' . $jl['company'] . '.',
                'required_skills' => $jl['skills'],
                'application_url' => 'https://karir.example.com/apply/JOB-' . str_pad(count($createdJobs), 3, '0', STR_PAD_LEFT),
                'posted_date' => now()->subDays(rand(1, 30)),
                'expires_date' => now()->addDays(rand(15, 60)),
                'is_active' => true,
            ]);
        }

        // ============================================================
        // 4. PROGRAMS (15 program)
        // ============================================================
        $programData = [
            ['name' => 'Digital Marketing Bootcamp', 'type' => 'Bootcamp', 'duration' => '3 Bulan', 'status' => 'active'],
            ['name' => 'Data Analytics Certification', 'type' => 'Sertifikasi', 'duration' => '6 Bulan', 'status' => 'active'],
            ['name' => 'AI & Machine Learning Workshop', 'type' => 'Workshop', 'duration' => '2 Hari', 'status' => 'active'],
            ['name' => 'Fullstack Web Development', 'type' => 'Bootcamp', 'duration' => '6 Bulan', 'status' => 'active'],
            ['name' => 'UI/UX Design Fundamentals', 'type' => 'Workshop', 'duration' => '3 Hari', 'status' => 'active'],
            ['name' => 'Project Management Professional', 'type' => 'Sertifikasi', 'duration' => '3 Bulan', 'status' => 'active'],
            ['name' => 'Cloud Computing AWS', 'type' => 'Sertifikasi', 'duration' => '4 Bulan', 'status' => 'upcoming'],
            ['name' => 'Cybersecurity Essentials', 'type' => 'Workshop', 'duration' => '2 Hari', 'status' => 'upcoming'],
            ['name' => 'Python for Data Science', 'type' => 'Bootcamp', 'duration' => '2 Bulan', 'status' => 'active'],
            ['name' => 'Agile & Scrum Masterclass', 'type' => 'Workshop', 'duration' => '1 Hari', 'status' => 'active'],
            ['name' => 'Mobile App Development Flutter', 'type' => 'Bootcamp', 'duration' => '4 Bulan', 'status' => 'upcoming'],
            ['name' => 'Business Intelligence with PowerBI', 'type' => 'Sertifikasi', 'duration' => '3 Bulan', 'status' => 'active'],
            ['name' => 'DevOps & CI/CD Pipeline', 'type' => 'Workshop', 'duration' => '3 Hari', 'status' => 'active'],
            ['name' => 'Digital Content Creation', 'type' => 'Bootcamp', 'duration' => '2 Bulan', 'status' => 'active'],
            ['name' => 'HR Analytics & People Management', 'type' => 'Sertifikasi', 'duration' => '3 Bulan', 'status' => 'upcoming'],
        ];

        foreach ($programData as $pd) {
            $eduUser = $educations[array_rand($educations)];
            Program::create([
                'name' => $pd['name'],
                'type' => $pd['type'],
                'description' => 'Program ' . $pd['type'] . ' untuk ' . $pd['name'] . '. Dirancang bersama industri untuk memastikan relevansi kurikulum.',
                'duration' => $pd['duration'],
                'max_students' => rand(20, 50),
                'status' => $pd['status'],
                'start_date' => $pd['status'] === 'active' ? now()->subDays(rand(10, 60)) : now()->addDays(rand(10, 60)),
                'end_date' => $pd['status'] === 'active' ? now()->addDays(rand(30, 180)) : now()->addDays(rand(90, 240)),
                'institution_id' => $eduUser->institution_id,
                'industry_partners' => [$industries[array_rand($industries)]->name],
            ]);
        }

        // ============================================================
        // 5. ASSESSMENTS & SCORES (15 assessment)
        // ============================================================
        $assessmentConfigs = [
            ['seeker' => 0, 'pos' => 0, 'scores' => ['DM-T01'=>2,'DM-T02'=>3,'DM-T03'=>4,'DM-T04'=>2,'DM-T05'=>1,'DM-S01'=>4,'DM-S02'=>3]],
            ['seeker' => 1, 'pos' => 2, 'scores' => ['FE-T01'=>4,'FE-T02'=>3,'FE-T03'=>3,'FE-T04'=>2,'FE-T05'=>4,'FE-S01'=>3,'FE-S02'=>4]],
            ['seeker' => 2, 'pos' => 1, 'scores' => ['DA-T01'=>2,'DA-T02'=>1,'DA-T03'=>2,'DA-T04'=>3,'DA-T05'=>4,'DA-S01'=>3,'DA-S02'=>2]],
            ['seeker' => 3, 'pos' => 4, 'scores' => ['UX-T01'=>3,'UX-T02'=>2,'UX-T03'=>3,'UX-T04'=>1,'UX-T05'=>2,'UX-S01'=>4,'UX-S02'=>3]],
            ['seeker' => 4, 'pos' => 3, 'scores' => ['BE-T01'=>4,'BE-T02'=>4,'BE-T03'=>3,'BE-T04'=>3,'BE-T05'=>2,'BE-S01'=>4,'BE-S02'=>3]],
            ['seeker' => 5, 'pos' => 0, 'scores' => ['DM-T01'=>3,'DM-T02'=>2,'DM-T03'=>3,'DM-T04'=>4,'DM-T05'=>2,'DM-S01'=>5,'DM-S02'=>4]],
            ['seeker' => 6, 'pos' => 1, 'scores' => ['DA-T01'=>5,'DA-T02'=>4,'DA-T03'=>4,'DA-T04'=>4,'DA-T05'=>3,'DA-S01'=>4,'DA-S02'=>4]],
            ['seeker' => 7, 'pos' => 4, 'scores' => ['UX-T01'=>5,'UX-T02'=>4,'UX-T03'=>4,'UX-T04'=>3,'UX-T05'=>3,'UX-S01'=>5,'UX-S02'=>4]],
            ['seeker' => 8, 'pos' => 2, 'scores' => ['FE-T01'=>2,'FE-T02'=>1,'FE-T03'=>2,'FE-T04'=>1,'FE-T05'=>2,'FE-S01'=>3,'FE-S02'=>3]],
            ['seeker' => 9, 'pos' => 5, 'scores' => ['PM-T01'=>3,'PM-T02'=>3,'PM-T03'=>2,'PM-T04'=>2,'PM-S01'=>4,'PM-S02'=>3,'PM-S03'=>3]],
            ['seeker' => 0, 'pos' => 1, 'scores' => ['DA-T01'=>1,'DA-T02'=>2,'DA-T03'=>1,'DA-T04'=>2,'DA-T05'=>3,'DA-S01'=>3,'DA-S02'=>2]],
            ['seeker' => 1, 'pos' => 5, 'scores' => ['PM-T01'=>2,'PM-T02'=>2,'PM-T03'=>1,'PM-T04'=>2,'PM-S01'=>3,'PM-S02'=>3,'PM-S03'=>3]],
            ['seeker' => 3, 'pos' => 0, 'scores' => ['DM-T01'=>2,'DM-T02'=>1,'DM-T03'=>3,'DM-T04'=>2,'DM-T05'=>1,'DM-S01'=>3,'DM-S02'=>2]],
            ['seeker' => 4, 'pos' => 7, 'scores' => ['PRD-T01'=>3,'PRD-T02'=>2,'PRD-T03'=>2,'PRD-T04'=>3,'PRD-S01'=>4,'PRD-S02'=>3,'PRD-S03'=>3]],
            ['seeker' => 6, 'pos' => 5, 'scores' => ['PM-T01'=>4,'PM-T02'=>4,'PM-T03'=>3,'PM-T04'=>3,'PM-S01'=>5,'PM-S02'=>4,'PM-S03'=>4]],
        ];

        $createdAssessments = [];
        foreach ($assessmentConfigs as $ac) {
            $position = $positions[$ac['pos']];
            $assessment = UserAssessment::create([
                'user_id' => $seekers[$ac['seeker']]->id,
                'position_id' => $position->id,
                'assessment_date' => now()->subDays(rand(1, 60)),
                'total_gap_percentage' => 0,
                'status' => 'completed',
            ]);

            $totalGap = 0;
            $countSkills = 0;
            foreach ($position->competencies as $comp) {
                $selfLevel = $ac['scores'][$comp->code] ?? 3;
                $gap = $comp->min_level_required > 0 ? max(0, (($comp->min_level_required - $selfLevel) / $comp->min_level_required) * 100) : 0;
                $totalGap += $gap;
                $countSkills++;
                UserCompetencyScore::create([
                    'assessment_id' => $assessment->id,
                    'competency_id' => $comp->id,
                    'self_assessed_level' => $selfLevel,
                    'ai_analyzed_level' => $selfLevel,
                    'gap_percentage' => $gap,
                    'priority' => $gap > 50 ? 'high' : ($gap > 20 ? 'medium' : 'low'),
                ]);
            }
            $assessment->update(['total_gap_percentage' => round($countSkills > 0 ? $totalGap / $countSkills : 0, 2)]);
            $createdAssessments[] = $assessment;
        }

        // ============================================================
        // 6. JOB APPLICATIONS (20 aplikasi)
        // ============================================================
        $applicationData = [
            ['seeker' => 0, 'job' => 0, 'status' => 'applied', 'match' => 72],
            ['seeker' => 0, 'job' => 1, 'status' => 'reviewed', 'match' => 68],
            ['seeker' => 1, 'job' => 4, 'status' => 'interviewed', 'match' => 81],
            ['seeker' => 1, 'job' => 5, 'status' => 'applied', 'match' => 75],
            ['seeker' => 2, 'job' => 2, 'status' => 'applied', 'match' => 55],
            ['seeker' => 2, 'job' => 17, 'status' => 'offered', 'match' => 78],
            ['seeker' => 3, 'job' => 8, 'status' => 'applied', 'match' => 65],
            ['seeker' => 3, 'job' => 19, 'status' => 'reviewed', 'match' => 70],
            ['seeker' => 4, 'job' => 6, 'status' => 'interviewed', 'match' => 85],
            ['seeker' => 4, 'job' => 7, 'status' => 'offered', 'match' => 82],
            ['seeker' => 5, 'job' => 0, 'status' => 'applied', 'match' => 76],
            ['seeker' => 5, 'job' => 16, 'status' => 'reviewed', 'match' => 71],
            ['seeker' => 6, 'job' => 3, 'status' => 'offered', 'match' => 92],
            ['seeker' => 6, 'job' => 2, 'status' => 'interviewed', 'match' => 88],
            ['seeker' => 7, 'job' => 8, 'status' => 'offered', 'match' => 90],
            ['seeker' => 7, 'job' => 9, 'status' => 'applied', 'match' => 85],
            ['seeker' => 8, 'job' => 4, 'status' => 'applied', 'match' => 45],
            ['seeker' => 8, 'job' => 18, 'status' => 'rejected', 'match' => 42],
            ['seeker' => 9, 'job' => 12, 'status' => 'applied', 'match' => 60],
            ['seeker' => 9, 'job' => 13, 'status' => 'reviewed', 'match' => 58],
        ];

        foreach ($applicationData as $ad) {
            UserJobApplication::create([
                'user_id' => $seekers[$ad['seeker']]->id,
                'job_listing_id' => $createdJobs[$ad['job']]->id,
                'matching_percentage' => $ad['match'],
                'applied_at' => now()->subDays(rand(1, 30)),
                'status' => $ad['status'],
                'notes' => $ad['status'] === 'offered' ? 'Kandidat diterima!' : null,
            ]);
        }

        // ============================================================
        // 7. COURSE PROGRESS (15 progress)
        // ============================================================
        $courses = Course::all();
        $progressData = [
            ['seeker' => 0, 'course' => 0, 'status' => 'in_progress', 'pct' => 45],
            ['seeker' => 0, 'course' => 1, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 1, 'course' => 15, 'status' => 'in_progress', 'pct' => 30],
            ['seeker' => 1, 'course' => 16, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 2, 'course' => 7, 'status' => 'in_progress', 'pct' => 20],
            ['seeker' => 3, 'course' => 28, 'status' => 'in_progress', 'pct' => 55],
            ['seeker' => 4, 'course' => 22, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 4, 'course' => 23, 'status' => 'in_progress', 'pct' => 70],
            ['seeker' => 5, 'course' => 2, 'status' => 'in_progress', 'pct' => 15],
            ['seeker' => 6, 'course' => 8, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 6, 'course' => 9, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 7, 'course' => 29, 'status' => 'completed', 'pct' => 100],
            ['seeker' => 7, 'course' => 30, 'status' => 'in_progress', 'pct' => 60],
            ['seeker' => 8, 'course' => 15, 'status' => 'in_progress', 'pct' => 10],
            ['seeker' => 9, 'course' => 36, 'status' => 'in_progress', 'pct' => 25],
        ];

        foreach ($progressData as $pd) {
            if (isset($courses[$pd['course']])) {
                UserCourseProgress::create([
                    'user_id' => $seekers[$pd['seeker']]->id,
                    'course_id' => $courses[$pd['course']]->id,
                    'status' => $pd['status'],
                    'started_at' => now()->subDays(rand(5, 60)),
                    'completed_at' => $pd['status'] === 'completed' ? now()->subDays(rand(1, 5)) : null,
                    'progress_percentage' => $pd['pct'],
                ]);
            }
        }

        // ============================================================
        // 8. CAREER ROADMAPS (untuk 5 seeker)
        // ============================================================
        $milestones = [
            ['Fundamentals & Basics', 'Pelajari dasar-dasar dan konsep fundamental.'],
            ['Tools & Platforms', 'Kuasai tools dan platform yang dibutuhkan industri.'],
            ['Strategy & Planning', 'Pelajari strategi dan perencanaan yang efektif.'],
            ['Execution & Practice', 'Praktikkan skill dalam proyek nyata.'],
            ['Analytics & Optimization', 'Analisis hasil dan optimasi performa.'],
            ['Portfolio & Certification', 'Bangun portofolio dan ambil sertifikasi.'],
        ];

        foreach ([0, 1, 4, 6, 7] as $seekerIdx) {
            $posIdx = $assessmentConfigs[$seekerIdx]['pos'];
            for ($i = 0; $i < 6; $i++) {
                CareerRoadmap::create([
                    'user_id' => $seekers[$seekerIdx]->id,
                    'position_id' => $positions[$posIdx]->id,
                    'month_number' => $i + 1,
                    'milestone_title' => 'Bulan ' . ($i + 1) . ': ' . $milestones[$i][0],
                    'milestone_description' => $milestones[$i][1],
                    'is_completed' => $i < 2,
                    'completed_at' => $i < 2 ? now()->subMonths(6 - $i) : null,
                ]);
            }
        }

        $this->command->info('=== Seeder KOMPASKARIR berhasil! ===');
        $this->command->info('Users: ' . User::count());
        $this->command->info('Companies: ' . Company::count());
        $this->command->info('Institutions: ' . Institution::count());
        $this->command->info('Positions: ' . Position::count());
        $this->command->info('Competencies: ' . Competency::count());
        $this->command->info('Courses: ' . Course::count());
        $this->command->info('Job Listings: ' . JobListing::count());
        $this->command->info('Programs: ' . Program::count());
        $this->command->info('Assessments: ' . UserAssessment::count());
        $this->command->info('Applications: ' . UserJobApplication::count());
        $this->command->info('Course Progress: ' . UserCourseProgress::count());
        $this->command->info('Career Roadmaps: ' . CareerRoadmap::count());
    }
}
