<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('collaboration_proposals', function (Blueprint $table) {
            $table->date('timeline_start')->after('timeline')->nullable();
            $table->date('timeline_end')->after('timeline_start')->nullable();
            $table->dropColumn('timeline');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('collaboration_proposals', function (Blueprint $table) {
            $table->string('timeline')->after('expected_outcome');
            $table->dropColumn(['timeline_start', 'timeline_end']);
        });
    }
};
