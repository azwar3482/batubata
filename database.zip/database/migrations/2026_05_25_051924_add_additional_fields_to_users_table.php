<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->json('skills')->nullable();
            $table->json('languages')->nullable();
            $table->string('expected_job_type')->nullable();
            $table->decimal('expected_salary', 15, 2)->nullable();
            $table->text('job_preferences')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'skills',
                'languages',
                'expected_job_type',
                'expected_salary',
                'job_preferences'
            ]);
        });
    }
};
