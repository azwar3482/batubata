<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_document_scores', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('document_id')->constrained('user_documents')->onDelete('cascade');
            $table->json('extracted_skills')->nullable()->comment('Daftar skill yang berhasil diekstrak oleh Python NLP');
            $table->longText('skill_embedding_vector')->nullable()->comment('Vektor embedding JSON dari SentenceTransformers');
            $table->decimal('overall_score', 5, 2)->default(0)->comment('Skor keseluruhan dokumen ini (0-100)');
            $table->timestamp('processed_at')->nullable();
            $table->timestamps();

            // Satu dokumen hanya punya satu skor
            $table->unique('document_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_document_scores');
    }
};
