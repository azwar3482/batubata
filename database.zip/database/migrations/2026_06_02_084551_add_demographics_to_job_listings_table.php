<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('job_listings', function (Blueprint $table) {
            $table->string('blood_type')->nullable()->default('Semua Golongan Darah');
            $table->string('gender')->nullable()->default('Semua Jenis Kelamin');
            $table->integer('max_age')->nullable();
            $table->json('languages')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('job_listings', function (Blueprint $table) {
            $table->dropColumn(['blood_type', 'gender', 'max_age', 'languages']);
        });
    }
};
