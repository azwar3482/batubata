<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Update enum to include assignment and quiz
        DB::statement("ALTER TABLE admin_course_materials MODIFY COLUMN type ENUM('document','video','link','text','embed','assignment','quiz') DEFAULT 'document'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE admin_course_materials MODIFY COLUMN type ENUM('document','video','link','text','embed') DEFAULT 'document'");
    }
};
