<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('user_competency_scores', function (Blueprint $table) {
            // Cek apakah kolom lama ada, lalu rename ke nama standar
            if (Schema::hasColumn('user_competency_scores', 'user_assessment_id')) {
                $table->renameColumn('user_assessment_id', 'assessment_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('user_competency_scores', function (Blueprint $table) {
            // Kembalikan ke nama lama jika rollback
            if (Schema::hasColumn('user_competency_scores', 'assessment_id')) {
                $table->renameColumn('assessment_id', 'user_assessment_id');
            }
        });
    }
};
