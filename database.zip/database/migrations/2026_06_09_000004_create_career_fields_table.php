<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Tabel jurusan/bidang karir
        Schema::create('career_fields', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Nama bidang (Teknik Informatika, Manajemen, dll)
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('icon')->nullable(); // Icon class atau emoji
            $table->string('color')->nullable(); // Warna untuk UI
            $table->json('job_titles')->nullable(); // Contoh posisi: ["Web Developer", "Data Analyst"]
            $table->json('industries')->nullable(); // Industri terkait: ["IT", "Finance"]
            $table->decimal('avg_salary_min', 15, 2)->nullable();
            $table->decimal('avg_salary_max', 15, 2)->nullable();
            $table->integer('demand_score')->default(50); // 0-100 skor permintaan pasar
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Tabel roadmap per bidang
        Schema::create('career_paths', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('career_field_id');
            $table->string('level'); // entry, junior, mid, senior, lead, manager
            $table->string('level_label'); // Staff, Junior, Senior, Lead, Manager
            $table->integer('year_range_min')->nullable(); // Tahun pengalaman min
            $table->integer('year_range_max')->nullable(); // Tahun pengalaman max
            $table->text('description')->nullable();
            $table->json('skills_required')->nullable(); // Skill yang dibutuhkan
            $table->json('certifications')->nullable(); // Sertifikasi yang disarankan
            $table->json('courses')->nullable(); // Kursus yang direkomendasikan
            $table->decimal('salary_min', 15, 2)->nullable();
            $table->decimal('salary_max', 15, 2)->nullable();
            $table->text('tips')->nullable(); // Tips untuk mencapai level ini
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('career_paths');
        Schema::dropIfExists('career_fields');
    }
};
