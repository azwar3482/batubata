<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Tambah kolom TPA ke job_listings
        Schema::table('job_listings', function (Blueprint $table) {
            $table->boolean('use_tpa')->default(false)->after('banner_image');
            $table->unsignedInteger('tpa_deadline_hours')->default(48)->after('use_tpa'); // deadline dalam jam setelah undangan
        });

        // Tambah kolom TPA ke user_job_applications
        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->enum('tpa_status', ['not_required', 'invited', 'in_progress', 'completed', 'passed', 'failed'])
                  ->default('not_required')->after('direct_offer_status');
            $table->unsignedInteger('tpa_session_id')->nullable()->after('tpa_status');
            $table->decimal('tpa_score', 5, 2)->nullable()->after('tpa_session_id');
        });
    }

    public function down(): void
    {
        Schema::table('job_listings', function (Blueprint $table) {
            $table->dropColumn(['use_tpa', 'tpa_deadline_hours']);
        });

        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->dropColumn(['tpa_status', 'tpa_session_id', 'tpa_score']);
        });
    }
};
