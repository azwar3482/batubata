<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tpa_tests', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('job_listing_id')->nullable(); // NULL = template global
            $table->unsignedInteger('created_by'); // industry/admin user_id
            $table->string('title')->default('Tes Potensi Akademik');
            $table->text('description')->nullable();
            $table->unsignedInteger('total_questions')->default(40);
            $table->unsignedInteger('time_limit_minutes')->default(60);
            $table->unsignedInteger('verbal_count')->default(10);
            $table->unsignedInteger('numerik_count')->default(10);
            $table->unsignedInteger('logika_count')->default(10);
            $table->unsignedInteger('spasial_count')->default(10);
            $table->decimal('passing_score', 5, 2)->default(60.00); // persentase kelulusan
            $table->decimal('verbal_weight', 5, 2)->default(30.00);
            $table->decimal('numerik_weight', 5, 2)->default(30.00);
            $table->decimal('logika_weight', 5, 2)->default(20.00);
            $table->decimal('spasial_weight', 5, 2)->default(20.00);
            $table->boolean('randomize_questions')->default(true);
            $table->boolean('randomize_options')->default(true);
            $table->boolean('show_result_after')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['job_listing_id', 'is_active']);
            $table->index(['created_by']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tpa_tests');
    }
};
