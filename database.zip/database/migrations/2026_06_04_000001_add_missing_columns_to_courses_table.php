<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->string('provider')->nullable()->after('description');
            $table->json('skills_covered')->nullable()->after('provider');
            $table->float('rating')->default(0)->after('is_free');
            $table->integer('num_reviews')->default(0)->after('rating');
            $table->string('image_url')->nullable()->after('num_reviews');
            $table->foreignId('created_by')->nullable()->after('image_url')->constrained('users')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->dropForeign(['created_by']);
            $table->dropColumn(['provider', 'skills_covered', 'rating', 'num_reviews', 'image_url', 'created_by']);
        });
    }
};
