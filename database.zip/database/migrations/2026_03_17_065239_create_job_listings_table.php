<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('job_listings', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
        $table->string('external_id')->nullable();
        $table->string('source_platform');
        $table->string('title');
        $table->string('company_name');
        $table->string('location');
        $table->enum('work_type', ['remote', 'hybrid', 'onsite']);
        $table->decimal('salary_min', 12, 2)->nullable();
        $table->decimal('salary_max', 12, 2)->nullable();
        $table->string('experience_required');
        $table->text('description');
        $table->json('required_skills');
        $table->string('application_url');
        $table->date('posted_date');
        $table->date('expires_date');
        $table->boolean('is_active')->default(true);
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('job_listings');
}
};
