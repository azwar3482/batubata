<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->boolean('is_direct_offer')->default(false)->after('notes');
            $table->enum('direct_offer_status', ['pending', 'accepted', 'declined'])->nullable()->after('is_direct_offer');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->dropColumn(['is_direct_offer', 'direct_offer_status']);
        });
    }
};
