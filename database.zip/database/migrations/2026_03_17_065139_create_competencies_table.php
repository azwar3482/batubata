<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('competencies', function (Blueprint $table) {
        $table->id();
        $table->string('code')->unique();
        $table->string('name');
        $table->enum('category', ['technical', 'soft_skill']);
        $table->foreignId('position_id')->constrained()->onDelete('cascade');
        $table->integer('min_level_required')->default(1); // 1-5
        $table->string('source_reference')->nullable();
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('competencies');
}
};
