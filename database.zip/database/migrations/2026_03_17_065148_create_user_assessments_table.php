<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('user_assessments', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->foreignId('position_id')->constrained()->onDelete('cascade');
        $table->timestamp('assessment_date');
        $table->decimal('total_gap_percentage', 5, 2)->default(0);
        $table->enum('status', ['draft', 'completed'])->default('draft');
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('user_assessments');
}
};
