<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('institutions', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->string('name');
        $table->enum('type', ['university', 'polytechnic', 'vocational_school']);
        $table->text('address');
        $table->string('accreditation')->nullable();
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('institutions');
}
};
