<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tpa_test_sessions', function (Blueprint $table) {
            // Tipe tes: online atau offline
            $table->enum('tpa_type', ['online', 'offline'])->default('online')->after('status');

            // Detail offline
            $table->text('offline_instructions')->nullable()->after('tpa_type');
            $table->datetime('offline_scheduled_at')->nullable()->after('offline_instructions');
            $table->string('offline_location')->nullable()->after('offline_scheduled_at');
            $table->string('offline_contact_person')->nullable()->after('offline_location');
            $table->string('offline_contact_phone')->nullable()->after('offline_contact_person');
            $table->text('offline_notes')->nullable()->after('offline_contact_phone');

            // Respon seeker
            $table->enum('seeker_response', ['pending', 'accepted', 'reschedule_proposed', 'declined'])->default('pending')->after('offline_notes');
            $table->datetime('reschedule_proposed_at')->nullable()->after('seeker_response');
            $table->text('reschedule_reason')->nullable()->after('reschedule_proposed_at');

            // Hasil offline (diinput oleh industry)
            $table->decimal('offline_score', 5, 2)->nullable()->after('reschedule_reason');
            $table->boolean('offline_is_passed')->nullable()->after('offline_score');
            $table->text('offline_result_notes')->nullable()->after('offline_is_passed');
        });
    }

    public function down(): void
    {
        Schema::table('tpa_test_sessions', function (Blueprint $table) {
            $table->dropColumn([
                'tpa_type', 'offline_instructions', 'offline_scheduled_at',
                'offline_location', 'offline_contact_person', 'offline_contact_phone',
                'offline_notes', 'seeker_response', 'reschedule_proposed_at',
                'reschedule_reason', 'offline_score', 'offline_is_passed', 'offline_result_notes'
            ]);
        });
    }
};
