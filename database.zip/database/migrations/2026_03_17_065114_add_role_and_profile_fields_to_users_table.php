<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->enum('role', [
            'job_seeker', 
            'industry', 
            'education', 
            'admin', 
            'staf_hr_manager', 
            'staf_recruiter', 
            'staf_talent_sourcer', 
            'staf_interviewer'
        ])->default('job_seeker')->after('email');
        $table->string('phone')->nullable()->after('role');
        $table->string('photo')->nullable()->after('phone');
        $table->string('education_level')->nullable()->after('photo');
        $table->string('major')->nullable()->after('education_level');
        $table->integer('experience_years')->default(0)->after('major');
    });
}

public function down(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->dropColumn(['role', 'phone', 'photo', 'education_level', 'major', 'experience_years']);
    });
}
};
