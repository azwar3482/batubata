<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE user_documents MODIFY COLUMN document_type ENUM('cv', 'ijazah', 'transkrip', 'sertifikat', 'portofolio', 'photo')");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE user_documents MODIFY COLUMN document_type ENUM('cv', 'ijazah', 'transkrip', 'sertifikat', 'portofolio')");
    }
};
