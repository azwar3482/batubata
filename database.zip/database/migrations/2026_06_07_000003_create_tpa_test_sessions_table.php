<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tpa_test_sessions', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('tpa_test_id');
            $table->unsignedInteger('user_id'); // job seeker
            $table->unsignedInteger('job_application_id')->nullable(); // relasi ke lamaran
            $table->enum('status', ['invited', 'in_progress', 'completed', 'expired', 'abandoned'])->default('invited');
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('expires_at')->nullable(); // deadline untuk mengerjakan
            $table->unsignedInteger('time_spent_seconds')->default(0);
            $table->json('question_order')->nullable(); // urutan soal yang di-random
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index(['tpa_test_id', 'status']);
            $table->index(['job_application_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tpa_test_sessions');
    }
};
