<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('user_job_applications', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->foreignId('job_listing_id')->constrained()->onDelete('cascade');
        $table->decimal('matching_percentage', 5, 2);
        $table->timestamp('applied_at');
        $table->enum('status', ['saved', 'applied', 'interviewed', 'offered', 'rejected']);
        $table->text('notes')->nullable();
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('user_job_applications');
}
};
