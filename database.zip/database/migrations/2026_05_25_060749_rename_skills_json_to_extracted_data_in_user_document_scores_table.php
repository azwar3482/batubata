<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_document_scores', function (Blueprint $table) {
            $table->renameColumn('extracted_skills', 'extracted_data');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_document_scores', function (Blueprint $table) {
            $table->renameColumn('extracted_data', 'extracted_skills');
        });
    }
};
