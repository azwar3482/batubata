<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('user_assessments', function (Blueprint $table) {
            // Drop foreign key constraint first, then make nullable
            $table->dropForeign(['position_id']);
            $table->unsignedBigInteger('position_id')->nullable()->change();
            $table->foreign('position_id')->references('id')->on('positions')->onDelete('set null');

            // Add job_listing_id for job-based assessments
            $table->unsignedBigInteger('job_listing_id')->nullable()->after('position_id');
            $table->foreign('job_listing_id')->references('id')->on('job_listings')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('user_assessments', function (Blueprint $table) {
            $table->dropForeign(['job_listing_id']);
            $table->dropColumn('job_listing_id');

            $table->dropForeign(['position_id']);
            $table->unsignedBigInteger('position_id')->nullable(false)->change();
            $table->foreign('position_id')->references('id')->on('positions')->onDelete('cascade');
        });
    }
};
