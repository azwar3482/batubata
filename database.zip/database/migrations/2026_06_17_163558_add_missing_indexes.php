<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Teacher Classes
        Schema::table('teacher_classes', function (Blueprint $table) {
            $table->index('teacher_id');
            $table->index('course_id');
        });

        // Class Enrollments
        Schema::table('class_enrollments', function (Blueprint $table) {
            $table->index('class_id');
            $table->index('user_id');
        });

        // Submissions
        Schema::table('submissions', function (Blueprint $table) {
            $table->index('enrollment_id');
            $table->index('material_id');
        });

        // Course Modules
        Schema::table('course_modules', function (Blueprint $table) {
            $table->index('course_id');
        });

        // Course Materials
        Schema::table('course_materials', function (Blueprint $table) {
            $table->index('module_id');
        });

        // Teacher Profiles
        Schema::table('teacher_profiles', function (Blueprint $table) {
            $table->index('user_id');
        });

        // Teacher Courses
        Schema::table('teacher_courses', function (Blueprint $table) {
            $table->index('teacher_id');
            $table->index('competency_id');
        });

        // Direct Conversations
        Schema::table('direct_conversations', function (Blueprint $table) {
            $table->index('industry_id');
            $table->index('job_seeker_id');
        });

        // Direct Messages
        Schema::table('direct_messages', function (Blueprint $table) {
            $table->index('conversation_id');
        });

        // User Document Scores
        Schema::table('user_document_scores', function (Blueprint $table) {
            $table->index('document_id');
            $table->index('user_id');
        });

        // Career Histories
        Schema::table('career_histories', function (Blueprint $table) {
            $table->index('user_id');
        });

        // Skill Analyses
        Schema::table('skill_analyses', function (Blueprint $table) {
            $table->index('user_id');
        });

        // Collaboration Proposals
        Schema::table('collaboration_proposals', function (Blueprint $table) {
            $table->index('user_id');
            $table->index('institution_id');
        });

        // Programs
        Schema::table('programs', function (Blueprint $table) {
            $table->index('institution_id');
        });

        // Program Enrollments
        Schema::table('program_enrollments', function (Blueprint $table) {
            $table->index('program_id');
        });
    }

    public function down(): void
    {
        Schema::table('teacher_classes', function (Blueprint $table) {
            $table->dropIndex(['teacher_id']);
            $table->dropIndex(['course_id']);
        });

        Schema::table('class_enrollments', function (Blueprint $table) {
            $table->dropIndex(['class_id']);
            $table->dropIndex(['user_id']);
        });

        Schema::table('submissions', function (Blueprint $table) {
            $table->dropIndex(['enrollment_id']);
            $table->dropIndex(['material_id']);
        });

        Schema::table('course_modules', function (Blueprint $table) {
            $table->dropIndex(['course_id']);
        });

        Schema::table('course_materials', function (Blueprint $table) {
            $table->dropIndex(['module_id']);
        });

        Schema::table('teacher_profiles', function (Blueprint $table) {
            $table->dropIndex(['user_id']);
        });

        Schema::table('teacher_courses', function (Blueprint $table) {
            $table->dropIndex(['teacher_id']);
            $table->dropIndex(['competency_id']);
        });

        Schema::table('direct_conversations', function (Blueprint $table) {
            $table->dropIndex(['industry_id']);
            $table->dropIndex(['job_seeker_id']);
        });

        Schema::table('direct_messages', function (Blueprint $table) {
            $table->dropIndex(['conversation_id']);
        });

        Schema::table('user_document_scores', function (Blueprint $table) {
            $table->dropIndex(['document_id']);
            $table->dropIndex(['user_id']);
        });

        Schema::table('career_histories', function (Blueprint $table) {
            $table->dropIndex(['user_id']);
        });

        Schema::table('skill_analyses', function (Blueprint $table) {
            $table->dropIndex(['user_id']);
        });

        Schema::table('collaboration_proposals', function (Blueprint $table) {
            $table->dropIndex(['user_id']);
            $table->dropIndex(['institution_id']);
        });

        Schema::table('programs', function (Blueprint $table) {
            $table->dropIndex(['institution_id']);
        });

        Schema::table('program_enrollments', function (Blueprint $table) {
            $table->dropIndex(['program_id']);
        });
    }
};
