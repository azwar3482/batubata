<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tpa_results', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('session_id')->unique(); // tpa_test_sessions.id
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('tpa_test_id');

            // Skor per kategori (persentase 0-100)
            $table->decimal('verbal_score', 5, 2)->default(0);
            $table->decimal('numerik_score', 5, 2)->default(0);
            $table->decimal('logika_score', 5, 2)->default(0);
            $table->decimal('spasial_score', 5, 2)->default(0);

            // Skor total (persentase 0-100, weighted)
            $table->decimal('total_score', 5, 2)->default(0);

            // Skor Bappenas-style (200-800)
            $table->unsignedInteger('bappenas_score')->default(200);

            // Statistik
            $table->unsignedInteger('total_correct')->default(0);
            $table->unsignedInteger('total_wrong')->default(0);
            $table->unsignedInteger('total_unanswered')->default(0);
            $table->unsignedInteger('total_questions')->default(0);

            // Status kelulusan
            $table->boolean('is_passed')->default(false);
            $table->decimal('passing_score', 5, 2)->default(60.00);

            $table->timestamps();

            $table->index(['user_id']);
            $table->index(['tpa_test_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tpa_results');
    }
};
