<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Index untuk user_job_applications
        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->index('status');
            $table->index(['user_id', 'job_listing_id']);
            $table->index(['user_id', 'status']);
        });

        // Index untuk career_roadmaps
        Schema::table('career_roadmaps', function (Blueprint $table) {
            $table->index(['user_id', 'position_id']);
        });

        // Index untuk user_assessments
        Schema::table('user_assessments', function (Blueprint $table) {
            $table->index(['user_id', 'assessment_date']);
        });

        // Index untuk user_competency_scores
        Schema::table('user_competency_scores', function (Blueprint $table) {
            $table->index(['assessment_id', 'priority']);
        });

        // Index untuk job_listings
        Schema::table('job_listings', function (Blueprint $table) {
            $table->index(['is_active', 'expires_date']);
            $table->index('user_id');
        });

        // Index untuk user_course_progress
        Schema::table('user_course_progress', function (Blueprint $table) {
            $table->index(['user_id', 'status']);
        });

        // Index untuk competencies
        Schema::table('competencies', function (Blueprint $table) {
            $table->index(['position_id', 'category']);
        });
    }

    public function down(): void
    {
        Schema::table('user_job_applications', function (Blueprint $table) {
            $table->dropIndex(['status']);
            $table->dropIndex(['user_id', 'job_listing_id']);
            $table->dropIndex(['user_id', 'status']);
        });

        Schema::table('career_roadmaps', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'position_id']);
        });

        Schema::table('user_assessments', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'assessment_date']);
        });

        Schema::table('user_competency_scores', function (Blueprint $table) {
            $table->dropIndex(['assessment_id', 'priority']);
        });

        Schema::table('job_listings', function (Blueprint $table) {
            $table->dropIndex(['is_active', 'expires_date']);
            $table->dropIndex(['user_id']);
        });

        Schema::table('user_course_progress', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'status']);
        });

        Schema::table('competencies', function (Blueprint $table) {
            $table->dropIndex(['position_id', 'category']);
        });
    }
};
