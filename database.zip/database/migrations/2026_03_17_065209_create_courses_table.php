<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('courses', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->text('description');
        $table->string('platform');
        $table->string('category');
        $table->foreignId('competency_id')->constrained()->onDelete('cascade');
        $table->integer('duration_hours');
        $table->enum('level', ['beginner', 'intermediate', 'advanced']);
        $table->string('url');
        $table->decimal('price', 10, 2)->nullable();
        $table->boolean('is_free')->default(false);
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('courses');
}
};
