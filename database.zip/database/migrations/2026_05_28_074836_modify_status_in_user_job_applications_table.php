<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::statement("ALTER TABLE user_job_applications MODIFY COLUMN status ENUM('saved', 'applied', 'reviewed', 'interviewed', 'offered', 'rejected') NOT NULL");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::statement("ALTER TABLE user_job_applications MODIFY COLUMN status ENUM('saved', 'applied', 'interviewed', 'offered', 'rejected') NOT NULL");
    }
};
