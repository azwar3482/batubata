<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('career_roadmaps', function (Blueprint $table) {
            $table->foreignId('competency_id')->nullable()->after('position_id');
            $table->string('priority')->nullable()->after('milestone_description');
            $table->decimal('gap_percentage', 5, 1)->nullable()->after('priority');
            $table->integer('current_level')->nullable()->after('gap_percentage');
            $table->integer('target_level')->nullable()->after('current_level');
            $table->json('recommended_courses')->nullable()->after('target_level');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('career_roadmaps', function (Blueprint $table) {
            $table->dropColumn(['competency_id', 'priority', 'gap_percentage', 'current_level', 'target_level', 'recommended_courses']);
        });
    }
};
