<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tpa_answers', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('session_id'); // tpa_test_sessions.id
            $table->unsignedInteger('question_id'); // tpa_questions.id
            $table->string('selected_answer', 5)->nullable(); // A, B, C, D, E (NULL jika tidak dijawab)
            $table->boolean('is_correct')->default(false);
            $table->unsignedInteger('time_spent_seconds')->default(0);
            $table->boolean('is_flagged')->default(false); // ditandai untuk review
            $table->timestamps();

            $table->unique(['session_id', 'question_id']);
            $table->index(['session_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tpa_answers');
    }
};
