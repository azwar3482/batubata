<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('user_competency_scores', function (Blueprint $table) {
        $table->id();
        $table->foreignId('assessment_id')->constrained('user_assessments')->onDelete('cascade');
        $table->foreignId('competency_id')->constrained()->onDelete('cascade');
        $table->integer('self_assessed_level'); // 1-5
        $table->integer('ai_analyzed_level')->nullable();
        $table->decimal('gap_percentage', 5, 2);
        $table->enum('priority', ['high', 'medium', 'low']);
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('user_competency_scores');
}
};
