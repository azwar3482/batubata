<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chat_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id');
            $table->enum('role', ['user', 'assistant'])->default('user');
            $table->text('content');
            $table->string('user_role')->nullable(); // role user saat chat
            $table->json('context_used')->nullable(); // section dokumen yang digunakan
            $table->json('metadata')->nullable(); // deep links, suggestions, dll
            $table->string('session_id')->nullable(); // group percakapan
            $table->timestamps();

            $table->index(['user_id', 'session_id']);
            $table->index(['created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('chat_messages');
    }
};
