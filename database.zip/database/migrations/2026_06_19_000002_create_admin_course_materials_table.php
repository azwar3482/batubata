<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admin_course_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('chapter_id')->constrained('admin_course_chapters')->onDelete('cascade');
            $table->string('title');
            $table->enum('type', ['document', 'video', 'link', 'text', 'embed'])->default('document');
            $table->text('content')->nullable();
            $table->string('external_url')->nullable();
            $table->string('file_path')->nullable();
            $table->string('file_name')->nullable();
            $table->integer('file_size')->nullable();
            $table->string('mime_type')->nullable();
            $table->integer('order_number')->default(0);
            $table->boolean('is_downloadable')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_course_materials');
    }
};
