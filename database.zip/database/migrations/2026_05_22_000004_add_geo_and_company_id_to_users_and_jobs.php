<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Tambah kolom geo ke tabel users
        Schema::table('users', function (Blueprint $table) {
            $table->string('address')->nullable()->after('bio')->comment('Alamat lengkap user');
            $table->decimal('latitude', 10, 8)->nullable()->after('address')->comment('Koordinat GPS: Latitude');
            $table->decimal('longitude', 11, 8)->nullable()->after('latitude')->comment('Koordinat GPS: Longitude');
        });

        // Tambah kolom geo dan company_id ke tabel job_listings
        Schema::table('job_listings', function (Blueprint $table) {
            $table->foreignId('company_id')->nullable()->after('id')->constrained('companies')->onDelete('set null');
            $table->decimal('latitude', 10, 8)->nullable()->after('location')->comment('Koordinat GPS lokasi kantor');
            $table->decimal('longitude', 11, 8)->nullable()->after('latitude')->comment('Koordinat GPS lokasi kantor');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['address', 'latitude', 'longitude']);
        });

        Schema::table('job_listings', function (Blueprint $table) {
            $table->dropForeign(['company_id']);
            $table->dropColumn(['company_id', 'latitude', 'longitude']);
        });
    }
};
