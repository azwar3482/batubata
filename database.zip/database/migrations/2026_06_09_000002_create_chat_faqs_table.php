<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chat_faqs', function (Blueprint $table) {
            $table->id();
            $table->string('question'); // Pertanyaan
            $table->text('answer'); // Jawaban
            $table->string('category')->nullable(); // Kategori: umum, job_seeker, industry, education, tpa, dll
            $table->json('roles')->nullable(); // Role yang bisa melihat: ["job_seeker", "industry"]
            $table->json('keywords')->nullable(); // Keyword untuk pencarian: ["lamar", "apply", "melamar"]
            $table->json('deep_links')->nullable(); // Link terkait: [{"label":"Lamar Kerja","url":"/seeker/jobs"}]
            $table->integer('priority')->default(0); // Prioritas tampil (angka lebih tinggi = lebih prioritas)
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['category', 'is_active']);
            $table->index(['priority']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('chat_faqs');
    }
};
