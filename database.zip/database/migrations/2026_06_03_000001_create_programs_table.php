<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('programs', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('type'); // Bootcamp, Sertifikasi, Workshop, Magang
            $table->text('description')->nullable();
            $table->string('duration');
            $table->integer('max_students')->default(30);
            $table->enum('status', ['active', 'upcoming', 'completed', 'cancelled'])->default('upcoming');
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->foreignId('institution_id')->nullable()->constrained()->onDelete('set null');
            $table->json('industry_partners')->nullable();
            $table->string('curriculum_path')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('programs');
    }
};
