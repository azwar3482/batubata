<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('company_document_weights', function (Blueprint $table) {
            $table->id();
            // Nullable company_id = konfigurasi DEFAULT untuk semua perusahaan
            $table->foreignId('company_id')->nullable()->constrained('companies')->onDelete('cascade');
            $table->string('name')->default('Default')->comment('Nama konfigurasi bobot, misal: "Startup Tech" atau "Default"');

            // Bobot per jenis dokumen (total harus 100)
            $table->decimal('cv_weight', 5, 2)->default(50.00)->comment('Bobot CV dalam %');
            $table->decimal('ijazah_weight', 5, 2)->default(20.00)->comment('Bobot Ijazah dalam %');
            $table->decimal('transkrip_weight', 5, 2)->default(15.00)->comment('Bobot Transkrip dalam %');
            $table->decimal('sertifikat_weight', 5, 2)->default(10.00)->comment('Bobot Sertifikat dalam %');
            $table->decimal('portofolio_weight', 5, 2)->default(5.00)->comment('Bobot Portofolio dalam %');

            $table->boolean('is_active')->default(true);
            $table->timestamps();

            // Satu perusahaan hanya punya satu konfigurasi bobot
            $table->unique('company_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_document_weights');
    }
};
