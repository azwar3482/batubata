<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tpa_questions', function (Blueprint $table) {
            $table->id();
            $table->enum('category', ['verbal', 'numerik', 'logika', 'spasial']);
            $table->string('subcategory')->nullable(); // sinonim, antonim, analogi, deret_angka, silogisme, dll
            $table->enum('difficulty', ['easy', 'medium', 'hard'])->default('medium');
            $table->text('question_text');
            $table->string('question_image')->nullable(); // untuk soal spasial/gambar
            $table->json('options'); // [{key:"A", text:"..."}, {key:"B", text:"..."}, ...]
            $table->string('correct_answer', 5); // A, B, C, D, E
            $table->text('explanation')->nullable(); // penjelasan jawaban
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('created_by')->nullable(); // admin atau industry user_id
            $table->timestamps();

            $table->index(['category', 'is_active']);
            $table->index(['difficulty']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tpa_questions');
    }
};
