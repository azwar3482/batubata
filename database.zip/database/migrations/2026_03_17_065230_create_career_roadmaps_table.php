<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('career_roadmaps', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->foreignId('position_id')->constrained()->onDelete('cascade');
        $table->integer('month_number'); // 1-6
        $table->string('milestone_title');
        $table->text('milestone_description');
        $table->boolean('is_completed')->default(false);
        $table->timestamp('completed_at')->nullable();
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('career_roadmaps');
}
};
