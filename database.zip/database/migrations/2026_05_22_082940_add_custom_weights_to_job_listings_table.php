<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('job_listings', function (Blueprint $table) {
            $table->boolean('use_custom_weight')->default(false)->after('required_skills');
            $table->decimal('cv_weight', 5, 2)->nullable()->after('use_custom_weight');
            $table->decimal('ijazah_weight', 5, 2)->nullable()->after('cv_weight');
            $table->decimal('transkrip_weight', 5, 2)->nullable()->after('ijazah_weight');
            $table->decimal('sertifikat_weight', 5, 2)->nullable()->after('transkrip_weight');
            $table->decimal('portofolio_weight', 5, 2)->nullable()->after('sertifikat_weight');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('job_listings', function (Blueprint $table) {
            $table->dropColumn([
                'use_custom_weight',
                'cv_weight',
                'ijazah_weight',
                'transkrip_weight',
                'sertifikat_weight',
                'portofolio_weight'
            ]);
        });
    }
};
